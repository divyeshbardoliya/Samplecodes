import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classNames from "classnames";
import Chartjs from 'chart.js';

class Chart extends PureComponent {
  constructor(props) {
    super(props);
    this.el = null;
    this.chart = null;
  }

  componentDidMount() {
    const { config } = this.props;
    this.chart = new Chartjs((this.el).getContext('2d'), config);
  }

  render() {
    const { className, config, ...props } = this.props;

    return (
      <canvas
        id="chart"
        className={classNames(className)}
        ref={(node) => this.el = node}
        {...props}
      />
    );
  }
}

Chart.propTypes = {
  config: PropTypes.object.isRequired
};

export default Chart;