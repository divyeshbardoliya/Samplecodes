import { SidebarPanel as SidebarPanelTmp } from "./SidebarPanel";
import { Modal as ModalTmp } from "./Modal";
import { Calendar as CalendarTmp } from "./Calendar";
import { Dialog as DialogTmp } from "./Dialog";
import { Scrollbar as ScrollbarTmp } from "./Scrollbar";

export const Searchfield = SearchfieldTmp;
export const SidebarPanel = SidebarPanelTmp;
export const Modal = ModalTmp;
export const Calendar = CalendarTmp;
export const Dialog = DialogTmp;
export const Scrollbar = ScrollbarTmp;