import React, { Component } from 'react';
import NotificationsSystem from 'reapop';

import theme from './theme';

export default class MyNotificationsSystem extends Component {
  render() {
    return (<NotificationsSystem theme={theme} />)
  }
}