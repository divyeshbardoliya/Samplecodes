import React from "react";
import Responsive from "react-responsive";
import moment from "moment";
import _ from "lodash";

export const getGreeting = hours => {
  let time = hours || moment().hours();
  let greeting = "";

  switch (time) {
    case time < 10:
      greeting = "Good morning";
      break;
    case time < 20:
      greeting = "Good day";
      break;
    default:
      greeting = "Good evening";
  }

  return greeting;
};

export const requireAll = requireContext => requireContext.keys().map(requireContext);

export const _getSubdomain = (hostname = window.location.hostname) => ((["127.0.0.1", "localhost"].includes(hostname)) ? "" : ((hostname).split(".")[0]).split("//")[0]);

export const ucfirst = (string) => (string.charAt(0).toUpperCase() + string.slice(1).toLowerCase());

export const isValidEmail = (email = "") => (new RegExp(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).test(email));

export const isValidPassword = (password = "") => (/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\dX])(?=.*[!@#$%]).*$/.test(password));

export const isValidPhone = (phone) => (/(?:\d{1}\s)?\(?(\d{3})\)?-?\s?(\d{3})-?\s?(\d{4})/g).test(phone);

export const getInitials = (string, divider = " ") => ((string || "").split(divider)).map((a) => a.charAt(0)).join("").toUpperCase();

export const requestAnimationFrame = window.requestAnimationFrame
  || window.mozRequestAnimationFrame
  || window.webkitRequestAnimationFrame
  || window.msRequestAnimationFrame
  || function (f) { return setTimeout(f, 1000 / 60) } // simulate calling code 60 

export const cancelAnimationFrame = window.cancelAnimationFrame
  || window.mozCancelAnimationFrame
  || function (requestID) { clearTimeout(requestID) } //fall back

export const Desktop = props => <Responsive {...props} minWidth={1200} />;
export const Tablet = props => <Responsive {...props} minWidth={768} maxWidth={1199} />;
export const Mobile = props => <Responsive {...props} maxWidth={767} />;
export const Default = props => <Responsive {...props} minWidth={768} />;

export default {
  getGreeting,
  requireAll,
  _getSubdomain,
  isValidEmail,
  isValidPassword,
  getInitials,
  _groupAlpha,
  formatOptions
};
