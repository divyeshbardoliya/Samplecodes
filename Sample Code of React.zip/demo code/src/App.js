import React, { Component } from "react";
import { connect } from "react-redux";
import _ from "lodash";

// Reapop ( react-notification-system ) with customized theme.
import NotificationsSystem from './components/NotificationsSystem';

// pages
import Login from "./pages/Login";
import Application from "./pages/Application";

// render Login / Application's Dashboard, We can do it in both way using route (react-router) / conditional rendering, I have done using condition.

class App extends Component {
  render() {
    return (
      <React.Fragment>
        {(!_.isEmpty(this.props.token)) ? <Application /> : <Login />}
        <NotificationsSystem />
      </React.Fragment>
    )
  }
}

const mapStateToProps = state => ({
  token: _.get(state, "oauth.token")
});

export default connect(mapStateToProps)(App);
