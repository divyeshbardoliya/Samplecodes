import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { ApolloProvider } from "react-apollo";

// apollo-client ( `GraphQL` client for handling the api calls. )
import { client } from '../../graphql/client';

// pages
import Dashboard from "../Dashboard";
import Site from "../Site";

class Application extends Component {
  render() {
    return (
      <ApolloProvider client={client}>
        <Router>
          <Switch>
            <Route path="/:siteId([0-9]+)" component={Site} />
            <Route component={Dashboard} />
          </Switch>
        </Router>
      </ApolloProvider>
    )
  }
}

export default Application;