<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendEmailVerificationCode;
use App\Models\EmailVerify;
use Carbon\Carbon;

class EmailController extends Controller {

    public function getCode(Request $request) {
        try {
            // get email from request.
            $email = $request->email;

            // verify email address.
            if (empty($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
                throw new \Exception('Invalid email address.', 422);
            }

            $email_exist = EmailVerify::where('email', $email)->first();

            if (!empty($email_exist)) {

                $remaining_minutes = Carbon::now()->diffInMinutes(Carbon::createFromFormat(Carbon::DEFAULT_TO_STRING_FORMAT, $email_exist->expire_at));

                if (!$email_exist->verified && $remaining_minutes > 0) {
                    throw new \Exception("The verification email has already been sent, please wait at least for the next {$remaining_minutes} minute(s) to receive a new one.", 422);
                }

                $email_exist->delete();
            }

            // generate a code.
            $code = mt_rand(100000, 999999);

            // send code to the email for varification.
            Mail::to($email)->queue(new SendEmailVerificationCode($code));

            // store the code into the DB.
            $EmailVerify = new EmailVerify;
            $EmailVerify->email = $email;
            $EmailVerify->code = $code;
            $EmailVerify->expire_at = Carbon::now()->addMinute(config('timewise.email_expire'));
            $EmailVerify->save();

            return response()->json([
                        'status' => 'OK',
                        'code' => 200,
                        'message' => 'Verification email sent, please check your inbox to continue the registration process.'
                            ], 200
            );
        } catch (\Exception $ex) {
            return response()->json([
                        'status' => 'ERROR',
                        'code' => $ex->getCode(),
                        'errors' => @json_decode($ex->getMessage()) ?: [(object) ["message" => $ex->getMessage()]]
                            ], $ex->getCode()
            );
        }
    }

    public function verifyCode(Request $request) {
        try {
            $email = $request->email;
            $code = $request->code;

            if (empty($email) || !($email = filter_var($email, FILTER_VALIDATE_EMAIL))) {
                throw new \Exception('No or invalid email found.', 422);
            }

            if (empty($code)) {
                throw new \Exception('No code found.', 422);
            }

            $EmailVerify = EmailVerify::where('email', $email)->first();

            if (!empty($EmailVerify)) {

                if (!$EmailVerify->verified) {
                    if ($EmailVerify->attempt >= 6) {
                        throw new \Exception('Sorry, Maximum attempts for verification have ended.', 422);
                    }

                    $EmailVerify->attempt = $EmailVerify->attempt + 1;
                    $EmailVerify->save();
                }


                if ($EmailVerify->code === $code) {
                    $EmailVerify->verified = true;
                    $EmailVerify->save();

                    return response()->json([
                                'status' => 'OK',
                                'code' => 200,
                                'message' => "Email: ({$email}) is successfully verified."
                                    ], 200
                    );
                }
            }

            throw new \Exception('Invalid code.', 422);
        } catch (\Exception $ex) {
            return response()->json([
                        'status' => 'ERROR',
                        'code' => $ex->getCode(),
                        'errors' => @json_decode($ex->getMessage()) ?: [(object) ["message" => $ex->getMessage()]]
                            ], $ex->getCode()
            );
        }
    }

}
