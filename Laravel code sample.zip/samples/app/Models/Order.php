<?php

namespace App\Models;

use Illuminate\Database\Eloquent\{
  Model,
  SoftDeletes
};

class Order extends Model {

  use SoftDeletes;

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
      'order_date',
      'refund_date'
  ];

  public function customer() {
    return $this->belongsTo(Customer::class);
  }

  public function location() {
    return $this->belongsTo(Location::class);
  }

  public function items() {
    return $this->belongsToMany(Product::class, 'order_items')->withPivot(['rate', 'quantity'])->withTrashed();
  }

  public function payment() {
    return $this->belongsTo(Payment::class);
  }

  public function getTotalPriceAttribute() {
    $total = 0.00;

    try {
      $items = $this->items;

      foreach ($items ?: [] as $item) {
        $total += (float) (@$item->pivot->rate * @$item->pivot->quantity);
      }

      return $total;
    } catch (Exception $ex) {
      
    }

    return $total;
  }

  public function getRefundAmountAttribute($value) {
    return (float) $value / 100;
  }

  public function setRefundAmountAttribute($value) {
    $this->attributes['refund_amount'] = $value / 100;
  }

}
