<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Location;
use Illuminate\Auth\Access\HandlesAuthorization;

class LocationPolicy {

  use HandlesAuthorization;

  /**
   * Determine whether the user can list the locations.
   *
   * @param  \App\Models\User  $user
   * @return mixed
   */
  public function list(User $user) {
    return (($user->isSuperAdmin() || $user->isAdmin() || $user->hasPermission('locations.view')));
  }
  
  /**
   * Determine whether the user can view the location.
   *
   * @param  \App\Models\User  $user
   * @param  \App\Models\Location  $location
   * @return mixed
   */
  public function view(User $user, Location $location) {
    return (($user->isSuperAdmin() || $user->isAdmin() || $user->hasPermission('locations.view')) && $user->locations()->find($location->id));
  }

  /**
   * Determine whether the user can create locations.
   *
   * @param  \App\Models\User  $user
   * @return mixed
   */
  public function create(User $user) {
    return ($user->isSuperAdmin() || $user->isAdmin() || $user->hasPermission('locations.create'));
  }

  /**
   * Determine whether the user can update the location.
   *
   * @param  \App\Models\User  $user
   * @param  \App\Models\Location  $location
   * @return mixed
   */
  public function update(User $user, Location $location) {
    return (($user->isSuperAdmin() || $user->isAdmin()) || ($user->hasPermission('locations.update') && $user->locations()->find($location->id)));
  }

  /**
   * Determine whether the user can delete the location.
   *
   * @param  \App\Models\User  $user
   * @param  \App\Models\Location  $location
   * @return mixed
   */
  public function delete(User $user, Location $location) {
    return (($user->isSuperAdmin() || $user->isAdmin()) || ($user->hasPermission('locations.delete') && $user->locations()->find($location->id)));
  }

}
