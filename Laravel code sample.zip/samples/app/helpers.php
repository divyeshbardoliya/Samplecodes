<?php

use Carbon\Carbon;

if (!function_exists("_config")) {

  function _config($key = null, $default = null) {
    if (is_null($key)) {
      return get_defined_constants();
    }

    if (is_array($key)) {
      foreach ($key ?: [] as $name => $value) {
        if (!defined($name)) {
          define($name, $value);
        }
      }
      return true;
    }

    if (defined($key)) {
      return constant($key);
    }

    return $default;
  }

}

if (!function_exists('get_permission_error')) {

  function get_permission_error($entity, $permission = 'list') {
    $error_template = config('timewise.permission_error');

    $error = str_replace('#{PERMISSION}', $permission, $error_template);
    $error = str_replace('#{ENTITY}', $entity, $error);

    return $error;
  }

}

if (!function_exists('get_permission_array')) {

  function get_permission_array($permission = []) {
    $default = config('timewise.permissions');

    if (empty($permission)) {
      return $default;
    }

    $tmp = [];

    $permission = @json_decode(json_encode($permission), true) ?: [];

    foreach ($default ?: [] as $k => $arr) {
      $tmp[$k] = array_merge($arr, data_get($permission, $k, []));
    }

    return $tmp;
  }

}

if (!function_exists('is_date')) {

  function is_date($date) {
    $timestamp = strtotime($date);

    if (!empty($timestamp)) {
      return Carbon::createFromTimestamp($timestamp);
    }

    return false;
  }

}

if (!function_exists('sales_format')) {

  function sales_format($numbers) {
    $readable = array("", "K", "M", "B", "T", 'Q');
    $index = 0;

    while ($numbers >= 1000) {
      $numbers /= 1000;
      $index++;
    }

    return(round($numbers, 1) . $readable[$index]);
  }

}

if (!function_exists('generate_uuid')) {

  function generate_uuid() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            // 32 bits for "time_low"
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            // 16 bits for "time_mid"
            mt_rand(0, 0xffff),
            // 16 bits for "time_hi_and_version",
            // four most significant bits holds version number 4
            mt_rand(0, 0x0fff) | 0x4000,
            // 16 bits, 8 bits for "clk_seq_hi_res",
            // 8 bits for "clk_seq_low",
            // two most significant bits holds zero and one for variant DCE1.1
            mt_rand(0, 0x3fff) | 0x8000,
            // 48 bits for "node"
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
  }

}

if (!function_exists('format_phone')) {

  function format_phone($phone, $country = 'us') {
    $function = "format_phone_{$country}";
    if (function_exists($function)) {
      return $function($phone);
    }
    return $phone;
  }

}

if (!function_exists('format_phone_us')) {

  function format_phone_us($phone) {
    // note: making sure we have something
    if (!isset($phone{3})) {
      return '';
    }
    // note: strip out everything but numbers 
    $phone = preg_replace("/[^0-9]/", "", $phone);
    $length = strlen($phone);
    switch ($length) {
      case 7:
        return preg_replace("/([0-9]{3})([0-9]{4})/", "$1 $2", $phone);
        break;
      case 10:
        return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2 $3", $phone);
        break;
      case 11:
        return preg_replace("/([0-9]{1})([0-9]{3})([0-9]{3})([0-9]{4})/", "$1($2) $3 $4", $phone);
        break;
      default:
        return $phone;
        break;
    }
  }

}

if (!function_exists('crud_partition')) {

  function crud_partition($oldData, $newData) {

    // ids
    $oldIds = array_pluck($oldData, 'id');
    $newIds = array_filter(array_pluck($newData, 'id'), 'is_numeric');

    // groups
    $delete = collect($oldData)->filter(function ($model) use ($newIds) {
      return !in_array($model->id, $newIds);
    });

    $update = collect($newData)->filter(function ($model) use ($oldIds) {
      return property_exists($model, 'id') && in_array($model->id, $oldIds);
    });

    $create = collect($newData)->filter(function ($model) {
      return !property_exists($model, 'id');
    });

    // return
    return compact('delete', 'update', 'create');
  }

}

if (!function_exists('check_file_uploaded_name')) {

  /**
   * Check $_FILES[][name]
   *
   * @param (string) $filename - Uploaded file name.
   */
  function check_file_uploaded_name($filename) {
    (bool) ((preg_match("`^[-0-9A-Z_\.]+$`i", $filename)) ? true : false);
  }

}

