<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class AccountCreate extends Command {

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'account:create {account}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command used for creating the first admin account for the company.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle() {
        $account = $this->argument('account');

        // creating the database.
        Artisan::call('db:create', ['database' => str_replace("#{ACCOUNT_NAME}", $account, config('timewise.database_pattern'))]);

        // running the passport migration.
        Artisan::call('migrate', ['--path' => 'vendor/laravel/passport/database/migrations', '--force' => true]);

        // running the application migration.
        Artisan::call('migrate', ['--force' => true]);

        // installing the passport clients.
        Artisan::call('passport:install');

        // retrieving teh passport password client
        $rec = DB::table('oauth_clients')->select(['id', 'secret'])->where('password_client', 1)->where('personal_access_client', 0)->first();

        // update the account's config file.
        $configPath = realpath(base_path("accounts/config.{$account}.php"));
        $configContent = File::get($configPath);
        $updatedContent = str_replace('#{PASSPORT_CLIENT_SECRET}', trim($rec->secret), $configContent);
        $updatedContent = str_replace('#{PASSPORT_CLIENT_ID}', trim($rec->id), $updatedContent);
        File::put($configPath, $updatedContent, true);

        // update the account's .env.[account] file.
        $envPath = realpath(base_path(".env.{$account}"));
        $envContent = File::get($envPath);
        $updatedEnvContent = str_replace('#{PASSPORT_CLIENT_SECRET}', trim($rec->secret), $envContent);
        $updatedEnvContent = str_replace('#{PASSPORT_CLIENT_ID}', trim($rec->id), $updatedEnvContent);
        File::put($envPath, $updatedEnvContent, true);
    }

}
