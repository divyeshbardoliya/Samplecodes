<?php

namespace App\GraphQL\Type;

use GraphQL;
use GraphQL\Type\Definition\Type;
use Folklore\GraphQL\Support\Type as BaseType;

class SalesType extends BaseType {

  protected $attributes = [
      'name' => 'Sales',
      'description' => 'A type'
  ];

  public function fields() {
    return [
        'total' => [
            'type' => Type::string(),
            'description' => 'total sales of the location.'
        ],
        'retail_total' => [
            'type' => Type::string(),
            'description' => 'total retail sales of the location.'
        ],
        'service_total' => [
            'type' => Type::string(),
            'description' => 'total service sales of the location.'
        ],
        'tip_total' => [
            'type' => Type::string(),
            'description' => 'total service sales of the location.'
        ],
        'retail_statistics' => [
            'type' => Type::listOf(Type::float()),
            'description' => 'retail sales data of the location.'
        ],
        'service_statistics' => [
            'type' => Type::listOf(Type::float()),
            'description' => 'service sales data of the location.'
        ],
        'tip_statistics' => [
            'type' => Type::listOf(Type::float()),
            'description' => 'service sales data of the location.'
        ],
    ];
  }

  // getting the total sales
  protected function resolveTotalField($root, $args) {
    $sales = $root;

    $total = 0.00;

    foreach ($sales ?: [] as $sale) {
      $total += (float) $sale->total;
    }

    return sales_format($total);
  }

  // getting the retail total sales
  protected function resolveRetailTotalField($root, $args) {
    $sales = $root;

    $total = 0.00;

    foreach ($sales ?: [] as $sale) {
      if ($sale->type == "retail") {
        $total += (float) $sale->total;
      }
    }

    return sales_format($total);
  }

  // getting the service total sales
  protected function resolveServiceTotalField($root, $args) {
    $sales = $root;

    $total = 0.00;

    foreach ($sales ?: [] as $sale) {
      if ($sale->type == "service") {
        $total += (float) $sale->total;
      }
    }

    return sales_format($total);
  }

  // getting the tip total sales
  protected function resolveTipTotalField($root, $args) {
    $sales = $root;

    $total = 0.00;

    foreach ($sales ?: [] as $sale) {
      if ($sale->type == "tip") {
        $total += (float) $sale->total;
      }
    }

    return sales_format($total);
  }

  // getting the statistics array for the retails sales
  protected function resolveRetailStatisticsField($root, $args) {
    $sales = $root;

    $statistics = [];

    foreach ($sales ?: [] as $sale) {
      if ($sale->type == "retail") {
        $statistics[] = (float) $sale->total;
      }
    }

    return $statistics;
  }

  // getting the statistics array for the services sales
  protected function resolveServiceStatisticsField($root, $args) {
    $sales = $root;

    $statistics = [];

    foreach ($sales ?: [] as $sale) {
      if ($sale->type == "service") {
        $statistics[] = (float) $sale->total;
      }
    }

    return $statistics;
  }

  // getting the statistics array for the tip sales
  protected function resolveTipStatisticsField($root, $args) {
    $sales = $root;

    $statistics = [];

    foreach ($sales ?: [] as $sale) {
      if ($sale->type == "tip") {
        $statistics[] = (float) $sale->total;
      }
    }

    return $statistics;
  }

}
