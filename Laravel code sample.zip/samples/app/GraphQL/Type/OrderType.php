<?php

namespace App\GraphQL\Type;

use GraphQL;
use GraphQL\Type\Definition\Type;
use Folklore\GraphQL\Support\Type as BaseType;

class OrderType extends BaseType {

  protected $attributes = [
      'name' => 'Order',
      'description' => 'An Order'
  ];

  public function fields() {
    return [
        'id' => [
            'type' => Type::nonNull(Type::int()),
            'description' => 'The id of the order'
        ],
        'code' => [
            'type' => Type::string(),
            'description' => 'The code of the order'
        ],
        'customer' => [
            'type' => GraphQL::type('Customer'),
            'description' => 'The customer of the order'
        ],
        'status' => [
            'type' => Type::string(),
            'description' => 'The status of the order'
        ],
        'refund_date' => [
            'type' => Type::string(),
            'description' => 'The refund date of the order'
        ],
        'refund_amount' => [
            'type' => Type::float(),
            'description' => 'The refund amount of the order'
        ],
        'created_at' => [
            'type' => Type::string(),
            'description' => 'The order created on.'
        ],
        'updated_at' => [
            'type' => Type::string(),
            'description' => 'The order last updated on.'
        ],
        'deleted_at' => [
            'type' => Type::string(),
            'description' => 'The order deleted on.'
        ],
        'line_items' => [
            'type' => Type::listOf(GraphQL::type('OrderItem')),
            'description' => 'The order items.'
        ],
        'total_price' => [
            'type' => Type::float(),
            'description' => 'The total price of the order.'
        ],
        'payment' => [
            'type' => GraphQL::type('Payment'),
            'description' => 'The payment associated with this order.'
        ],
    ];
  }

  protected function resolveRefundDateField($root, $args) {
    return $root->refund_date->toDateString();
  }

  protected function resolveCreatedAtField($root, $args) {
    return $root->created_at->toDateTimeString();
  }

  protected function resolveUpdatedAtField($root, $args) {
    return $root->updated_at->toDateTimeString();
  }

  protected function resolveDeletedAtField($root, $args) {
    return $root->deleted_at->toDateTimeString();
  }

  protected function resolveLineItemsField($root, $args) {
    return $root->items;
  }

}
