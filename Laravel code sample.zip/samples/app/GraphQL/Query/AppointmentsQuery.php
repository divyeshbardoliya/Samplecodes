<?php

namespace App\GraphQL\Query;

use GraphQL;
use Folklore\GraphQL\Support\Query;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use Carbon\Carbon;
use App\Models\Appointment;
use Folklore\GraphQL\Support\Traits\ShouldValidate;

class AppointmentsQuery extends Query {

  use ShouldValidate;

  protected $attributes = [
      'name' => 'AppointmentsQuery',
      'description' => 'A query'
  ];

  public function type() {
    return GraphQL::type('AppointmentWithPagination');
  }

  public function args() {
    return [
        'date' => ['name' => 'date', 'type' => Type::string(), 'rules' => ['date']],
        'from' => ['name' => 'from', 'type' => Type::string(), 'rules' => ['date']],
        'to' => ['name' => 'to', 'type' => Type::string(), 'rules' => ['date']],
        'status' => ['name' => 'status', 'type' => Type::listOf(Type::string()), 'rules' => ['array']],
        'tags' => ['name' => 'tags', 'type' => Type::listOf(Type::int()), 'rules' => ['array']],
        'limit' => ['type' => Type::int(), 'rules' => ['numeric']],
        'page' => ['type' => Type::int(), 'rules' => ['numeric']],
        'order_by' => ['type' => Type::string(), 'rules' => ['alpha_dash']],
    ];
  }

  public function authorize($root, $args) {
    return auth()->user()->can('list', Appointment::class);
  }

  public function resolve($root, $args, $context, ResolveInfo $info) {
    // get current user.
    $user = auth()->user();

    // initiate the query builder.
    $appointments = Appointment::query();

    // verifying that only allowed locations 's appointments are included in the result.
    if (!($user->isSuperAdmin() || $user->isAdmin())) {
      $appointments->whereIn('appointments.location_id', $user->locations->pluck('id'));
    }

    $date = is_date(@$args['date']) ?: Carbon::today();

    $from = $date->startOfWeek()->toDateString();
    if (!empty(@$args['from'])) {
      try {
        $from = Carbon::createFromFormat(Carbon::DEFAULT_TO_STRING_FORMAT, $args['from'])->toDateString();
      } catch (\Exception $ex) {

      }
    }

    $appointments->whereDate('start_time', '>=', $from);

    $to = $date->endOfWeek()->toDateString();
    if (!empty(@$args['to'])) {
      try {
        $to = Carbon::createFromFormat(Carbon::DEFAULT_TO_STRING_FORMAT, $args['to'])->toDateString();
      } catch (\Exception $ex) {
        
      }
    }

    $appointments->whereDate('end_time', '<=', $to);

    // filtering the appointments by the status
    $status = (@$args['status']) ?: ['BOOKED', 'BLOCKED']; // default: ['BOOKED', 'BLOCKED']

    if (!empty($status)) {
      $appointments->whereIn('status', $status);
    }

    $tags = @$args['tags'] ?: [];

    if (!empty($tags)) {
      $appointments->whereHas('tags', function($query) use ($tags) {
        $query->whereIn('appointment_tag.tag_id', $tags);
      });
    }

    if (!empty(@$args['order_by'])) {
      $appointments->orderBy($args['order_by']);
    }

    return $appointments->paginate(@$args['limit'], ['*'], 'page', @$args['page']);
  }

}
