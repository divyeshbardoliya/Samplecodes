<?php

namespace App\GraphQL\Mutation;

use GraphQL;
use Folklore\GraphQL\Support\Mutation;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use App\Models\Payment;
use App\Models\Order;
use App\Models\Appointment;
use Carbon\Carbon;
use App\Events\SalesEvent;
use Illuminate\Support\Facades\DB;

class CreatePaymentMutation extends Mutation {

  protected $appointment = null;
  protected $order = null;
  protected $attributes = [
      'name' => 'CreatePayment',
      'description' => "A mutation for creating the 'Payment' entity."
  ];

  public function type() {
    return GraphQL::type('Payment');
  }

  public function args() {
    return [
        'transaction' => ['type' => Type::string(), 'rules' => ['alpha_dash', 'unique:payments,transaction']],
        'customer' => ['type' => Type::nonNull(Type::int()), 'rules' => ['bail', 'required', 'exists:customers,id']],
        'payment_method' => ['type' => Type::nonNull(Type::int()), 'rules' => ['bail', 'required', 'exists:payment_methods,id']],
        'date' => ['type' => Type::string(), 'rules' => ['date']],
        'amount' => ['type' => Type::nonNull(Type::float()), 'rules' => ['required', 'numeric']],
        'other_details' => ['type' => Type::string(), 'rules' => ['json']],
        'order' => ['type' => Type::int(), 'rules' => ['bail', 'required_without:appointment', 'exists:orders,id']],
        'appointment' => ['type' => Type::int(), 'rules' => ['bail', 'required_without:order', 'exists:appointments,id']],
    ];
  }

  public function resolve($root, $args, $context, ResolveInfo $info) {

    if (!empty(@$args['appointment'])) {
      $appointment = Appointment::find($args['appointment']);

      if (empty($appointment) || ($appointment->customer->id != $args['customer'])) {
        return;
      }

      $this->appointment = $appointment;
    }

    if (!empty(@$args['order'])) {
      $order = Order::find($args['order']);

      if (empty($order) || ($order->customer->id != $args['customer'])) {
        return;
      }

      $this->order = $order;
    }

    DB::beginTransaction();

    try {

      // initiate a payment entity.
      $payment = new Payment;

      $payment->transaction_id = @$args['transaction'] ?: generate_uuid();
      $payment->customer_id = $args['customer'];
      $payment->payment_method_id = $args['payment_method'];
      $payment->date = @$args['date'] ?: Carbon::now()->toDateTimeString();
      $payment->amount = $args['amount'] ?: 0.00;
      $payment->status = @$args['status'] ?: config('timewise.payment_status.completed');
      $payment->other_details = @$args['other_details'];

      $payment->save();

      if (!empty($this->order)) {
        $this->order->payment_id = $payment->id;
        $this->order->save();

        // emitting the `sales` event to update the sales data for `retail`.
        event(new SalesEvent($this->order, 'retail'));
      }

      if (!empty($this->appointment)) {
        $this->appointment->payment_id = $payment->id;
        $this->appointment->save();

        // emitting the `sales` event to update the sales data for `service`.
        event(new SalesEvent($this->appointment, 'service'));
      }
    } catch (Exception $ex) {
      // rollback the changes if something went wrong during the operation.
      DB::rollBack();
    }

    DB::commit();

    return $payment;
  }

}
