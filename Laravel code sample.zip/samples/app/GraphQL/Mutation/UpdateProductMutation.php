<?php

namespace App\GraphQL\Mutation;

use GraphQL;
use Folklore\GraphQL\Support\Mutation;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductImage;
use App\Models\Location;

class UpdateProductMutation extends Mutation {

  protected $product;
  protected $attributes = [
      'name' => 'updateProduct',
      'description' => "A mutation for updating the existing 'Product' entity."
  ];

  public function type() {
    return GraphQL::type('Product');
  }

  public function args() {
    return [
        'id' => ['type' => Type::nonNull(Type::int()), 'rules' => ['bail', 'required', 'numeric']],
        'title' => [
            'type' => Type::nonNull(Type::string()),
            'rules' => function($root, $args) {
              return ['bail', 'required', "unique:products,title,{$args['id']},id"];
            }
        ],
        'sub_title' => ['type' => Type::nonNull(Type::string()), 'rules' => ['bail']],
        'brand' => ['type' => Type::string()],
        'code' => [
            'type' => Type::nonNull(Type::string()),
            'rules' => function($root, $args) {
              return ['bail', 'required', "unique:products,code,{$args['id']},id", 'alpha_dash'];
            }
        ],
        'description' => ['type' => Type::string(), 'rules' => ['bail', 'required']],
        'price' => ['type' => Type::float(), 'rules' => ['required', 'numeric']],
        'categories' => ['type' => Type::listOf(Type::int()), 'rules' => ['array', 'exists:categories,id']],
        'images' => ['type' => Type::listOf(GraphQL::type('InputProductImage')), 'rules' => ['array']],
        'attributes' => ['type' => Type::listOf(GraphQL::type('InputProductAttribute')), 'rules' => ['array']],
        'locations' => ['type' => Type::listOf(GraphQL::type('InputLocationProduct')), 'rules' => ['array']],
    ];
  }

  public function authorize($root, $args) {
    $this->product = Product::find($args['id']);
    return auth()->user()->can('update', $this->product);
  }

  public function resolve($root, $args, $context, ResolveInfo $info) {
    $location_ids = Location::all()->pluck('id')->toArray();

    $locations = @$args['locations'] ?: [];

    $location_to_attach = [];

    $locations_not_found = [];

    if (!empty($locations)) {
      foreach ($locations ?: [] as $location) {
        $location = (array) $location;

        if (in_array($location['id'], $location_ids)) {
          $location_to_attach[$location['id']] = [
              'quantity' => @$location['quantity'] ?: 0,
              'price' => @$location['price'] ? $location['price'] * 100 : 0
          ];
          continue;
        }

        $locations_not_found[] = (int) $location['id'];
      }
    }

    if (!empty($locations_not_found)) {
      throw new \Exception(sprintf("Sorry, Location not found with Id: %s", json_encode($locations_not_found)), 404);
    }

    $attributes = @$args['attributes'] ?: [];
    $images = @$args['images'] ?: [];
    $categories = @$args['categories'] ?: [];

    $product = $this->product;

    $product->title = @$args['title'] ?: $product->title;
    $product->sub_title = @$args['sub_title'] ?: $product->sub_title;
    $product->brand = @$args['brand'] ?: $product->brand;
    $product->code = @$args['code'] ?: $product->code;
    $product->description = @$args['description'] ?: $product->description;
    $product->price = @$args['price'] ?: $product->price;

    $product->save();

    // attaching the categories.
    $product->categories()->sync($categories);

    // empty array to fetch the attribute id.
    $new_attr_ids = [];

    // adding attributes of the products.
    foreach ($attributes ?: [] as $attribute) {
      $productAttribute = ProductAttribute::updateOrCreate(['product_id' => $product->id, 'field' => $attribute['field']], ['value' => $attribute['value']]);
      $new_attr_ids[] = $productAttribute->id;
      $product->attributes()->save($productAttribute);
    }

    // delete unwanted product's attributes.
    $product->attributes()->whereNotIn('id', $new_attr_ids)->delete();

    // empty array to fetch the image id.
    $new_img_ids = [];

    $order = 0;
    // adding attributes of the products.
    foreach ($images ?: [] as $image) {
      $url = '';

      if (!($url = filter_var($image['url'], FILTER_VALIDATE_URL))) {
        $old_path = config('timewise.tmp_dir') . DIRECTORY_SEPARATOR . $image['url'];
        $url = config('timewise.product_dir') . '/' . $image['url'];

        if (!file_exists(storage_path("app/$url")) && !@rename($old_path, storage_path("app/$url"))) {
          continue;
        }
      }

      $productImage = ProductImage::updateOrCreate(['product_id' => $product->id, 'url' => $url], ['order' => @$image['order'] ?: $order]);
      $new_img_ids[] = $productImage->id;
      $product->images()->save($productImage);
      $order++;
    }

    // delete unwanted images
    $imgs_to_delete = $product->images()->whereNotIn('product_images.id', $new_img_ids)->get();

    foreach ($imgs_to_delete ?: [] as $img) {
      if (!filter_var($img->url, FILTER_VALIDATE_URL)) {
        @unlink(storage_path("app/$img->url"));
      }
    }

    // delete unwanted product's attributes.
    $product->images()->whereNotIn('product_images.id', $new_img_ids)->delete();

    // attaching the product to locations.
    $product->locations()->sync($location_to_attach);

    return $product;
  }

}
