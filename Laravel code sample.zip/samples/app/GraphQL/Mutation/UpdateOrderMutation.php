<?php

namespace App\GraphQL\Mutation;

use GraphQL;
use Folklore\GraphQL\Support\Mutation;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use App\Models\Order;
use App\Models\Product;

class UpdateOrderMutation extends Mutation {

  protected $order;
  protected $attributes = [
      'name' => 'updateOrder',
      'description' => "A mutation for updating existing 'Order' entity."
  ];

  public function type() {
    return GraphQL::type('Order');
  }

  public function args() {
    return [
        'id' => ['type' => Type::nonNull(Type::int()), 'rules' => ['bail', 'required', 'numeric']],
        'code' => [
            'type' => Type::string(),
            'rules' => function($root, $args) {
              return ['bail', "unique:orders,code,{$args['id']},id", 'alpha_dash'];
            }
        ],
        'status' => ['type' => Type::string(), 'rules' => ['alpha_dash']],
        'refund_date' => ['type' => Type::string(), 'rules' => ['date']],
        'refund_amount' => ['type' => Type::string(), 'rules' => ['numeric']],
        'items' => ['type' => Type::nonNull(Type::listOf(GraphQL::type('InputOrderItem')))],
        'payment' => ['type' => Type::int(), 'rules' => ['numeric', 'exists:payments,id']],
    ];
  }

  public function authorize($root, $args) {
    $this->order = Order::find($args['id']);
    return auth()->user()->can('update', $this->order);
  }

  public function resolve($root, $args, $context, ResolveInfo $info) {
    $order = $this->order;

    $product_ids = Product::all()->pluck('id')->toArray();

    $items = $args['items'];
    $products_not_found = [];
    $products_to_attach = [];

    foreach ($items ?: [] as $item) {
      $item = (array) $item;

      if (in_array($item['id'], $product_ids)) {
        $products_to_attach[$item['id']] = [
            'rate' => @$item['rate'] ?: 0.00,
            'quantity' => @$item['quantity'] ?: 0
        ];
        continue;
      }

      $products_not_found[] = (int) $item['id'];
    }

    if (!empty($products_not_found)) {
      throw new \Exception(sprintf("Sorry, Product not found with Id: %s", json_encode($products_not_found)), 404);
    }

    $order->code = @$args['code'] ?: $order->code;
    $order->status = @$args['status'] ?: $order->status;
    $order->refund_date = @$args['refund_date'] ?: $order->refund_date;
    $order->refund_amount = @$args['refund_amount'] ?: $order->refund_amount;
    $order->payment_id = @$args['payment'] ?: $order->payment_id;

    $order->save();

    // attach products to the order.
    $order->items()->sync($products_to_attach);

    return $order;
  }

}
