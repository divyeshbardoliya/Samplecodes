<?php

namespace App\GraphQL\Mutation;

use GraphQL;
use Folklore\GraphQL\Support\Mutation;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductImage;
use App\Models\Location;
use Illuminate\Support\Facades\File;

class CreateProductMutation extends Mutation {

  protected $attributes = [
      'name' => 'createProduct',
      'description' => "A mutation for creating the 'Product' entity."
  ];

  public function type() {
    return GraphQL::type('Product');
  }

  public function args() {
    return [
        'title' => ['type' => Type::nonNull(Type::string()), 'rules' => ['bail', 'required', 'unique:products,title']],
        'sub_title' => ['type' => Type::nonNull(Type::string())],
        'brand' => ['type' => Type::string(), 'rules' => ['bail', 'required']],
        'code' => ['type' => Type::nonNull(Type::string()), 'rules' => ['bail', 'required', 'unique:products,code', 'alpha_dash']],
        'description' => ['type' => Type::string(), 'rules' => ['bail', 'required']],
        'price' => ['type' => Type::float(), 'rules' => ['required', 'numeric']],
        'categories' => ['type' => Type::listOf(Type::int()), 'rules' => ['array', 'exists:categories,id']],
        'images' => ['type' => Type::listOf(GraphQL::type('InputProductImage')), 'rules' => ['array']],
        'attributes' => ['type' => Type::listOf(GraphQL::type('InputProductAttribute')), 'rules' => ['array']],
        'locations' => ['type' => Type::listOf(GraphQL::type('InputLocationProduct')), 'rules' => ['array']],
    ];
  }

  public function authorize($root, $args) {
    return auth()->user()->can('create', Product::class);
  }

  public function resolve($root, $args, $context, ResolveInfo $info) {
    $location_ids = Location::all()->pluck('id')->toArray();

    // retrieving the `locations` data from the request or assigning the default.
    $locations = @$args['locations'] ?: [];

    $location_to_attach = [];

    $locations_not_found = [];

    // verifying the locations and preparing the attach array.
    foreach ($locations ?: [] as $location) {
      $location = (array) $location;

      if (in_array($location['id'], $location_ids)) {
        $location_to_attach[$location['id']] = [
            'quantity' => @$location['quantity'] ?: 0,
            'price' => @$location['price'] ? $location['price'] * 100 : 0
        ];
        continue;
      }

      $locations_not_found[] = (int) $location['id'];
    }

    // throwing error which will be handled by the exception class and will returns proper json.
    if (!empty($locations_not_found)) {
      throw new \Exception(sprintf("Sorry, Location not found with Id: %s", json_encode($locations_not_found)), 404);
    }
    
    $attributes = @$args['attributes'] ?: [];
    $images = @$args['images'] ?: [];
    $categories = @$args['categories'] ?: [];

    $product = new Product;

    $product->title = $args['title'];
    $product->sub_title = $args['sub_title'];
    $product->brand = $args['brand'];
    $product->code = $args['code'];
    $product->description = $args['description'];
    $product->price = $args['price'];

    $product->save();

    // attaching the categories
    if (!empty($categories)) {
      $product->categories()->sync($categories);
    }

    // adding attributes of the products
    foreach ($attributes ?: [] as $attribute) {
      $product->attributes()->save(ProductAttribute::create($attribute));
    }

    $order = 0;
    // adding images of the products
    foreach ($images ?: [] as $image) {
      $url = '';
      
      if (!($url = filter_var($image['url'], FILTER_VALIDATE_URL))) {
        $old_path = config('timewise.tmp_dir') . DIRECTORY_SEPARATOR . $image['url'];
        $url = config('timewise.product_dir') . '/' . $image['url'];
        if (!@rename($old_path, storage_path("app/$url"))) {
          continue;
        }
      }

      $product->images()->save(ProductImage::create(['url' => $url, 'order' => @$image['order'] ?: $order]));
      $order++;
    }

    if (!empty($location_to_attach)) {
      $product->locations()->sync($location_to_attach);
    }


    return $product;
  }

}
