<?php

namespace App\GraphQL\Mutation;

use GraphQL;
use Folklore\GraphQL\Support\Mutation;
use GraphQL\Type\Definition\ResolveInfo;
use GraphQL\Type\Definition\Type;
use App\Models\Order;
use App\Models\Product;

class CreateOrderMutation extends Mutation {

  protected $attributes = [
      'name' => 'createOrder',
      'description' => "A mutation for creating the 'Order' entity."
  ];

  public function type() {
    return GraphQL::type('Order');
  }

  public function args() {
    return [
        'location' => ['type' => Type::nonNull(Type::int()), 'rules' => ['bail', 'required', 'exists:locations,id']],
        'customer' => ['type' => Type::nonNull(Type::int()), 'rules' => ['bail', 'required', 'exists:customers,id']],
        'code' => ['type' => Type::nonNull(Type::string()), 'rules' => ['bail', 'required', 'unique:orders,code', 'alpha_dash']],
        'status' => ['type' => Type::string(), 'rules' => ['alpha_dash']],
        'refund_date' => ['type' => Type::string(), 'rules' => ['date']],
        'refund_amount' => ['type' => Type::string(), 'rules' => ['numeric']],
        'items' => ['type' => Type::nonNull(Type::listOf(GraphQL::type('InputOrderItem')))],
    ];
  }

  // authorizing the request
  public function authorize($root, $args) {
    return auth()->user()->can('create', Order::class);
  }

  public function resolve($root, $args, $context, ResolveInfo $info) {
    $product_ids = Product::all()->pluck('id')->toArray();

    // retrieving data from the request
    $items = $args['items'];
    $products_not_found = [];
    $products_to_attach = [];

    // prepare the sync array with validation
    foreach ($items ?: [] as $item) {
      $item = (array) $item;

      if (in_array($item['id'], $product_ids)) {
        $products_to_attach[$item['id']] = [
            'rate' => @$item['rate'] ?: 0.00,
            'quantity' => @$item['quantity'] ?: 0
        ];
        continue;
      }

      $products_not_found[] = (int) $item['id'];
    }

    // verify `product_id`
    if (!empty($products_not_found)) {
      throw new \Exception(sprintf("Sorry, Product not found with Id: %s", json_encode($products_not_found)), 404);
    }

    // create a new order
    $order = new Order;

    $order->location_id = $args['location'];
    $order->customer_id = $args['customer'];
    $order->code = $args['code'];
    $order->status = @$args['status'] ?: config('timewise.order_status.placed');
    $order->refund_date = @$args['refund_date'];
    $order->refund_amount = @$args['refund_amount'] ?: 0.00;
    $order->created_by = auth()->user()->id;

    $order->save();

    // attach default `rate` and `quantity` of the products to a location.
    $order->items()->sync($products_to_attach);

    return $order;
  }

}
