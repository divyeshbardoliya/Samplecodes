<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Artisan;

class TimewiseTableSetup extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {

    // creating `roles` table.
    Schema::create('roles', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name')->unique()->comment('a unique name for the role of the users.');
      $table->json('permissions')->nullable()->comment('contains json based user permission.');
      $table->timestamps();
      $table->softDeletes();
    });

    // run seeder for feeling the data into the table.
    Artisan::call('db:seed', array('--class' => 'RolesTableSeeder'));

    // checking if `users` table has `role_id` column.
    if (!Schema::hasColumn('users', 'role_id')) {
      // adding `role_id` to `users` table.
      Schema::table('users', function (Blueprint $table) {
        $table->softDeletes();

        $table->unsignedInteger('role_id')->after('remember_token')->nullable()->comment('user having type of role.');
        $table->timestamp('login_at')->after('role_id')->nullable()->comment('last logged-in time.');
        $table->foreign('role_id')->references('id')->on('roles');
      });
    }

    // creating `locations` table.
    Schema::create('locations', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name');
      $table->string('phone');
      $table->string('street1')->nullable();
      $table->string('street2')->nullable();
      $table->string('city');
      $table->string('state');
      $table->string('country');
      $table->string('zip');
      $table->unsignedInteger('created_by');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `location_user` table.
    Schema::create('location_user', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('location_id');
      $table->unsignedInteger('user_id');

      $table->foreign('user_id')->references('id')->on('users');
      $table->foreign('location_id')->references('id')->on('locations');
    });

    // creating `services` table.
    Schema::create('services', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name')->comment('name of service.');
      $table->text('description')->nullable()->comment('description of service if any.');
      $table->unsignedInteger('created_by')->comment('user who have created the service.');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `location_service` table
    Schema::create('location_service', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('location_id');
      $table->unsignedInteger('service_id');
      $table->integer('duration')->default(0)->comment('duration taken to complete the service.');
      $table->integer('price')->default(0)->comment('price taken for the service.');

      $table->foreign('location_id')->references('id')->on('locations');
      $table->foreign('service_id')->references('id')->on('services');
    });

    // creating `resources` table.
    Schema::create('resources', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name')->comment('name of the resource/room/chair/anything.');
      $table->unsignedInteger('location_id')->comment('resource belongs to which location.');
      $table->unsignedInteger('created_by')->comment('user who have created the resource.');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('location_id')->references('id')->on('locations');
      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `sources` table.
    Schema::create('sources', function(Blueprint $table) {
      $table->increments('id');
      $table->string('name')->comment('type of source.');
      $table->unsignedInteger('created_by')->comment('user who have created the source.');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `customers` table.
    Schema::create('customers', function (Blueprint $table) {
      $table->increments('id');
      $table->string('first_name');
      $table->string('last_name')->nullable();
      $table->boolean('allergies')->default(false);
      $table->boolean('medication')->default(false);
      $table->string('phone');
      $table->boolean('phone_verified')->default(false)->comment('flag to see if phone number is verified.');
      $table->string('alt_phone')->nullable();
      $table->string('email')->unique();
      $table->boolean('email_verified')->default(false)->comment('flag to see if email is verified.');
      $table->unsignedInteger('preferred_staff')->nullable()->comment('favorite staff of the customer.');
      $table->date('dob')->nullable();
      $table->string('occupation')->nullable();
      $table->string('street1')->nullable();
      $table->string('street2')->nullable();
      $table->string('city');
      $table->string('state');
      $table->string('country');
      $table->string('zip');
      $table->string('notes')->nullable()->comment('special notes to consider for the customer.');
      $table->unsignedInteger('source_id')->nullable()->comment('source from which the customer came to know about the service.');
      $table->string('source_information')->nullable()->comment('referral information.');
      $table->boolean('receive_emails')->default(false)->comment('flag indicating that customer will like to receive email alert or not.');
      $table->boolean('receive_sms')->default(false)->comment('flag indicating that customer will like to receive sms alert or not.');
      $table->text('booking_alert')->nullable()->comment('template of booking alert.');
      $table->text('checkin_alert')->nullable()->comment('template of check-in alert.');
      $table->text('checkout_alert')->nullable()->comment('template of check-out alert.');
      $table->unsignedInteger('created_by')->comment('user created the customer.');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('preferred_staff')->references('id')->on('users');
      $table->foreign('source_id')->references('id')->on('sources');
      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `payment_methods` table.
    Schema::create('payment_methods', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name')->comment('payment method name');
      $table->string('short_code')->comment('payment method short code');
      $table->timestamps();
      $table->softDeletes();
    });

    // creating `payments` table.
    Schema::create('payments', function (Blueprint $table) {
      $table->increments('id');
      $table->string('transaction_id')->nullable()->comment('date on which payment is done.');
      $table->unsignedInteger('customer_id')->comment('customer who is paying.');
      $table->unsignedInteger('payment_method_id')->comment('payment method used by the customer for payment.');
      $table->timestamp('date')->nullable()->comment('date on which payment is done.');
      $table->decimal('amount', 12, 2)->default(0.00)->comment("amount of payment.");
      $table->string('status')->nullable()->comment("status of the payment which could be one of [].");
      $table->json('other_details')->nullable()->comment("extra details of the payment.");
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('customer_id')->references('id')->on('customers');
      $table->foreign('payment_method_id')->references('id')->on('payment_methods');
    });

    // creating `appointments` table.
    Schema::create('appointments', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('location_id')->comment('location where the appoinment is booked and processed.');
      $table->unsignedInteger('customer_id')->nullable()->comment('customer who will be served.');
      $table->unsignedInteger('resource_id')->nullable()->comment('room/resource where the customer is served.');
      $table->timestamp('start_time')->nullable()->comment('time when the appointment starts.');
      $table->timestamp('end_time')->nullable()->comment('time when the appointment ends.');
      $table->unsignedInteger('performed_by')->nullable()->comment('staff/employee/user who have served the customer.');
      $table->decimal('discount', 12, 2)->default(0.00)->comment('discount applied to the appointment.');
      $table->integer('price')->default(0)->comment('total price of appointment.');
      $table->decimal('paid', 12, 2)->default(0.00)->comment('amount paid for the appointment.');
      $table->string('status')->default('BOOKED')->comment("status of the appointment which could be one of ['BOOKED','IN-PROCESS' ,'CANCELLED', 'COMPLETED', 'BLOCKED']"); // ['BOOKED','IN-PROCESS' ,'CANCELLED', 'COMPLETED']
      $table->text('cancellation_reason')->nullable()->comment('reason of cancellation if appointment canceled by someone.');
      $table->unsignedInteger('payment_id')->nullable()->comment("payment details if appointment is paid");
      $table->unsignedInteger('created_by');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('location_id')->references('id')->on('locations');
      $table->foreign('customer_id')->references('id')->on('customers');
      $table->foreign('resource_id')->references('id')->on('resources');
      $table->foreign('performed_by')->references('id')->on('users');
      $table->foreign('created_by')->references('id')->on('users');
      $table->foreign('payment_id')->references('id')->on('payments');
    });

    // creating `appointment_service` table.
    Schema::create('appointment_service', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('appointment_id')->comment('appointment booked.');
      $table->unsignedInteger('service_id')->comment('services that will be served for appointment.');

      $table->foreign('appointment_id')->references('id')->on('appointments');
      $table->foreign('service_id')->references('id')->on('services');
    });

    // creating `tags` table.
    Schema::create('tags', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name')->unique()->comment('a unique name for the tag.');
      $table->string('type')->default('system')->comment("type of tag which could be on of ['system', 'custom']."); //['system', 'custom']
      $table->unsignedInteger('created_by')->comment('id of the user who had created this tag.');
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `appointment_tag` table.
    Schema::create('appointment_tag', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('appointment_id')->comment('appointment associated with tag.');
      $table->unsignedInteger('tag_id')->comment('tag associated with appointment.');

      $table->foreign('appointment_id')->references('id')->on('appointments');
      $table->foreign('tag_id')->references('id')->on('tags');
    });

    // creating `customer_payment_method` table.
    Schema::create('customer_payment_method', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('customer_id');
      $table->unsignedInteger('payment_method_id');
      $table->string('card_number')->comment('card number used for the payment');
      $table->string('expiry_date')->comment('card expiry date');
      $table->string('security_number')->comment('card security number');
      $table->json('other_details')->nullable()->comment('other details if any');

      $table->foreign('customer_id')->references('id')->on('customers');
      $table->foreign('payment_method_id')->references('id')->on('payment_methods');
    });

    // creating `location_sales` table.
    Schema::create('location_sales', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('location_id')->comment('this record belong to this location.');
      $table->date('date')->nullable()->comment('information of the date.');
      $table->string('type')->comment('type of record ["retail", "service"].');
      $table->decimal('total', 12, 2)->default(0.00)->comment('total sales of the type.');
      $table->timestamps();

      $table->foreign('location_id')->references('id')->on('locations');
    });

    // creating `customer_sales` table.
    Schema::create('customer_sales', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('customer_id')->comment('this record belong to this location.');
      $table->date('date')->nullable()->comment('information of the date.');
      $table->string('type')->comment('type of record ["retail", "service", "tip"].');
      $table->decimal('total', 12, 2)->default(0.00)->comment('total sales of the type.');
      $table->timestamps();

      $table->foreign('customer_id')->references('id')->on('customers');
    });

    // creating `categories` table.
    Schema::create('categories', function (Blueprint $table) {
      $table->increments('id');
      $table->string('name');
      $table->string('slug')->nullable();
      $table->timestamps();
      $table->softDeletes();
    });

    // creating `products` table.
    Schema::create('products', function (Blueprint $table) {
      $table->increments('id');
      $table->string('title')->comment('title of the product.');
      $table->string('sub_title')->nullable()->comment('sub title of the product.');
      $table->string('brand')->nullable()->comment('brand of the product.');
      $table->string('code')->nullable()->comment('code/sku of the product.');
      $table->text('description')->nullable()->comment('description of the product.');
      $table->integer('price')->default(0)->comment('price of the product.');
      $table->timestamps();
      $table->softDeletes();
    });

    // creating `category_product` table.
    Schema::create('category_product', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('category_id');
      $table->unsignedInteger('product_id');

      $table->foreign('category_id')->references('id')->on('categories');
      $table->foreign('product_id')->references('id')->on('products');
    });

    // creating `product_attributes` table.
    Schema::create('product_attributes', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('product_id')->nullable();
      $table->string('field')->comment('name of the attribute of that product.');
      $table->string('value')->comment('value of the attribute of that product.');

      $table->foreign('product_id')->references('id')->on('products');
    });

    // creating `product_images` table.
    Schema::create('product_images', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('product_id')->nullable();
      $table->text('url')->comment('image of that product.');
      $table->integer('order')->nullable()->comment('order of the image of that product.');

      $table->foreign('product_id')->references('id')->on('products');
    });

    // creating `location_product` table.
    Schema::create('location_product', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('location_id')->comment('name of the location.');
      $table->unsignedInteger('product_id')->comment('name of the product.');
      $table->integer('quantity')->comment('the quantity of product belongs to the location.');
      $table->integer('price')->default(0)->comment('price of the product.');

      $table->foreign('location_id')->references('id')->on('locations');
      $table->foreign('product_id')->references('id')->on('products');
    });

    // creating `orders` table.
    Schema::create('orders', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('location_id')->comment('order booked from this location.');
      $table->unsignedInteger('customer_id')->comment('order belong to this customer.');
      $table->string('code')->comment('order number to show in UI.');
      $table->string('status')->comment('status of the order. could be one out of ["PLACED", "IN-QUEUE", "PROCESSING", "PROCESSED", "CANCELLED"].');
      $table->unsignedInteger('payment_id')->nullable()->comment("payment details if order is paid");
      $table->timestamp('refund_date')->nullable()->comment('last date of refund.');
      $table->integer('refund_amount')->default(0)->comment('amount of refund.');
      $table->unsignedInteger('created_by')->nullable()->comment("staff/user who have created the order.");
      $table->timestamps();
      $table->softDeletes();

      $table->foreign('location_id')->references('id')->on('locations');
      $table->foreign('customer_id')->references('id')->on('customers');
      $table->foreign('payment_id')->references('id')->on('payments');
      $table->foreign('created_by')->references('id')->on('users');
    });

    // creating `order_items` table.
    Schema::create('order_items', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedInteger('order_id')->comment('order item belong to this order.');
      $table->unsignedInteger('product_id')->nullable()->comment('id of the product.');
      $table->decimal('rate', 12, 2)->default(0.00)->comment('rate of the product.');
      $table->integer('quantity')->default(0)->comment('quantity of the product.');

      $table->foreign('order_id')->references('id')->on('orders');
      $table->foreign('product_id')->references('id')->on('products');
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {

    // drop `order_items` table.
    Schema::dropIfExists('order_items');

    // drop `orders` table.
    Schema::dropIfExists('orders');

    // drop `location_product` table.
    Schema::dropIfExists('location_product');

    // drop `product_images` table.
    Schema::dropIfExists('product_images');

    // drop `product_attributes` table.
    Schema::dropIfExists('product_attributes');

    // drop `products` table.
    Schema::dropIfExists('products');

    // drop `customer_sales` table.
    Schema::dropIfExists('customer_sales');

    // drop `location_sales` table.
    Schema::dropIfExists('location_sales');

    // drop `customer_payment_method` table.
    Schema::dropIfExists('customer_payment_method');

    // drop `appointment_tag` table.
    Schema::dropIfExists('appointment_tag');

    // drop `tags` table.
    Schema::dropIfExists('tags');

    // drop `appointment_service` table.
    Schema::dropIfExists('appointment_service');

    // drop `appointments` table.
    Schema::dropIfExists('appointments');

    // drop `payments` table.
    Schema::dropIfExists('payments');

    // drop `payment_methods` table.
    Schema::dropIfExists('payment_methods');

    // drop `customers` table.
    Schema::dropIfExists('customers');

    // drop `sources` table.
    Schema::dropIfExists('sources');

    // drop `resources` table.
    Schema::dropIfExists('resources');

    // drop `location_service` table.
    Schema::dropIfExists('location_service');

    // drop `services` table.
    Schema::dropIfExists('services');

    // drop `location_user` table.
    Schema::dropIfExists('location_user');

    // drop `locations` table.
    Schema::dropIfExists('locations');

    // dropping column `role_id`
    if (Schema::hasColumn('users', 'role_id')) {
      Schema::table('users', function (Blueprint $table) {
        $table->dropForeign(['role_id']);
        $table->dropColumn('role_id');
      });
    }

    // drop `roles` table.
    Schema::dropIfExists('roles');
  }

}
