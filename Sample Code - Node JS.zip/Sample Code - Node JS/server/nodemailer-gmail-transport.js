"use strict";
var google = require('./google');
var config = require('config');
var logger = require('./log');

module.exports = {
  name: 'gmail',
  version: '1.0.0',
  send: function (mail, callback) {
    logger.log('send email:', mail.data);
    var input = mail.message.createReadStream();
    var messageId = (mail.message.getHeader('message-id') || '').replace(/[<>\s]/g, '');
    var bufs = [];
    var error = null;
    input.on('data', function(d){ bufs.push(d); });
//    input.pipe(process.stdout);
    input.on('error', err => {
      error = err;
      callback(err);
    });
    input.on('end', function() {
      if (error)
        return;
      var buf = Buffer.concat(bufs);
      google
        .sendEmail(buf, mail.data.from.replace(/^.*<(.+@.+)>.*$/, '$1'))
        .then(ret => {
          logger.log('email send ret:', ret);
          ret.messageId = messageId;
          callback(null, ret);
        })
        .catch(err => {
          logger.warn('email send failed:', err, err.stack);
          callback(err);
        });
    });
  }
}