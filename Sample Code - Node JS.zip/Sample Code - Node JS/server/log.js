var logger = require('tracer').colorConsole({
  inspectOpt: {
    depth : 0 // do not expand inner objects to avoid excessive logging.
  }
});

module.exports = logger;