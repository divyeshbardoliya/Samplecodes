"use strict";
var slack;
var realgeeks;

const CronJob = require('cron').CronJob;

var fb = require('./firebase');
var logger = require('./log');
var sendtext = require('./sendtext');
var talkus = require('./talkus');
const leadtag = require("./leadtag");
const flows = require("./flows");
const crm = require('./crm')
const lead = require('./lead');
const Bottleneck = require('bottleneck')

if (process.env.NODE_ENV !== "sandbox") {
  slack = require('./slack');
  realgeeks = require('./realgeeks');
}

// test cron job
console.log('Before job instantiation');
const job = new CronJob('*/5 * * * * *', async function() {
  let resp = await talkus.talkusAgentJob();
});

const dailyWaitTagRemoveJob = new CronJob('0 55 23 * * *', function() {
//CRON Job for remove expire tags from lead. It will run every day 11:55pm.
  leadtag.removeWaitTagsFromLeadJob();
});

// Setting time as UTC-04:00 = 12 UTC = 08:00 am
const dailyAgentCallCount = new CronJob('0 0 12 * * *', function () {
// CRON Job for remove expire tags from lead. It will run every day 08:00am
  const limiter = new Bottleneck({
    maxConcurrent: 1,
    minTime: 20000
  })
  crm.interceptor({ call: 'getUsers' }).then((responseData) => {
    let usersResponse = JSON.parse(responseData)
    const allUsers = usersResponse.users
    for (var i = 0; i < allUsers.length; i++) {
      limiter.schedule(lead.getAgentCalls, allUsers[i].id, allUsers[i].name).then((response) => {})
    }
  })
})

const everyMinReminderCalls = new CronJob('0 * * * * *', function () {
// CRON Job for checking reminderCalls for Agents every 1 minute
  console.log('checkReminderCalls jusr ran')
  realgeeks.checkReminderCalls()
})

// start cron job
job.start();
dailyWaitTagRemoveJob.start();
dailyAgentCallCount.start()
everyMinReminderCalls.start()

module.exports = {
  init: function (app) {

    return fb.initCfg.then(function (cfg) {
      if (process.env.NODE_ENV !== "sandbox") {
        slack.init(app);
        lead.init(app, cfg);
        realgeeks.init(app, cfg);
        flows.init(app, cfg);
      }

      sendtext.init(app);
      talkus.init(app);

      if (process.env.UPGRADE) {
        Promise.resolve().then(() => {
          var sourceNames = {
            fg: '',
          };
          var sourceName = sourceNames[process.env.NODE_ENV];
        })
          .catch(err => {
            logger.warn(err, err.stack);
          })
          .then(() => {
            process.exit(0);
          });
      }
    });
  }
};
