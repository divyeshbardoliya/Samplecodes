var nunjucks = require('nunjucks');
var numeral = require('numeral');
var _ = require('lodash');
var logger = require('./log');

var plainRender = nunjucks.configure({
  autoescape: false
});
var htmlRender = nunjucks.configure({
  autoescape: true
});

function money(n, fmt) {
  return numeral(n).format(fmt || '$0,0[.]00');
}

function firstName(str) {
  // if it's a email, just return empty
  if (str.indexOf('@') >= 0)
    return '';
  var parts = str.split(/\s+/);
  return parts[0];
}

function lastName(str) {
  if (str.indexOf('@') >= 0)
    return '';
  var parts = str.split(/\s+/);
  if (parts.length == 1)
    return '';
  return parts.pop();
}

plainRender.addFilter('money', money);
htmlRender.addFilter('money', money);
plainRender.addFilter('firstName', firstName);
htmlRender.addFilter('firstName', firstName);
plainRender.addFilter('lastName', lastName);
htmlRender.addFilter('lastName', lastName);

function render(input, context, inPlaceRender) {
  if (typeof input == 'string') {
    var m = input.match(/^`\s*(.+)\s*`$/);
    if (m) {
      if (m[1][0] == '`' && m[1][m[1].length-1] == '`') {
        input = '{{' + m[1].slice(1, -1) + '|dump}}';
      }
      else {
        input = m[1];
      }
      //logger.debug(input, context);
      var output = plainRender.renderString(input, context);
      //logger.debug(output);
      return JSON.parse(output);
    }
    return plainRender.renderString(input, context);
  }
  else if (typeof input == 'object') {
    if (!inPlaceRender)
      input = _.clone(input);
    for (var key in input) {
      var val = input[key];
      input[key] = render(val, context);
    }
  }
  return input;
}

module.exports = {
  render: render,
  plainRender: plainRender,
  htmlRender: htmlRender
};