"use strict";
const axios = require('axios');
const fb = require('./firebase');

let errorResponse = (err, res, type) => {
  if (type == 'html')
    return res.status(400).send(err.toString());
  let errJSON = {
    error: err.toString()
  };
  return res.status(400).json(errJSON);
};

const shortenUrl = (long_url) => {
  const {username, password, domain} = fb.cfg.yourls;
  return axios.get(`http://${domain}/yourls-api.php?username=${username}&password=${password}&action=shorturl&format=json&url=${long_url}`).catch((error) =>{
    console.log('error occur in shorturls');
    return null;
  });
};

const getAgentId = async (agentName, source) => {
  let agentId = '';
  let new_Source = getDomain(source);
  if (agentName && agentName != "null") {
    agentId = await fb.ref.child(`config/yourls/agentRGIds/${new_Source}/${agentName}`).once("value").then((snap)=>{
      return snap.val();
    }).catch(( error ) => {
      console.log('Error',error.message);
      return null;
    });
  }
  if (!agentId) {
    let monitorFUBLeadOwner = fb.cfg.georgiaar.monitorFUBLeadOwner;
    if (Array.isArray(monitorFUBLeadOwner)) {
      agentId = fb.cfg.yourls.agentRGIds[fb.cfg.yourls.defaultSource][fb.cfg.georgiaar.monitorFUBLeadOwner[0]];
    } else {
      agentId = fb.cfg.yourls.agentRGIds[fb.cfg.yourls.defaultSource][fb.cfg.georgiaar.monitorFUBLeadOwner];
    }
  }
  return agentId;
};

const getAllAgents = async (source) => {
  let AllagentId = '';
  let new_Source = getDomain(source);
  if (source && source != "null") {
    AllagentId = await fb.ref.child(`config/yourls/agentRGIds/${new_Source}`).once("value").then((snap)=>{
      return snap.val();
    }).catch(( error ) => {
      console.log('Error',error.message);
      return null;
    });
  }
  if (!AllagentId) {
    AllagentId = fb.cfg.yourls.agentRGIds[fb.cfg.yourls.defaultSource];
  }
  return AllagentId;
};

const getDomain = (source) => {
  source = source.toLowerCase();
  const re1 = new RegExp('https://www.|https://|http://www.|http://|www.');
  const re2 = new RegExp('\\.(.*)');
  let newSource = source.replace(re1, '');
  newSource = newSource.replace(re2, '');
  return newSource;
};

const getLongUrl = (longUrl) => {
  if(decodeURIComponent(longUrl).toLowerCase()!=="undefined" && decodeURIComponent(longUrl).toLowerCase()!=="null") {
    const {username, password, domain} = fb.cfg.yourls;
    return axios.get(`http://${domain}/yourls-api.php?username=${username}&password=${password}&action=expand&format=json&shorturl=${longUrl}`).catch((error)=>{
      console.log('Error occur in long url')
      return null;
    });
  }
};

module.exports = {
  errorResponse: errorResponse,
  objectValues: obj => {
    return Object.keys(obj).map(key => obj[key]);
  },
  createUrl: (rootURL, queryParamsMap) => {
    let queryParamsString = "";
    Object.keys(queryParamsMap).forEach((key) => {
      queryParamsString = queryParamsString + "&" + key + "=" + queryParamsMap[key];
    });
    queryParamsString = rootURL.endsWith("&") ? (queryParamsString.substring(1, queryParamsString.length)) : queryParamsString;

    return rootURL+queryParamsString;
  },
  shortenUrl,
  getAgentId,
  getLongUrl,
  getAllAgents,
};