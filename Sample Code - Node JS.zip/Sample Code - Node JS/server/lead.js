"use strict";
let fb = require('./firebase');
let logger = require('./log');
let errorResponse = require('./utils').errorResponse;
let config = require('config');
let _ = require('lodash');
let random = require("random-js")();
let jsonDiff = require('json-diff');
let addrs = require("email-addresses");
let slack = require('./slack');
let geocode = require('./geocode');
let crm = require('./crm');
let nunjucks = require('./nunjucks');
let moment = require('moment-timezone');
let Promise = require('bluebird');
let Queue = require('./queue');
let realgeeks = require('./realgeeks');
let axios = require('axios');
let querystring = require('querystring');
const twilioClient = require('./twilio');
let util = require('./utils');
const db = require('../models')
const Bottleneck = require('bottleneck')
const Sequelize = require('sequelize')
const SendtextLead = require('./sendtext');
const Op = Sequelize.Op

let claimQueue = new Queue(1);

let systemName = "PeterLeadBot";
let sendtextWebhookUrl = config.webRootUrl + "/fub/peopleCreatedEvent";

function localMoment(d) {
  return moment(d).tz(fb.cfg.timezone);
}

let leadsRef = fb.ref.child('leads');
let leadCommonDataRef = fb.ref.child('leadCommonData')
let nextLeadNoRef = fb.cfgRef.child('lead/nextLeadNo');
let newLeadsRef = leadsRef.orderByChild('slackSent').equalTo(null);
const scheduledCallsRef = fb.ref.child('scheduledCalls');
let ggLeadsRef = fb.ref.child('georgiaar');
let reminderCalls = fb.ref.child('reminderCalls')
//let newLeadsLoaded = false;

// to prevent from double response when multiple agents click the button.
let assignedLeads = {};
let slackUserLastSuccessClaim = {};

/* fix msl -> mls for leads */
/*
if (true) {
  let mslLeadNoRef = leadsRef.orderByChild('msl').startAt("0");
  mslLeadNoRef.on('child_added', function(snap) {
    let lead = snap.val();
    logger.log(snap.key, lead.msl);
    snap.ref.update({
      mls: lead.msl,
      msl: null
    }).then(function() {
      logger.log(snap.key, lead.msl, 'updated to mls');
    });
  });
}
*/
fb.events.on('cfgLoaded', () => {
  if (config.processLeads) {
    newLeadsRef.once('value', function (snap) {
      console.log('***newLeadsRef once value')
      // delay start to check rebroadcasting
      //if (!newLeadsLoaded)
      setTimeout(checkAndRebroadcastLeadsToSlackThenSchedule, 60000);
      //newLeadsLoaded = true;
    });
    newLeadsRef.on('child_removed', function (snap) {
      logger.log('lead marked slack sent:', snap.key, snap.val());
    });
    newLeadsRef.on('child_added', newLeadsMethod);
  }
});

function newLeadsMethod(snap) {
  let lead = snap.val();
  logger.log('lead:', snap.key, lead);
  return Promise.resolve().then(function () {
    // scraper firing block
    if (lead.mls && !lead.scrapedData && fb.cfg.lead.invokeScraper) {
      let mls = String(lead.mls);
      let previewUrl = null;
      if (mls.startsWith("6")) {
        previewUrl = "https://www.methodatlanta.net/property/" + mls;
      } else if (mls.startsWith("8")) {
        previewUrl = "https://www.theatlantamls.com/property/" + mls;
      }

      // call the scraper webhook
      axios.post('http://206.189.188.109:5000/webhook', querystring.stringify({
        mls: lead.mls,
        leadid: snap.key
      }), {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }).then((resp) => {
        logger.log("webhook response: ", resp.data);
        // write the scraped data to the lead
        delete resp.data['leadid'];
        delete resp.data['status'];
        snap.ref.update({
          scrapedData: resp.data,
          previewUrl: previewUrl
        }).then(() => {
          snap.ref.once('value').then((leadSnap) => {
            logger.log("leadKey: ", leadSnap.key);
            logger.log("***** leadValue on /webhook POST: ", leadSnap.val());
            let assignedTo = leadSnap.val().assignedTo;
            logger.log('***** assignedTo on /webhook POST', assignedTo);
            if (!!assignedTo) {
              // send message to agent
              logger.log('***** assignedto condition');
              let rSlack = require('slack');
              let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken })

              return slack.findUserByFullName(assignedTo).then(function (slackUser) {
                if (slackUser) {
                  let params = nunjucks.render(config.slack.scraperAssignmentMsg, {
                    token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
                    user: slackUser.id,
                    channel: fb.cfg.slack.leadsChannel,
                    lead: leadSnap.val()
                  });
                  Slack.chat.postEphemeral(params)
                    .then((response) => {
                      logger.log("postEphemeralToLeads", response);
                    }).catch((err) => {
                    logger.log("postEphemeralToLeadsErr", err);
                  });
                }
                // otherwise log message and agent's name
                logger.warn("no agent found ", assignedTo, leadSnap.key);
              });
            }
          });
        })
      }).catch((err) => {
        logger.log("Error sending webhook request for scraper params:", lead.mls, lead.key);
        logger.log("Error sending webhook request for scraper:", err, { params: { mls: lead.mls, leadid: snap.key } });
      });
    } else {
      logger.log('lead without mls: ', snap.key);
    }

    if (!lead.name) {
      logger.warn('detected child_added with incomplete lead info, retrieve full lead again ...');
      return snap.ref.once('value').then(function (snap) {
        let lead = snap.val();
        logger.log('retrieved lead:', lead);
        return lead;
      });
    }
    return lead;
  }).then(function (lead) {
    if (lead.address && !lead.zipCode) {
      let m = lead.address.match(/\d{5}$/);
      if (m)
        lead.zipCode = m[0];
    }
    lead.name = lead.name.replace(/@.*/, '');
    lead.id = snap.key;

    if (lead.message && fb.cfg.lead.ignoreMessagePattern && lead.message.match(fb.cfg.lead.ignoreMessagePattern)) {
      return snap.ref.update({
        slackSent: 'rentIgnored'
      }).then(function () {
        logger.log('lead ' + snap.key + ' marked rent ignored');
        // finally this will return undefined
      });
    }

    if (lead.address) {
      return geocode.geocode(lead).then(function (geoInfo) {
        lead.street = ((geoInfo.streetNumber || '') + ' ' + (geoInfo.streetName || '')).trim();
        lead.city = geoInfo.city;
        lead.state = geoInfo.administrativeLevels.level1short;
        lead.zipCode = geoInfo.zipcode || lead.zipCode;
        return snap.ref.update({
          street: lead.street,
          city: lead.city,
          state: lead.state,
          zipCode: lead.zipCode
        }).then(function () {
          logger.log('lead ' + snap.key + ' geo info saved');
          return lead;
        });
      }).catch(function (err) {
        logger.warn('geocode lead address failed:', err, err.stack);
        return lead;
      });
    }
    return lead;
  }).then(function (lead) {
    if (!lead)
      return;

    // XXX: every lead we should assign them an id, from 1000 begin
    //      we need to it with transcation, to avoid duplicated id.
    //      we also need to display the id some where.

    if (!lead.no) {
      return nextLeadNoRef.transaction(function (nextLeadNo) {
        nextLeadNo = nextLeadNo || 999;
        return nextLeadNo + 1;
      }, undefined, false)
        .then(function (ret) {
          let nextLeadNo = ret.snapshot.val();
          logger.log('nextLeadNo:', ret.error, ret.committed, nextLeadNo);
          lead.no = nextLeadNo - 1;
          return lead;
        });
    }
    return lead;
  }).then(function (lead) {
    if (lead)
      return sendLeadToSlack(lead);
  }).catch(function (err) {
    logger.warn('error during process new lead:', err, err.stack);
  });

  function sendLeadToSlack(lead, sendToPresetAgent, sendToTaddle) {
    logger.warn('***** send lead to slack:', lead, sendToPresetAgent);
    logger.warn('lead.channel', lead.channel);
    console.log('***** lead:', lead);
    let emailTochannel = false;
    let channel = lead.channel;
    if (channel) {
      sendToPresetAgent = false;
    }
    else if (sendToPresetAgent) {
      channel = sendToPresetAgent;
    }
    else {
      if (lead.mls && fb.cfg.lead.mlsAgentMap && lead.useMLSAgent !== false && sendToPresetAgent !== false) {
        // check the mls with the config data, see whether it belong to certain agent.
        let agent = fb.cfg.lead.mlsAgentMap[lead.mls];
        if (agent) {
          // XXX: then we query the agent's slack name, or id, anyway.
          logger.warn('detected preset MLS -> agent:', lead.mls, agent);
          return slack.findUserByFullName(agent).then(function (slackUser) {
            if (slackUser)
              return sendLeadToSlack(lead, '@' + slackUser.name, true);
            return sendLeadToSlack(lead, false);
          });
        }
      }
      if (!channel && fb.cfg.lead.sourceToChannel) {
        [lead.forwardedFrom, lead.from].forEach(from => {
          if (from) {
            // XXX: try the lead from email address first.
            let addr = addrs.parseOneAddress(from);
            if (addr) {
              channel = channel || fb.cfg.lead.sourceToChannel[fb.toFK(addr.address.toLowerCase())];
            }
          }
        });
        if (lead.source)
          channel = channel || fb.cfg.lead.sourceToChannel[fb.toFK(lead.source)];
        if(channel && !_.get(lead,'agentSourced')) {
          emailTochannel=true;
        }
      }
      if (fb.cfg.lead.priceToChannel && lead.price) {
        for (let ruleName in fb.cfg.lead.priceToChannel) {
          let rule = fb.cfg.lead.priceToChannel[ruleName];
          let matchRule = true;
          for (let op in rule) {
            if (op === 'channel')
              continue;
            if (op === 'lt' && lead.price >= rule[op]
              || (op === 'lte' || op === 'le') && lead.price > rule[op]
              || op === 'gt' && lead.price <= rule[op]
              || (op === 'gte' || op === 'ge') && lead.price < rule[op]) {
              matchRule = false;
              break;
            }
          }
          if (matchRule && rule.channel) {
            channel = channel || rule.channel;
            logger.warn('apply price channel rule:', lead.price, rule);
          }
        }
      }
      if (!lead.price && fb.cfg.lead.noPriceChannel)
        channel = channel || fb.cfg.lead.noPriceChannel;
      if (fb.cfg.lead.zipCodeToChannel)
        channel = channel || fb.cfg.lead.zipCodeToChannel[lead.zipCode] || fb.cfg.lead.zipCodeToChannel[lead.city] || fb.cfg.lead.zipCodeToChannel.default;
      channel = channel || fb.cfg.lead.defaultChannel;
    }
    let channelEncoded = fb.toFK(channel);
    // remember the first timestamp of the slack message sent to each channel
    let broadcastTimes = 0; // current times which already broadcasted
    if (lead.slackChannelSent && lead.slackChannelSent[channelEncoded])
      broadcastTimes = lead.slackChannelSent[channelEncoded].broadcastTimes;
    let rebroadcastRule = null;
    let nextReboardcastRule = null;
    if (!lead.assignedTo && fb.cfg.lead.rebroadcast && fb.cfg.lead.rebroadcast.channels && fb.cfg.lead.rebroadcast.channels[channelEncoded] && fb.cfg.lead.rebroadcast.rules) {
      // lead was sent to a channel which we do the rebroadcast.
      // let's check rebroadcast rules, and setup the rebroadcast timestamp
      for (let k in fb.cfg.lead.rebroadcast.rules) {
        let rule = fb.cfg.lead.rebroadcast.rules[k];
        if (rule.broadcastTimes == broadcastTimes) {
          if (rule.channel && rule.channel != channel && !rule.channel[channelEncoded] || !rule.duration)
            continue;
          rebroadcastRule = rule;
          // now the rule either apply to all channels or the current channel
          //break;
        }
        else if (rule.broadcastTimes == broadcastTimes + 1) {
          if (rule.channel && rule.channel != channel && !rule.channel[channelEncoded] || !rule.duration)
            continue;
          nextReboardcastRule = rule;
          // now the rule either apply to all channels or the current channel
          //break;
        }
      }
    }
    // XXX: for the same lead, to prevent double send to slack
    return snap.ref.once('value').then(snap => snap.val()).then(val => {
      // double check lead status before send to slack
      if (!val) {
        logger.warn('lead is no longer exists in firebase:', snap.key);
        return;
      }
      if (!val.existingLeadBroadCast && val.slackSent) {
        logger.warn('lead was already sent to slack:', val);
        return;
      }
      const sendingSlack = () => {
        logger.warn('***** sending slack message to:', channel, 'with lead:', lead);
        return slack
          .send('newLead', {
            lead: lead,
            hideFields: fb.cfg.lead.hideFields || {},
            channel: channel
          }, async function (slackMsg, context) {
            // for no property case message, remove price and address fields
            //if (!lead.address)
            //  slackMsg.attachments[0].fields = slackMsg.attachments[0].fields.slice(0, -2);

            if(channel.startsWith('@')) {
              slackMsg.attachments[0].actions = [
                {
                  "name": "initiateCall",
                  "text": "Initiate Call",
                  "type": "button",
                  "value": "initiateCall"
                },
                {
                  "name": "notInterested",
                  "text": "I don't want to/can’t service this lead",
                  "type": "button",
                  "value": "notInterested"
                }
              ];
            }

            if(channel === fb.cfg.crm.taddleChannel) {
              let leadInCrm = await findLeadInCrm(lead);
              slackMsg.attachments[0].fields.push(
                {
                  "title": "Assigned To",
                  "value": (leadInCrm && leadInCrm.assignedTo) || (lead && lead.assignedTo) || 'N/A',
                  "short": true,
                },
                {
                  "title": "Stage",
                  "value": (leadInCrm && leadInCrm.stage) || 'N/A',
                  "short": true,
                },
                {
                  "title": "Lead Link",
                  "value": (lead.idInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${lead.idInCrm}|client>`) ||
                    (leadInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${leadInCrm.id}|client>`) ||
                    'N/A',
                  "short": true,
                },
              );
              slackMsg.attachments[0].actions = [
                {
                  "name": "sendToChannel",
                  "text": "Send to channel",
                  "type": "button",
                  "value": "sendToChannel"
                }
              ];
            }

            if (rebroadcastRule && rebroadcastRule.message) {
              slackMsg.text = nunjucks.render(rebroadcastRule.message, context);
            }
          })
          .then(function (ret) {

            let leadJson = {
              leadId: lead.id,
              name: lead.name,
              city: lead.city,
              zip: lead.zipCode,
              price: lead.price,
              broadcast_date: Date.now()
            }
            db.lead.create(leadJson).then(result => console.log('Adding mysql broadcast record for id ', lead.id))

            console.log('slack new lead msg ' + snap.key + ' ret:', ret);
            console.log('message : ',ret.message);
            return snap.ref.transaction(val => {
              val = val || {};
              val.no = lead.no;
              val.slackChannelSent = val.slackChannelSent || {};
              let slackSent = val.slackChannelSent[sendToPresetAgent ? '@' : channelEncoded] = val.slackChannelSent[sendToPresetAgent ? '@' : channelEncoded] || {};
              slackSent.broadcastTimes = broadcastTimes + 1;
              slackSent.channel = channel;
              slackSent.channelId = ret.channel;
              slackSent.firstSentAt = slackSent.firstSentAt || fb.NOW;
              slackSent.lastSentAt = fb.NOW;
              slackSent.scheduleRebroadcast = nextReboardcastRule ? Date.now() + nextReboardcastRule.duration * 1000 : null;
              if (sendToPresetAgent) {
                val.useMLSAgent = sendToPresetAgent;
              }
              if(emailTochannel) {
                val.agentSourced = true;
              }
              if (ret.ts) {
                val.slackSent = slackSent.slackSent || {};
                val.slackSent[ret.ts.replace('.', '')] = ret.channel;
                if(channel === fb.cfg.crm.taddleChannel) {
                  val.taddleSlackSent = {channel: ret.channel, ts: ret.ts};
                }
              }
              else {
                val.slackSent = fb.NOW;
              }
              val.firstSlackSentAt = val.firstSlackSentAt || fb.NOW;
              val.lastSlackSentAt = fb.NOW;
              return val;
              /*let updateObj = {
                no: lead.no
              };
              // all preset agent we do the rebroadcast, so let them use the same '@' as channel here to make it unique and searchable.
              updateObj['slackChannelSent/' + (sendToPresetAgent ? '@' : channelEncoded)] = {
                broadcastTimes: broadcastTimes+1, // add one time to the broadcast times
                channel: channel,
                lastSentAt: fb.NOW,
                scheduleRebroadcast: nextReboardcastRule ? Date.now() + nextReboardcastRule.duration*1000 : null
              };
              if (sendToPresetAgent) {
                updateObj.useMLSAgent = sendToPresetAgent;
              }

              if (ret.ts) {
                updateObj['slackSent/' +  ret.ts.replace('.', '')] = ret.channel;
              }
              else {
                updateObj.slackSent = fb.NOW;
              }
              logger.log('update lead:', updateObj);*/
            }, undefined, false)
              .then(function (ret) {
                logger.log('lead ' + snap.key + ' marked slack sent:', ret.committed, ret.snapshot.val());
              });
          })
          .catch(function (err) {
            logger.warn('send new lead to slack failed:', err, err.stack);
          });
      };

      if (sendToTaddle){
        slack
          .send('newLead', {
            lead,
            hideFields: fb.cfg.lead.hideFields || {},
            channel: fb.cfg.crm.taddleChannel
          }, async function (slackMsg, context) {
            console.log(slackMsg, context);
            // for no property case message, remove price and address fields
            //if (!lead.address)
            //  slackMsg.attachments[0].fields = slackMsg.attachments[0].fields.slice(0, -2);
              slackMsg.attachments[0].actions = [
                {
                  "name": "sendToChannel",
                  "text": "Send to channel",
                  "type": "button",
                  "value": "sendToChannel"
                }
              ];
              let leadInCrm = await findLeadInCrm(lead);
              slackMsg.attachments[0].fields.push(
                {
                  "title": "Assigned To",
                  "value": (leadInCrm && leadInCrm.assignedTo) || (lead && lead.assignedTo) || 'N/A',
                  "short": true,
                },
                {
                  "title": "Stage",
                  "value": (leadInCrm && leadInCrm.stage) || 'N/A',
                  "short": true,
                },
                {
                  "title": "Lead Link",
                  "value": (lead.idInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${lead.idInCrm}|client>`) ||
                    (leadInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${leadInCrm.id}|client>`) ||
                    'N/A',
                  "short": true,
                },
              );

            if (rebroadcastRule && rebroadcastRule.message) {
              slackMsg.text = nunjucks.render(rebroadcastRule.message, context);
            }
          }).then(ret => {
          snap.ref.transaction(val => {
            val = val || {};
            if (ret.ts) {
              val.taddleSlackSent = {
                channel: ret.channel,
                ts: ret.ts
              };
            }
          }).then().catch((error) => {
            console.log('error in sendToTaddle transaction', error);
          });
        })
          .catch((err) => {
              logger.warn('send lead to Taddle channel failed', err, err.stack);
          });
      }

      logger.log('##=> lead  email :',lead.email,'phone :',lead.phone);
      crm.interceptor({ call: 'searchLeadInfo', searchQuery: { email: encodeURIComponent(lead.email), phone: lead.phone }, ignoreLogs: false, system: systemName }).then(function (info) {
        //crm.searchLeadInfo({email: encodeURIComponent(lead.email), phone: lead.phone},false,systemName).then(function (info) {
        console.log('##=> search lead =>', info.people);
        if (lead.reBroadcast || (lead.assignedTo === undefined && lead.reassignFrom === undefined || info.people.length) && !lead.existingLeadBroadCast) {
          console.log('##=> inside assignedTo undefined condition');
          logger.log('reBroadcast:-',lead.reBroadcast);
          if(lead.reBroadcast) {
            snap.ref.child('reBroadcast').remove()
              .then((res)=> {
                logger.log('reBroadcast set to null successfully for',lead.reBroadcast)
              }).catch(error => {
              logger.log('reBroadcast set to null failed',error)
            });
          }

          if (info.people.length && info.people[0].assignedTo && !_.includes(fb.cfg.georgiaar.monitorFUBLeadOwner, info.people[0].assignedTo)) {
            console.log('new id in crm : ', info.people[0].id);
            snap.ref.update({
              idInCrm: info.people[0].id,
              reBroadcast: null
            }).then((res) => {
              console.log('done updating', res);
            }).catch((error) => {
              console.log('error in transaction : ', error);
            });

            slack.findUserByFullName(info.people[0].assignedTo).then((slackUser) => {
              console.log('##=> found slack agent name =>', slackUser);
              console.log('###=>', lead); //temp log please remove.
              lead.message = lead.message ? lead.message + ` <${fb.cfg.crm.siteUrl}/2/people/view/${info.people[0].id}|${lead.email}>`:
                              ` <${fb.cfg.crm.siteUrl}/2/people/view/${info.people[0].id}|${lead.email}>`;
              let isRgSource = realgeeks.isRGSource(info.people[0].source);
              let excludedUsers = fb.cfg.slack.excludedUsers;
              let isExcludedUser = excludedUsers && excludedUsers[info.people[0].assignedTo];
              let timeStamp = isRgSource ? fb.cfg.slack.waitTime.RGwaitTime : fb.cfg.slack.waitTime.RealtorWaitTime;
              slack
                .send('newLead', {
                  lead,
                  hideFields: fb.cfg.lead.hideFields || {},
                  channel: '@' + slackUser.name
                }, function (slackMsg, context) {
                  // for no property case message, remove price and address fields
                  //if (!lead.address)
                  //  slackMsg.attachments[0].fields = slackMsg.attachments[0].fields.slice(0, -2);

                  if(!isExcludedUser && (isRgSource || info.people[0].source.toLowerCase()==='realtor.com')) {
                    slackMsg.text = `You have ${timeStamp / 60} minutes to click the Initiate Call button before the ISA calls the lead.`;
                  }

                  slackMsg.attachments[0].actions = [
                    {
                      "name": "initiateCall",
                      "text": "Initiate Call",
                      "type": "button",
                      "value": "initiateCall"
                    },
                    {
                      "name": "notInterested",
                      "text": "I don’t want/can’t service this lead",
                      "type": "button",
                      "value": "notInterested"
                    }
                  ];

                  if (rebroadcastRule && rebroadcastRule.message) {
                    slackMsg.text = nunjucks.render(rebroadcastRule.message, context);
                  }
                })
                .then(function (agentRet) {
                  logger.log("##>agent slacksent ret",agentRet);
                  snap.ref.transaction(val => {
                    val = val || {};
                    if (agentRet.ts) {
                      val.agentSlackSent = {
                        channel: agentRet.channel,
                        ts: agentRet.ts
                      };
                      if(!isExcludedUser) {
                        val.agentAllSlackSent = val.agentAllSlackSent || []
                        val.agentAllSlackSent.push({
                          channel: agentRet.channel,
                          ts: agentRet.ts
                        })
                      }
                    }
                    return val;
                  }).then(()=>{
                    if( !isExcludedUser && (isRgSource || info.people[0].source.toLowerCase()==='realtor.com')) {
                      logger.log('##=>TimeOut called isExcludedUser : ',isExcludedUser,'Assigned Agent : ',info.people[0].assignedTo);
                      handleRepeatLead(info.people[0],snap,timeStamp);
                    }
                  }).catch((error) => {
                    console.log('error in sendToTaddle transaction', error);
                  });
                });
              channel = fb.cfg.crm.taddleChannel;
              return sendingSlack();
            }).catch(() => console.log("couldn't find assigned agent in slack"));
          } else {
            return sendingSlack()
          }
        } else {
          return sendingSlack()
        }
      }).catch((error) => {
        console.log(error);
        return sendingSlack();
      });

    });
  }
};

function checkAndRebroadcastLeadsToSlackThenSchedule() {
  checkAndRebroadcastLeadsToSlack().catch(function (err) {
    logger.warn('checkAndRebroadcastLeadsToSlack failed:', err, err.stack)
  }).then(function () {
    setTimeout(checkAndRebroadcastLeadsToSlackThenSchedule, 60000);
  });
}

function checkAndRebroadcastLeadsToSlack() {
  // XXX: this function will be called every minutes.
  if (!fb.cfg.lead.rebroadcast || !fb.cfg.lead.rebroadcast.channels)
    return Promise.resolve();
  let nowTime = localMoment().format('HH:mm');
  let silentTime = fb.cfg.lead.rebroadcast.silentTime;
  //logger.log(nowTime, silentTime)
  if (silentTime) {
    if (silentTime.from <= silentTime.to) {
      if (nowTime >= silentTime.from && nowTime < silentTime.to)
        return Promise.resolve();
    }
    else {
      if (nowTime >= silentTime.from || nowTime < silentTime.to)
        return Promise.resolve();
    }
  }
  //logger.log('checkAndRebroadcastLeadsToSlack:', fb.cfg.lead.rebroadcast.channels);
  return Promise.mapSeries(Object.keys(fb.cfg.lead.rebroadcast.channels), function (channel) {
    //logger.log('check leads in channel ' + channel + ' to be rebroadcasted ...');
    let channelEncoded = fb.toFK(channel);
    return leadsRef.orderByChild('slackChannelSent/' + channelEncoded + '/scheduleRebroadcast').startAt(0).endAt(Date.now()).once('value').then(function (snap) {
      let leads = snap.val();
      if (leads) {
        // now we have leads to be rebroadcasted
        var leadIds = Object.keys(leads);
        logger.log(channel, leadIds.length, 'leads to be rebroadcasted:', leadIds);
        // XXX: so, how to rebroadcast a lead in a slack channel?
        // FIXME: by now, e.g. we can do, just delete then resend to a channel.
        // maybe, first check with the rebroadcast rule
        return Promise.mapSeries(leadIds, function (leadId) {
          let lead = leads[leadId];
          let leadRef = leadsRef.child(leadId);
          return Promise.resolve().then(() => {
            let updateObject = {};
            if (lead.assignedTo) {
              logger.log('no rebroadcast, lead was already assigned in crm:', lead);
              updateObject['slackChannelSent/' + channelEncoded + '/scheduleRebroadcast'] = null;
              return updateObject;
            }
            return leadRef
              .once('value')
              .then(snap => snap.val())
              .then(lead => {
                if (!lead.slackChannelSent || !lead.slackChannelSent[channelEncoded])
                  return;
                let broadcastTimes = lead.slackChannelSent[channelEncoded].broadcastTimes;
                let broadcastRule = null;
                for (let k in fb.cfg.lead.rebroadcast.rules) {
                  let rule = fb.cfg.lead.rebroadcast.rules[k];
                  if (rule.broadcastTimes == broadcastTimes) {
                    if (rule.channel && rule.channel != channel && !rule.channel[channelEncoded] || !rule.duration)
                      continue;
                    broadcastRule = rule;
                    break;
                  }
                }
                if (!broadcastRule) {
                  // no broadcast rule matched
                  logger.log('no rebroadcast, no rule currently match the lead:', lead);
                  updateObject['slackChannelSent/' + channelEncoded + '/scheduleRebroadcast'] = null;
                }
                else {
                  // a rule matched the lead.
                  if ((lead.slackChannelSent[channelEncoded].lastSentAt || lead.slackChannelSent[channelEncoded].firstSentAt) + broadcastRule.duration <= Date.now()) {
                    // duration matched.
                    // XXX: do the re-broadcast.
                    let changeChannelByRule = broadcastRule.newChannel && broadcastRule.newChannel != channel;
                    let channelToRebroadcast = broadcastRule.newChannel || channel;
                    let doRebroadcast = !broadcastRule.newChannel || broadcastRule.newChannel == channel;
                    return deleteLeadFromSlack(lead.no, channelToRebroadcast, doRebroadcast ? 'rebroadcast' : null).then(ret => {
                      if (changeChannelByRule && broadcastRule.messageToOldChannel) {
                        // the channel changed, and we have message need send to the old channel
                        return slack.api.chat.postMessage({
                          token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
                          channel: channel,
                          text: nunjucks.render(broadcastRule.messageToOldChannel, {
                            lead: lead,
                            channel: channel
                          }),
                          as_user: false
                        });
                      }
                    });
                  }
                  else {
                    updateObject['slackChannelSent/' + channelEncoded + '/scheduleRebroadcast'] = (lead.slackChannelSent[channelEncoded].lastSentAt || lead.slackChannelSent[channelEncoded].firstSentAt) + broadcastRule.duration;
                  }
                }
              })
              .then(ret => {
                return updateObject;
              });
          })
            .then(updateObject => {
              return leadRef.update(updateObject);
            })
            .catch(err => {
              logger.warn('rebroadcast lead failed:', leadId, lead, err, err.stack);
              return Promise.resolve().delay(1000);
            });
        });
      }
    });
  });
}

function deleteLeadFromSlack(leadNo, targetChannel, action) {
  let rebroadcast = action == 'rebroadcast';
  let reassign = action == 'reassign';
  // when reassign, we try to get the lead from FUB crm, and then save the reassignFrom field to the lead
  return leadsRef.orderByChild('no').equalTo(leadNo).once('value').then(function (snap) {
    let leads = snap.val();
    let leadId = Object.keys(leads)[0];
    let lead = leads[leadId];
    lead.id = leadId;
    logger.log('lead to delete:', leadId, lead);
    if (!lead) {
      throw new Error('Lead #' + leadId + ' not found.');
    }
    if (!targetChannel && (!lead.slackSent || typeof lead.slackSent != 'object')) {
      if (lead.slackSent == 'deleted')
        throw new Error('Lead #' + leadNo + ' was deleted already.');
      throw new Error('Lead #' + leadNo + ' was not sent to slack.');
    }
    if (reassign && lead.idInCrm) {
      return crm.interceptor({ call: 'getLeadInfo', leadId: lead.idInCrm, ignoreLogs: false, system: systemName }).then(function (info) {
      // return crm.getLeadInfo(lead.idInCrm, false, systemName).then(function (info) {
        lead.leadInCrm = info;
        return lead;
      }).catch(function (err) {
        logger.warn('retrieve crm lead failed:', err, err.stack);
        return lead;
      });
    }
    return lead;
  }).then(function (lead) {
    let slackSent = {};
    if (lead.slackSent && typeof lead.slackSent == 'object')
      slackSent = lead.slackSent;
    // XXX: slackSent is the ts => channel data mapping. we can use this to delete messages.
    return Promise.all(Object.keys(slackSent).map(function (ts) {
      return slack.api.chat.delete({
        token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
        ts: ts.slice(0, -6) + '.' + ts.slice(-6),
        channel: slackSent[ts]
      })
        .catch(err => {
          if (err.toString().indexOf('message_not_found' >= 0)) {
            logger.warn('ignore slack message missing when deletion:', slackSent[ts], ts, err, err.stack);
            return;
          }
          logger.warn('delete slack message failed:', slackSent[ts], ts, err, err.stack);
          throw err;
        });
    })).then(function (ret) {
      if (ret.length > 0)
        logger.log('delete lead message from slack ret:', ret);
      let leadRef = leadsRef.child(lead.id);
      delete assignedLeads[lead.id];
      let updateObj = {
        slackSent: 'deleted',
        deletedAt: fb.NOW
      };
      if (reassign && !lead.reassignFrom && !_.get(lead,'reassignFrom.length') && lead.leadInCrm && lead.leadInCrm.assignedTo) {
        updateObj.reassignFrom = [lead.leadInCrm.assignedTo];
      }
      // only if we are rebroadcasting, else we clear these timestamps
      if (!rebroadcast)
        updateObj.slackChannelSent = null;
      return leadRef.update(updateObj).then(function (ret) {
        logger.log('lead ' + leadNo + ' marked deleted:', ret);
        if (targetChannel) {
          // FIXME: what if the channel does not exists?
          //        we need check it anyway first.
          let updateObject = {
            slackSent: null,
            deletedAt: null,
            channel: targetChannel
          };
          if (lead.useMLSAgent)
            updateObj.useMLSAgent = false;  // we only use MLS Agent once, so once it's deleted, mark not use it any more
          if (targetChannel == 'AUTO')
            delete updateObject.channel;
          return leadRef.update(updateObject);
        }
        return ret;
      });
    });
  });
}

function init(app, cfg) {
  //checkAndRebroadcastLeadsToSlackThenSchedule();
  //slack.findUserByName('Lion U');
  app.post('/leadCmd', function (req, resp) {
    logger.log('got lead command req:', req.body);
    if (req.body.ssl_check)
      return resp.json({});
    if (req.body.token != fb.cfg.slack.token/* && req.body.token != fb.cfg.slack.cmdToken*/)
      return errorResponse(new Error('invalid token'), resp);
    let cmd = req.body;
    let today = localMoment().format('YYYY-MM-DD');
    let m = cmd.text.match(/^(sendtext)/);
    if (m) {
      if (!slack.allowCommand('sendtext', cmd.user_name))
        throw new Error('You are not allowed to run this command');

      let rSlack = require('slack');
      let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken })
      logger.log("req.body.token", req.body.token);
      logger.log("req.body.channel_id", req.body.channel_id);
      let optionGroups = [];
      let tagTexts = fb.cfg.georgiaar.tagTexts;
      let sendtextIndex = 0;
      _.forOwn(tagTexts, function (value, key) {
        if (key === "meta") {
          return;
        }
        let curOption = {};
        curOption["text"] = key;
        curOption["options"] = [];
        _.forOwn(value, function (value2, key2) {
          curOption.options.push({
            "text": doubleCurlyToDollar(value2).substring(0, 70),
            "value": sendtextIndex + "_" + key2
          })
        });
        // curOption.options.push({
        //   "text": "Add New",
        //   "value": sendtextIndex + "_n"
        // });

        optionGroups.push(curOption);
        sendtextIndex++;
      });

      optionGroups.push({
        text: "Add New",
        options: [
          {
            text: "add_new",
            "value": "add_new_" + (sendtextIndex + 1)
          }
        ]
      });
      logger.log("optionGroups: ", JSON.stringify(optionGroups));
      // let dialog = {
      //   "callback_id": "edit_sendtext_tag",
      //   "title": "Select Message To Edit",
      //   "submit_label": "Submit",
      //   "state":cmd.trigger_id,
      //   "elements": [
      //     {
      //       "label": "Choose message to edit",
      //       "name": "tagText",
      //       "type": "select",
      //       "option_groups": optionGroups
      //     }
      //   ]
      // };
      // Slack.dialog.open({
      //   token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
      //   dialog: dialog,
      //   trigger_id: cmd.trigger_id
      // }).catch(err => {
      //   logger.log("Error opening dialog", err);
      // }).then((re) => {
      //   logger.log("Re=", JSON.stringify(re.message));
      // });

      Slack.chat.postEphemeral({
        token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken, text: "Edit Sendtext Tag(s)", attachments: [
          {
            "text": "Select the tag to edit",
            "fallback": "Upgrade your Slack client to use messages like these.",
            "color": "3AA3E3",
            "attachment_type": "default",
            "callback_id": "edit_sendtext_tag",
            "actions": [
              {
                "name": "tag_list",
                "text": "Select the sendtext message to edit",
                "type": "select",
                "data_source": "static",
                "option_groups": optionGroups
              }
            ]
          }
        ], channel: req.body.channel_id,
        user: req.body.user_id
      }).catch(err => {
        logger.log("Error opening dialog", err);
      }).then((re) => {
        logger.log("Re=", JSON.stringify(re.message));
      });
      return resp.status(200).send("");
    }
    m = cmd.text.match(/^(move|reassign)\s+#?(\d+)\s+(\S+)\s*$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command:', m[2], m[3]);
      let slackResp = slack.webhook(cmd.response_url);
      Promise.resolve().then(function () {
        if (!slack.allowCommand('move', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        return deleteLeadFromSlack(+m[2], m[3], m[1]).then(function () {
          return {
            "text": "Lead #" + m[2] + " will be reassgined to channel " + m[3],
            "response_type": 'ephemeral'
          };
        });
      })
        .catch(function (err) {
          logger.warn('reassign lead on slack failed:', err, err.stack);
          return {
            "text": err.toString(),
            "response_type": 'ephemeral'
          };
        })
        .then(function (notifyMessage) {
          logger.log('notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('cmd result sent to slack action user:', cmd.user_name, ret);
          });
        });
      return resp.send('');
    }
    m = cmd.text.match(/^(remove|delete|del|kill)\s+#?(\d+)\s*$/);
    if (m) {
      // remove lead
      logger.log('got slack remove command:', m[2]);
      let slackResp = slack.webhook(cmd.response_url);
      Promise.resolve().then(function () {
        if (!slack.allowCommand('delete', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        return deleteLeadFromSlack(+m[2]).then(function () {
          return {
            "text": "Lead #" + m[2] + " deleted",
            "response_type": 'ephemeral'
          };
        });
      })
        .catch(function (err) {
          logger.warn('delete lead form slack failed:', err, err.stack);
          return {
            "text": err.toString(),
            "response_type": 'ephemeral'
          };
        })
        .then(function (notifyMessage) {
          logger.log('notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('cmd result sent to slack action user:', cmd.user_name, ret);
          });
        });
      return resp.send('');
    }
    m = cmd.text.match(/^(delay)(\s+(\d+)\s+@(\S+)\s*)?$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command:', m[3], m[4]);
      let slackResp = slack.webhook(cmd.response_url);
      Promise.resolve().then(function () {
        if (!slack.allowCommand('delay', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        if (!m[3] && !m[4]) {
          // no parameters, then we just list what we know
          let delayedUsers = [];
          if (fb.cfg.lead.claim.punishedUsers) {
            delayedUsers = delayedUsers.concat(Object.keys(fb.cfg.lead.claim.punishedUsers).map(user => '@' + user + ' is PUNISHED and waits ' + fb.cfg.lead.claim.punishedUsers[user] + ' seconds'));
          }
          if (fb.cfg.lead.claim.delayByMaxClaimPerDay && fb.cfg.lead.claim.delayByMaxClaimPerDay.delay && fb.cfg.lead.claim.delayByMaxClaimPerDay.maxClaimPerDay && fb.cfg.lead.claim.userPerDay) {
            delayedUsers = delayedUsers.concat(Object.keys(fb.cfg.lead.claim.userPerDay).map(uid => fb.cfg.lead.claim.userPerDay[uid]).filter(user => user.username && user.date === today && !user.uncapped && user.numClaimed - (user.credits || 0) >= fb.cfg.lead.claim.delayByMaxClaimPerDay.maxClaimPerDay).map(user => '@' + user.username + ' is CAPPED and waits ' + fb.cfg.lead.claim.delayByMaxClaimPerDay.delay + ' seconds'));
          }
          return {
            "text": (delayedUsers.length === 0 ? 'Currently no user is delayed' : delayedUsers.join('\n')) + '\nTo change punished user: /leadbot delay seconds @username\nTo uncap user: /leadbot uncap @username',
            "response_type": 'ephemeral'
          };
        }
        return fb.cfgRef.child('lead/claim/punishedUsers/' + m[4]).set(+m[3] || null).then(function () {
          return {
            "text": m[3] == '0' ? 'User @' + m[4] + ' now set undelayed' : 'User @' + m[4] + ' now set delayed ' + m[3] + ' seconds',
            "response_type": 'ephemeral'
          };
        });
      })
        .catch(function (err) {
          logger.warn('delay user failed:', err, err.stack);
          return {
            "text": err.toString(),
            "response_type": 'ephemeral'
          };
        })
        .then(function (notifyMessage) {
          logger.log('notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('cmd result sent to slack action user:', cmd.user_name, ret);
          });
        });
      return resp.send('');
    }
    m = cmd.text.match(/^(new)\s*$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command');
      return Promise.resolve().then(() => {
        if (!slack.allowCommand('new', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        return resp.json({
          "text": "<" + config.webRootUrl + "/newLead|Create new lead>",
          "response_type": 'ephemeral'
        });
      })
        .catch(err => {
          logger.warn('new lead cmd failed:', err, err.stack);
          return resp.json({
            "text": err.toString(),
            "response_type": 'ephemeral'
          });
        });
    }
    m = cmd.text.match(/^(uncap)\s+@(\S+)\s*$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command:', m[2]);
      let slackResp = slack.webhook(cmd.response_url);
      Promise.resolve().then(function () {
        if (!slack.allowCommand('uncap', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        // now get id by username
        return slack.findUserByName(m[2]).then(slackUser => {
          if (!slackUser)
            throw new Error('User ' + m[2] + ' not found.');
          return fb.cfgRef.child('lead/claim/userPerDay/' + slackUser.id).transaction(val => {
            val = val || {};
            if (today !== val.date) {
              val.date = today;
              val.claimed = {};
              val.numClaimed = 0;
              val.credits = null;
            }
            val.username = slackUser.name;
            val.uncapped = fb.NOW;
            return val;
          }, undefined, false)
            .then(ret => {
              return {
                "text": 'User @' + m[2] + ' now set uncapped today',
                "response_type": 'ephemeral'
              };
            });
        });
      })
        .catch(function (err) {
          logger.warn('uncapped user failed:', err, err.stack);
          return {
            "text": err.toString(),
            "response_type": 'ephemeral'
          };
        })
        .then(function (notifyMessage) {
          logger.log('notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('cmd result sent to slack action user:', cmd.user_name, ret);
          });
        });
      return resp.send('');
    }
    m = cmd.text.match(/^(credit)\s+@(\S+)\s*$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command:', m[2]);
      let slackResp = slack.webhook(cmd.response_url);
      Promise.resolve().then(function () {
        if (!slack.allowCommand('credit', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        // now get id by username
        return slack.findUserByName(m[2]).then(slackUser => {
          if (!slackUser)
            throw new Error('User ' + m[2] + ' not found.');
          return fb.cfgRef.child('lead/claim/userPerDay/' + slackUser.id).transaction(val => {
            val = val || {};
            if (today !== val.date) {
              val.date = today;
              val.claimed = {};
              val.numClaimed = 0;
              val.credits = null;
              val.uncapped = null;
            }
            val.credits = val.credits || 0;
            val.credits++;
            return val;
          }, undefined, false)
            .then(ret => {
              return {
                "text": 'User @' + m[2] + ' has been credited one lead',
                "response_type": 'ephemeral'
              };
            });
        });
      })
        .catch(function (err) {
          logger.warn('add credit for user failed:', err, err.stack);
          return {
            "text": err.toString(),
            "response_type": 'ephemeral'
          };
        })
        .then(function (notifyMessage) {
          logger.log('notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('cmd result sent to slack action user:', cmd.user_name, ret);
          });
        });
      return resp.send('');
    }
    m = cmd.text.match(/^(stat)\s*$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command:', m[2]);
      let slackResp = slack.webhook(cmd.response_url);
      Promise.resolve().then(function () {
        if (!slack.allowCommand('stat', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        // now get id by username
        return fb.cfgRef.child('lead/claim/userPerDay').once('value').then(snap => snap.val() || {})
          .then(userPerDayClaimStat => {
            let stats = Object.keys(userPerDayClaimStat).map(uid => userPerDayClaimStat[uid]).filter(stat => stat.date === today && stat.numClaimed > 0);
            return {
              "text": stats.length === 0 ? 'Today there is no claim yet.' : stats.map(stat => '@' + stat.username + ' has claimed ' + stat.numClaimed + ' lead' + (stat.numClaimed > 1 ? 's' : '') + ' today' + (stat.credits ? ' and ' + stat.credits + ' extra credit' + (stat.credits > 1 ? 's' : '') : '')).join('\n'),
              "response_type": 'ephemeral'
            };
          });
      })
        .catch(function (err) {
          logger.warn('uncapped user failed:', err, err.stack);
          return {
            "text": err.toString(),
            "response_type": 'ephemeral'
          };
        })
        .then(function (notifyMessage) {
          logger.log('notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('cmd result sent to slack action user:', cmd.user_name, ret);
          });
        });
      return resp.send('');
    }
    m = cmd.text.match(/^(help)\s*$/);
    if (m) {
      // move lead to the other channel
      logger.log('got slack ' + m[1] + ' command');
      return Promise.resolve().then(() => {
        if (!slack.allowCommand('help', cmd.user_name))
          throw new Error('You are not allowed to run this command');
        return resp.json({
          "text": "/leadbot command usage:\n1. Move a lead to the other channel:\n/leadbot move|reassign leadId channel\n2. Delete a lead:\n/leadbot remove|del|delete leadId\n3. Punish an user with a delay to claim lead:\n/leadbot delay seconds @username\n4. List all delayed users either punished or capped:\n/leadbot delay\n5. Unpunish an user:\n/leadbot delay 0 @username\n6. Uncap an user today:\n/leadbot uncap @username\n7. Add one credit for user today:\n/leadbot credit @username\n8. Manually create lead:\n/leadbot new\n9. Show number of claims of per user today:\n/leadbot stat\n10. Show help messages:\n/leadbot help",
          "response_type": 'ephemeral'
        });
      })
        .catch(err => {
          logger.warn('help cmd failed:', err, err.stack);
          return resp.json({
            "text": err.toString(),
            "response_type": 'ephemeral'
          });
        });
    }
    resp.json({
      "text": "Command format is not correct!",
      "response_type": 'ephemeral'
    });
  });
  app.post('/claimLead', function (req, resp) {
    // { payload: '{"actions":[{"name":"apply","value":"apply"}],"callback_id":"PENBRHRteERKUkM5OW5aX21uc0Q0RHFqMXJzR2lGU3B4Y3J3WC04RDB0R0FlNkw4MnV4d0BtYWlsLmdtYWlsLmNvbT4=","team":{"id":"T1KSDKUGG","domain":"georgiaassociated"},"channel":{"id":"D1L2AETNJ","name":"directmessage"},"user":{"id":"U1L2QBRCH","name":"ulion"},"action_ts":"1466942963.734656","message_ts":"1466942955.000020","attachment_id":"1","token":"KcrlMARGOYfI8bRp9X8oIdUK","original_message":{"text":"NEW LEAD to leadbot","bot_id":"B1LBLTUFJ","attachments":[{"callback_id":"PENBRHRteERKUkM5OW5aX21uc0Q0RHFqMXJzR2lGU3B4Y3J3WC04RDB0R0FlNkw4MnV4d0BtYWlsLmdtYWlsLmNvbT4=","text":"\\"\\"I\'m interested in 2583 Hewatt Rd\\"\\"","title":"<http:\\/\\/email.realtor.com\\/wf\\/click?upn=ec9lqO1IP0U8XYXKBgZaPEl5qhSW-2FxZorh-2F7Mg12oJ66D5nDSKi8HZq3gyazNDurgwsHCOGFRVJMjcNKW2CdOYbNyzpHWCvgw4l7kSjixDg-3D_OiKHqhLQgdf6WY5bYMkTUXmWCo39emdAIfwWlbSnMitDUzcRQ213Wfl5i1-2BY5uG4m4GHHX0l4wzqwY9UAvNxka-2FV2ggVnSRXjjxOdt57bOoERZ8Z3KpIkSEwSLeJf2hfdfo9nPeyqTRty8-2FsPxq1VdLiySWwxtvy6FbvKVwsfI1g8j73Xm2f1XFavgQBrgyPe2lLvD-2FcBhmUq0xEhCDmqeSBmCF4uIB4q7joAi3bYICkGpR9xPimUix35W8dn1CslTct1R7qc5Ou8rWGAfmRdcZbw6KJwUlh6UNGMFrOGWAJNzYVXwf-2BXdV3VGic-2BwJhAh8-2FVa247dbEJSl2aOPibsFteOZTetTwNU3qqubdlHvFA5nEdJFYbrmuL6g7lFPnpCSnORMlxZGN4aOj0B8Q9w-3D-3D|New lead from realtor.com \\u00ae>","id":1,"color":"36a64f","fields":[{"title":"Name","value":"Danielle Hudson","short":true},{"title":"Email","value":"<mailto:daniellechudson@gmail.com|daniellechudson@gmail.com>","short":true},{"title":"Phone","value":"<tel:404-610-1572|404-610-1572>","short":true},{"title":"Price","value":"$174,900","short":true},{"title":"Address","value":"2583 Hewatt Rd, Snellville, GA 30039","short":false}],"actions":[{"id":"1","name":"apply","text":"Apply this Lead","type":"button","value":"apply","style":""}],"fallback":"NO FALLBACK DEFINED"}],"type":"message","subtype":"bot_message","ts":"1466942955.000020"},"response_url":"https:\\/\\/hooks.slack.com\\/actions\\/T1KSDKUGG\\/54404483925\\/2fBq1FZZ0mW4T5pE0mZCFGv6"}' }
    /*
{ actions: [ { name: 'apply', value: 'apply' } ],
2016-06-26T12:11:51.511007+00:00 app[web.1]:   callback_id: 'PENBRHRteEQrZnJEQnhvWWZteFlKV01adUQrUGdUeDRlQzI5dk5pa2RGcjZqZE9EeC1vZ0BtYWlsLmdtYWlsLmNvbT4=',
2016-06-26T12:11:51.511009+00:00 app[web.1]:   team: { id: 'T1KSDKUGG', domain: 'georgiaassociated' },
2016-06-26T12:11:51.511009+00:00 app[web.1]:   channel: { id: 'D1L2AETNJ', name: 'directmessage' },
2016-06-26T12:11:51.511010+00:00 app[web.1]:   user: { id: 'U1L2QBRCH', name: 'ulion' },
2016-06-26T12:11:51.511011+00:00 app[web.1]:   action_ts: '1466943111.368603',
2016-06-26T12:11:51.511011+00:00 app[web.1]:   message_ts: '1466942955.000019',
2016-06-26T12:11:51.511012+00:00 app[web.1]:   attachment_id: '1',
2016-06-26T12:11:51.511013+00:00 app[web.1]:   token: 'KcrlMARGOYfI8bRp9X8oIdUK',
2016-06-26T12:11:51.511014+00:00 app[web.1]:   original_message:
2016-06-26T12:11:51.511014+00:00 app[web.1]:    { text: 'NEW LEAD to leadbot',
2016-06-26T12:11:51.511015+00:00 app[web.1]:      bot_id: 'B1LBLTUFJ',
2016-06-26T12:11:51.511016+00:00 app[web.1]:      attachments: [ [Object] ],
2016-06-26T12:11:51.511016+00:00 app[web.1]:      type: 'message',
2016-06-26T12:11:51.511017+00:00 app[web.1]:      subtype: 'bot_message',
2016-06-26T12:11:51.511017+00:00 app[web.1]:      ts: '1466942955.000019' },
2016-06-26T12:11:51.511018+00:00 app[web.1]:   response_url: 'https://hooks.slack.com/actions/T1KSDKUGG/54355314643/xy4B1MAqIZuEAa6Nte8C45yT' }
    */
    logger.log('got lead claim req:', req.body);
    if (req.body.ssl_check)
      return resp.json({});
    let payload = JSON.parse(req.body.payload);
    logger.log('parsed payload:', payload);
    if (payload.token != fb.cfg.slack.token)
      return errorResponse(new Error('invalid token'), resp);
    if (payload.callback_id === "edit_sendtext_tag") {
      if (payload.actions && payload.actions[0] && payload.actions[0].selected_options && payload.actions[0].selected_options[0].value) {
        let selection = payload.actions[0].selected_options[0].value;
        let rSlack = require('slack');
        let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken })
        if (selection.startsWith("add_new")) {
          let tagNumber = parseInt(selection.replace("add_new_", ""));
          if (!isNaN(tagNumber)) {
            let newTag = "SENDTEXT" + tagNumber;
            // fb.cfgRef.child("georgiaar/tagTexts/" + newTag).transaction((val) => {
            //     return {
            //       0: "Hello World!"
            //     };
            //   }, function (error, committed, snapshot) {
            //   }, false
            // );

            let dialog = {
              "callback_id": "edit_sendtext_tag_submit",
              "title": "Edit " + newTag,
              "submit_label": "Save",
              "state": (tagNumber - 1) + "_" + 0 + "_" + payload.message_ts,
              "elements": [
                {
                  "label": "Edit text",
                  "name": "tagText",
                  "type": "textarea",
                  "hint": "Available merge fields:\n $timeOfDay , $firstName, $loginLink, $city, $agentName, $agentFullName, $leadSource, $inquiryAddress",
                  "value": "Hello world!"
                }
              ]
            };
            Slack.dialog.open({
              token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
              dialog: dialog,
              trigger_id: payload.trigger_id
            }).catch(err => {
              logger.log("Error opening dialog", err);
            }).then((re) => {
              logger.log("Re=", JSON.stringify(re.message));
            });
          }
        } else {
          let tagIndex = parseInt(selection.split("_")[0]);
          let textIndex = selection.split("_")[1];
          logger.log("tagIndex=", tagIndex);
          logger.log("textIndex=", textIndex);
          if (!isNaN(tagIndex)) {
            let selectedTag = "SENDTEXT" + (tagIndex + 1);
            let messageToEdit = doubleCurlyToDollar(fb.cfg.georgiaar.tagTexts[selectedTag][textIndex]);
            let dialog = {
              "callback_id": "edit_sendtext_tag_submit",
              "title": "Edit " + selectedTag,
              "submit_label": "Save",
              "state": tagIndex + "_" + textIndex + "_" + payload.message_ts,
              "elements": [
                {
                  "label": "Edit text",
                  "name": "tagText",
                  "type": "textarea",
                  "hint": "Available merge fields:\n $timeOfDay , $firstName, $loginLink, $citySearched, $agentName, $agentFullName, $leadSource, $inquiryAddress",
                  "value": messageToEdit
                }
              ]
            };
            Slack.dialog.open({
              token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
              dialog: dialog,
              trigger_id: payload.trigger_id
            }).catch(err => {
              logger.log("Error opening dialog", err);
            }).then((re) => {
              logger.log("Re=", JSON.stringify(re));
            });
          }
        }
      }
      return resp.status(200).send("");
    }

    if(payload.callback_id === 'openDialog') {
      console.log(payload);
      scheduledCallsRef.child(payload.actions[0].value).once('value').then((snap) => {
        let dialog = {
          "callback_id": "callNote",
          "title": "Add note for the call:",
          "submit_label": "Save",
          "state": payload.actions[0].value,
          "elements": [
            {
              "label": "Add Note here:",
              "name": "note",
              "type": "textarea",
              "hint": snap.val().callStatus === 'completed' ?
                "Call has been completed. You can not add note after this!" :
                "You can add note about the current call"
            }
          ]
        };
        let rSlack = require('slack');
        let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken });
        Slack.dialog.open({
          token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
          dialog: dialog,
          trigger_id: payload.trigger_id
        }).catch(err => {
          logger.log("Error opening dialog", err);
        }).then((re) => {
          logger.log("Re=", JSON.stringify(re.message));
        });
      }).catch((error) => {
        console.log(error);
      });
      return resp.status(200).send("");
    }

    if(payload.callback_id === "scheduledCall"){
      console.log('##=> payload:', payload, payload.actions[0].value);
      const responseMessage = slack.webhook(payload.response_url);
      console.log("scheduled call id:", payload.actions[0].value);
      scheduledCallsRef.child(payload.actions[0].value).once('value').then((snap) => {
        const scheduledCall = snap.val();
        console.log("scheduled from fb:", scheduledCall);
        scheduledCall.payload.url += `&scheduledCall=${encodeURI(payload.actions[0].value)}`;
        scheduledCall.payload.statusCallback += `&scheduledCall=${encodeURI(payload.actions[0].value)}`;
        let updatedMessage = payload.original_message;
        updatedMessage.replace_original = true;
        scheduledCallsRef.child(payload.actions[0].value).update({
          updatedMessage,
          response_url: payload.response_url
        }).then().catch((error) => {console.log(error)});
        delete updatedMessage.attachments[0];
        updatedMessage.state = payload.actions[0].value;
        updatedMessage.attachments.push({
          "color": "good",
          "title": "add notes:",
          "text": "You can add notes for call log until 5 minutes. after that call will be logged in followup boss.",
          "callback_id": "openDialog",
          "state": payload.actions[0].value,
          "actions": [
            {
              "name": "add note",
              "text": "add note",
              "type": "button",
              "value": payload.actions[0].value
            }
          ]
        });
        const thePhone = scheduledCall.lead.phones &&
          scheduledCall.lead.phones.length &&
          scheduledCall.lead.phones[0].value;
        thePhone && twilioClient.isValidNumber(thePhone).then((response) => {
            responseMessage.send(updatedMessage);
            twilioClient.client.calls.create(scheduledCall.payload, (err, call) => {
              if (err) {
                console.log('##=> error when making call', err);
                responseMessage.send({text: `Call Failed: ${err.message}`});
              } else {
                scheduledCallsRef.child(payload.actions[0].value).update({callStatus: 'started'}).then().catch((err) => {console.log(err)});
                console.log('##=>', call);
              }
            })
        }).catch((error) => {
          slack.findUserByFullName(scheduledCall.assignedTo).then((slackUser) => {
            if (slackUser) {
              slack.send('taddle', {
                channel: '@' + slackUser.name,
                message: error.message
              })
            }
          }).catch((slackFindError) => {
            console.log(slackFindError, error.message);
          })
        });

      }).catch((err) => {
        console.log('##=>', err);
        responseMessage.send({text: 'schedule was not found or call has already been done!'});
      });
      return resp.status(200).send("");
    }

    if(payload.callback_id === 'callNote') {
      const possibleReplies = ["Great Work!", "Thank ya!", "Excellence!", "Blam!"];
      const responseMessage = slack.webhook(payload.response_url);
      scheduledCallsRef.child(payload.state).once('value').then((snap) => {
        const currSchedule = snap.val();
        if(currSchedule){
          if(currSchedule.callStatus && currSchedule.callStatus === 'completed') {
            let updatedMessage = currSchedule.updatedMessage;
            updatedMessage.replace_original = true;
            delete updatedMessage.attachments[0].actions;
            updatedMessage.attachments[0].fields.push({
              "title": possibleReplies[Math.round(Math.random() * 10) % 4],
              "value": `Call Done! You can check call logs here: <${fb.cfg.crm.siteUrl}/2/people/view/${currSchedule.lead.id}|Open in FUB>`,
            });
            slack.webhook(currSchedule.response_url).send(updatedMessage);
            currSchedule.callParams.note += '\nAgent Note:' + currSchedule.agentNote + payload.submission.note;
            /*why wait 5 minutes, call log here and clear time out of 5 minute waiting*/
            if (currSchedule.callParams.api_key) {
              let interceptorParams = {
                call: 'addCall',
                leadId: currSchedule.callParams.leadId,
                note: currSchedule.callParams.note,
                phone: currSchedule.callParams.leadPhone,
                outcome: "Interested",
                duration: currSchedule.callParams.callDuration,
                isIncoming: false,
                ignoreLogs: false,
                system: systemName,
                apiKey: currSchedule.callParams.api_key
              }

              crm.interceptor(interceptorParams)
              /*
              crm.addCall(
                currSchedule.callParams.leadId,
                currSchedule.callParams.note,
                currSchedule.callParams.leadPhone,
                "Interested",
                currSchedule.callParams.callDuration,
                false,
                false,
                currSchedule.callParams.systemName,
                currSchedule.callParams.api_key
              );
              */
            } else {
              currSchedule.callParams.note += ". No api_key found for " + assignedTo + ". So writing note instead of call.";
              crm.interceptor({ call: 'addNote', leadId: currSchedule.callParams.leadId, note: currSchedule.callParams.note, ignoreLogs: false, system: currSchedule.callParams.systemName })
              /*
              crm.addNote(currSchedule.callParams.leadId,
                currSchedule.callParams.note,
                false,
                currSchedule.callParams.systemName,
                true);
              */
            }
            scheduledCallsRef.child(payload.state).remove().then().catch((err) => console.log(err));
          } else {
            scheduledCallsRef.child(payload.state).update({agentNote: currSchedule.agentNote + `\n${payload.submission.note}`}).then(() => {
              responseMessage.send({text: possibleReplies[Math.round(Math.random() * 10) % 4] + '. Your note was successfully added. you can see the log when call has ended!'});
            }).catch((error) => {
              console.log(error);
              responseMessage.send({text: 'there was problem in adding your log'});
            })
          }
        } else {
          /*scheduleCall record not found*/
          responseMessage.send({text: 'ehhh! too late! call is already been logged in the follow up boss'});
        }
      });
      return resp.status(200).send("");
    }

    if (payload.callback_id === "edit_sendtext_tag_submit") {
      let tagIndex = parseInt(payload.state.split("_")[0]);
      let textIndex = parseInt(payload.state.split("_")[1]);
      let message_ts = payload.state.split("_")[2];
      if (payload.submission && payload.submission.tagText) {
        fb.cfgRef.child("georgiaar/tagTexts/SENDTEXT" + (tagIndex + 1) + "/" + textIndex).transaction((val) => {
          val = dollarToDoubleCurly(payload.submission.tagText);
          return val;
        }, undefined, false);
      }
      let rSlack = require('slack');
      let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken })
      Slack.chat.delete({
        token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
        ts: message_ts,
        channel: payload.channel.id
      }).catch((err) => {
        logger.log("Delete message error", err);
        return;
      }).then(() => {
        Slack.chat.postEphemeral({
          token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
          text: "SENDTEXT" + (tagIndex + 1) + " edited successfully!",
          channel: payload.channel.id,
          user: payload.user.id
        });
      })
      return resp.status(200).send("");
    }

    if(payload.actions[0].value === 'initiateCall') {
      console.log('###=> initiate call on ', payload.callback_id);
      leadsRef.child(payload.callback_id).once('value').then((snap) => {
        const lead = snap.val();
        const currentTimeStamp = new Date();
        let currentDurationMin = null;
        let currentDurationSec = null;
        if(lead.lastSlackSentAt) {
          currentDurationMin = parseInt((currentTimeStamp - new Date(+lead.lastSlackSentAt)) / 1000 / 60);
          currentDurationSec = parseInt((currentTimeStamp - new Date(+lead.lastSlackSentAt)) / (1000) % 60);
        }
        lead.idInCrm && axios.post(sendtextWebhookUrl, {
          "src": !!realgeeks.isRGSource(lead.source) ? 'RG' : lead.source,
          "resourceIds": [lead.idInCrm],
          "noTexts": true
        }).then((response) => {
          crm.interceptor({ call: 'addNote', leadId: lead.idInCrm, note: (lead.lastSlackSentAt ? `${payload.user.name} initiated call ${currentDurationMin} minutes ${currentDurationSec} seconds after notification` : `Call was initiated by ${payload.user.name}`), ignoreLogs: false, system: systemName })
          if(lead && lead.taddleSlackSent) {
            slack.api.chat.update({
              "token": fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
              "ts": lead.taddleSlackSent.ts,
              "channel": lead.taddleSlackSent.channel,
              "text": lead.lastSlackSentAt ? `Update: Call was initiated at ${localMoment().format('h:mm:ss a')} by ${payload.user.name}, ${currentDurationMin} minutes and ${currentDurationSec} seconds after they were notified`
                :`Update: Call was initiated by ${payload.user.name}`,
            }).then((response) => {
              console.log('response: ',response)
            }).catch((error) => {
              console.log(error);
            });
          }
          if(lead && lead.agentAllSlackSent) {
            snap.ref.transaction((val)=>{
              val = val || {};
              val.agentAllSlackSent=[];
              return val;
            }).catch((error)=>{
              logger.log("###=>Transaction error",error);
            })
          }
          console.log('webhook call success');
        }).catch((error) => {
          console.log('error in webhook call', error);
        })
      }).catch((error) => {
        console.log(error);
      });
    }

    if(payload.actions[0].value === 'initiateCallISA') {
      const responseMessage = slack.webhook(payload.response_url);
      console.log('###=>ISA initiate call on ', payload.callback_id);
      let ISAMembers = fb.cfg.slack.ISAMEMBERS;
      if(ISAMembers && ISAMembers.includes(payload.user.name.toLowerCase())){
        leadsRef.child(payload.callback_id).once('value').then((snap) => {
          const lead = snap.val();
          lead.idInCrm && axios.post(sendtextWebhookUrl, {
            "src": !!realgeeks.isRGSource(lead.source) ? 'RG' : lead.source,
            "resourceIds": [lead.idInCrm],
            "noTexts": true
          }).then((response) => {
            if(lead && lead.taddleSlackSent) {
              slack.api.chat.update({
                "token": fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
                "ts": lead.taddleSlackSent.ts,
                "channel": lead.taddleSlackSent.channel,
                "text": `Update: Call was initiated by ${payload.user.name}`,
              }).then((response) => {
                console.log('response: ',response)
              }).catch((error) => {
                console.log(error);
              });
            }
            if(lead && lead.agentAllSlackSent) {
              snap.ref.transaction((val)=>{
                val = val || {};
                val.agentAllSlackSent=[];
                return val;
              }).catch((error)=>{
                logger.log("###=>Transaction error",error);
              })
            }
            console.log('webhook call success');
          }).catch((error) => {
            console.log('error in webhook call', error);
          })
        }).catch((error) => {
          console.log(error);
        });
      }
      else {
        let notifyMessage = nunjucks.render(config.slack.errorMsg, {
          error: 'Only ISA Members can initiate call.'
        });
        responseMessage.send(notifyMessage)
      }
      return resp.status(200).send("");
    }

    if(payload.actions[0].value === 'notInterested') {
      console.log('###=> current agent no longer interested on ', payload.callback_id);
      const responseMessage = slack.webhook(payload.response_url);
      const updatedMessage = payload.original_message;
      delete updatedMessage.attachments[0].actions;
      updatedMessage.attachments.push({color: "danger", title: "You chose not to service this lead"});
      leadsRef.child(payload.callback_id).once('value').then(async (snap) => {
        const lead = snap.val();
        lead.id = payload.callback_id;

        if(lead && lead.idInCrm) {
          crm.interceptor({ call: 'addNote', leadId: lead.idInCrm, note: `${payload.user.name} don’t want to/can’t service this lead`, ignoreLogs: false, system: systemName })
          // crm.addNote(lead.idInCrm, `${payload.user.name} don’t want to/can’t service this lead`, false, systemName);
        }

        if(lead && lead.taddleSlackSent) {
          const newMessage = nunjucks.render(config.slack.newLeadMsg, {
            lead,
            channel: lead.taddleSlackSent.channel
          });
          newMessage.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken;
          newMessage.text = `*<@${payload.user.name}> don’t want to/can’t service this lead.*`;
          newMessage.ts = lead.taddleSlackSent.ts;
          newMessage.attachments[0].actions = [
            {
              "name": "broadcast",
              "text": "Broadcast",
              "type": "button",
              "value": "broadcast"
            },
            {
              "name": "ignore",
              "text": "Ignore",
              "type": "button",
              "value": "ignore"
            }
          ];
          let leadInCrm = await findLeadInCrm(lead);
          newMessage.attachments[0].fields.push(
            {
              "title": "Assigned To",
              "value": (leadInCrm && leadInCrm.assignedTo) || (lead && lead.assignedTo) || 'N/A',
              "short": true,
            },
            {
              "title": "Stage",
              "value": (leadInCrm && leadInCrm.stage) || 'N/A',
              "short": true,
            },
            {
              "title": "Lead Link",
              "value": (lead.idInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${lead.idInCrm}|client>`) ||
                (leadInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${leadInCrm.id}|client>`) ||
                'N/A',
              "short": true,
            },
          )
          newMessage.attachments = JSON.stringify(newMessage.attachments);

          console.log('finally new message:', newMessage);

          slack.api.chat.update(newMessage).then((response) => {
            console.log('not interested response: ',response);
            responseMessage.send(updatedMessage);
          }).catch((error) => {
            console.log(error);
          });
        }
      });
      return resp.status(200).send("");
    }

    if(payload.actions[0].value === 'sendToChannel') {
      const responseMessage = slack.webhook(payload.response_url);
      if(slack.isAdmin(payload.user.name)) {
        leadsRef.child(payload.callback_id).update({
          existingLeadBroadCast: true
        }).then(() => {
          leadsRef.child(payload.callback_id).once('value').then((snap) => {
            logger.log('updated value for broadcast:', snap.val().existingLeadBroadCast, snap.val().slackSent);
            newLeadsMethod(snap).then((res) => {
              logger.log('done broadcasting',res);
              const updatedMessage = payload.original_message;
              delete updatedMessage.attachments;
              updatedMessage.attachments = [
                {
                  "color": "good",
                  "title": `Successfully broadcasted to appropriate channel by <@${payload.user.name}>.`
                }
              ];
              responseMessage.send(updatedMessage);
              let rSlack = require('slack');
              let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken })
              Slack.chat.delete({
                token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
                ts: snap.val().agentSlackSent.ts,
                channel: snap.val().agentSlackSent.channel,
              }).catch((err) => {
                logger.log("Delete message error", err);
                return;
              })
              snap.ref.update({existingLeadBroadCast: null}).then().catch(error => console.log(error));
            }).catch((error) => console.log(error))
          });
        }).catch((error) => {
          logger.log('error when fetching lead in broadcast:', error);
        });
      } else {
        let notifyMessage = nunjucks.render(config.slack.errorMsg, {
          error: 'Only admins can perform this action.'
        });
        responseMessage.send(notifyMessage)
      }

      return resp.status(200).send("");
    }

    if(payload.actions[0].value === 'broadcast') {
      console.log('broadcast');
      const responseMessage = slack.webhook(payload.response_url);
      if(slack.isAdmin(payload.user.name)) {
        leadsRef.child(payload.callback_id).update({
          existingLeadBroadCast: true
        }).then(() => {
          leadsRef.child(payload.callback_id).once('value').then((snap) => {
            console.log('updated value for broadcast:', snap.val().existingLeadBroadCast, snap.val().slackSent);
            newLeadsMethod(snap).then((res) => {
              console.log('done broadcasting',res);
              const updatedMessage = payload.original_message;
              delete updatedMessage.attachments;
              updatedMessage.attachments = [
                {
                  "color": "good",
                  "title": `Successfully broadcasted to appropriate channel by <@${payload.user.name}>.`
                }
              ];
              responseMessage.send(updatedMessage);

              snap.ref.update({existingLeadBroadCast: null}).then().catch(error => console.log(error));
            }).catch((error) => console.log(error))
          });
        }).catch((error) => {
          console.log('error when fetching lead in broadcast:', error);
        });
      } else {
        let notifyMessage = nunjucks.render(config.slack.errorMsg, {
          error: 'Only admins can perform this action.'
        });
        responseMessage.send(notifyMessage)
      }

      return resp.status(200).send("");
    }

    if(payload.actions[0].value === 'ignore') {
      const responseMessage = slack.webhook(payload.response_url);
      if(slack.isAdmin(payload.user.name)) {
        console.log('ignore');
        const updatedMessage = payload.original_message;
        delete updatedMessage.attachments;
        updatedMessage.attachments = [
          {
            "color": "good",
            "title": `This lead is ignored by ${payload.user.name}`
          }
        ];
        responseMessage.send(updatedMessage);
      } else {
        let notifyMessage = nunjucks.render(config.slack.errorMsg, {
          error: 'Only admins can perform this action.'
        });
        responseMessage.send(notifyMessage)
      }
      return resp.status(200).send("");
    }

    if (payload.actions[0].name === 'opportunity') {
      // gg lead opportinity mark handled
      let action = payload.actions[0].value;
      Promise.resolve().then(() => {
        let handleOptionValues = ['markAsHandled', 'sendEmailFromAgent', 'sendTextFromAgent', 'notifyAgent'];
        if (handleOptionValues.indexOf(action) >= 0 || action === 'muteLead') {
          return slack.api.users.info({
            token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
            user: payload.user.id
          })
            .then(user => {
              payload.agentName = payload.user.fullName = user.user.profile.real_name_normalized || user.user.profile.real_name || payload.user.name;
              /*if (action === 'sendEmailFromAgent' || action === 'sendTextFromAgent') {
                return
              }
            })
            .then(() => {*/
              let slackResp = slack.webhook(payload.response_url);
              let updatedMessage = payload.original_message;
              updatedMessage.replace_original = true;
              if (updatedMessage.attachments[0].actions) {
                updatedMessage.attachments[0].actions = updatedMessage.attachments[0].actions.filter(act => act.value !== action && !(action === 'markAsHandled' && act.value === 'notifyAgent'));
              }
              if (!updatedMessage.attachments[0].text)
                updatedMessage.attachments[0].text = '';
              else
                updatedMessage.attachments[0].text += "\n";

              if (action === 'markAsHandled')
                updatedMessage.attachments[0].text += 'Handled by ' + payload.agentName;
              else if (action === 'sendEmailFromAgent')
                updatedMessage.attachments[0].text += 'Email sent by ' + payload.agentName;
              else if (action === 'sendTextFromAgent')
                updatedMessage.attachments[0].text += 'Text sent by ' + payload.agentName;
              else if (action === 'muteLead')
                updatedMessage.attachments[0].text += 'Muted by ' + payload.agentName;
              //else if (action === 'notifyAgent')
              //  updatedMessage.attachments[0].text += 'Opportunity sent to ' + payload.agentName;

              if (action === 'muteLead') {
                return realgeeks.muteLead(payload.callback_id, payload.agentName).then(() => {
                  /*let slackResp = slack.webhook(payload.response_url);
                  let updatedMessage = payload.original_message;
                  updatedMessage.replace_original = true;
                  if (updatedMessage.attachments[0].actions) {
                    updatedMessage.attachments[0].actions = updatedMessage.attachments[0].actions.filter(action => action.value !== action);
                  }
                  if (!updatedMessage.attachments[0].text)
                    updatedMessage.attachments[0].text = '';
                  else
                    updatedMessage.attachments[0].text += "\n";
                  updatedMessage.attachments[0].text += 'Muted by ' + payload.agentName;*/
                  return slackResp.send(updatedMessage).then(() => {
                    return slackResp.send(config.slack.opportunityMutedMsg);
                  });
                });
              }
              else if (action === 'notifyAgent') {
                return realgeeks.notifyAgentOpportunity(payload.callback_id, payload.user, updatedMessage).then(lead => {
                  // XXX: now we know the agent name
                  if (action === 'notifyAgent')
                    updatedMessage.attachments[0].text += 'Opportunity sent to ' + lead.fubAssignedTo;
                  return slackResp.send(updatedMessage).then(() => {
                    return slackResp.send(nunjucks.render(config.slack.opportunityHandledMsg, {
                      fubSiteUrl: fb.cfg.crm.siteUrl,
                      action: action,
                      lead: lead,
                      agentName: lead.fubAssignedTo
                    }));
                  });
                });
              }
              else {
                return realgeeks.markOpportunityHandled(payload.callback_id, payload.agentName, action, payload.channel.id).then(lead => {
                  /*let slackResp = slack.webhook(payload.response_url);
                  let updatedMessage = payload.original_message;
                  updatedMessage.replace_original = true;
                  if (updatedMessage.attachments[0].actions) {
                    updatedMessage.attachments[0].actions = updatedMessage.attachments[0].actions.filter(act => action != act.value && !(action === 'markAsHandled' && act.value === 'notifyAgent'));
                  }
                  if (!updatedMessage.attachments[0].text)
                    updatedMessage.attachments[0].text = '';
                  else
                    updatedMessage.attachments[0].text += "\n";
                  // 'markAsHandled', 'sendEmailFromAgent', 'sendTextFromAgent'
                  if (action === 'markAsHandled')
                    updatedMessage.attachments[0].text += 'Handled by ' + payload.agentName;
                  else if (action === 'sendEmailFromAgent')
                    updatedMessage.attachments[0].text += 'Email sent by ' + payload.agentName;
                  else if (action === 'sendTextFromAgent')
                    updatedMessage.attachments[0].text += 'Text sent by ' + payload.agentName;
                  else if (action === 'muteLead')
                    updatedMessage.attachments[0].text += 'Muted by ' + payload.agentName;
                  else if (action === 'notifyAgent')
                    updatedMessage.attachments[0].text += 'Opportunity sent to ' + payload.agentName;
                  */
                  //delete updatedMessage.attachments[0].actions;
                  return slackResp.send(updatedMessage).then(() => {
                    return slackResp.send(nunjucks.render(config.slack.opportunityHandledMsg, {
                      fubSiteUrl: fb.cfg.crm.siteUrl,
                      action: action,
                      lead: lead,
                      agentName: payload.agentName
                    }));
                  });
                });
              }
            });
        }
        else {
          logger.warn('unknown opportunity action:', action);
        }
      })
        .catch(err => {
          logger.warn('handle opportunity button failed:', err, err.stack);
          let slackResp = slack.webhook(payload.response_url);
          let notifyMessage = nunjucks.render(config.slack.errorMsg, {
            error: err.toString()
          });
          logger.log('opportunity failure notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('failure message sent to slack action user:', payload.user.name, ret);
          }).catch(function (err) {
            logger.warn('send opportunity failure message to slack failed:', err, err.stack);
          });
        });
      resp.send('');
      return;
    }
    let intervalSinceMsgPosted = Date.now() / 1000 - (+payload.message_ts);
    if (fb.cfg.lead.claim.punishedUsers && fb.cfg.lead.claim.punishedUsers[payload.user.name] && intervalSinceMsgPosted < fb.cfg.lead.claim.punishedUsers[payload.user.name]) {
      logger.debug('slack user claim delay not meet:', intervalSinceMsgPosted, fb.cfg.lead.claim.punishedUsers[payload.user.name]);
      let notifyMessage = nunjucks.render(config.slack.claimFailedMsg, {
        error: nunjucks.render(fb.cfg.lead.claim.delayClaimMsg, {
          delay: (fb.cfg.lead.claim.punishedUsers[payload.user.name] - intervalSinceMsgPosted).toFixed(0)
        })
      });
      return resp.json(notifyMessage);
    }
    let lastClaim = slackUserLastSuccessClaim[payload.user.id];
    if (lastClaim) {
      let claimInterval = (Date.now() - lastClaim) / 1000;
      logger.log('slack user claim interval:', claimInterval);
      if (fb.cfg.lead.claim && fb.cfg.lead.claim.minInterval && claimInterval < fb.cfg.lead.claim.minInterval) {
        let notifyMessage = nunjucks.render(config.slack.claimFailedMsg, {
          error: fb.cfg.lead.claim.minIntervalMsg
        });
        return resp.json(notifyMessage);
      }
    }
    let today = localMoment().format('YYYY-MM-DD');
    if (!slack.isAdmin(payload.user.name) && fb.cfg.lead.claim.delayByMaxClaimPerDay && intervalSinceMsgPosted < fb.cfg.lead.claim.delayByMaxClaimPerDay.delay && fb.cfg.lead.claim.delayByMaxClaimPerDay.maxClaimPerDay && fb.cfg.lead.claim.userPerDay && fb.cfg.lead.claim.userPerDay[payload.user.id] && fb.cfg.lead.claim.userPerDay[payload.user.id].date == today && !fb.cfg.lead.claim.userPerDay[payload.user.id].uncapped && fb.cfg.lead.claim.userPerDay[payload.user.id].numClaimed && fb.cfg.lead.claim.userPerDay[payload.user.id].numClaimed - (fb.cfg.lead.claim.userPerDay[payload.user.id].credits || 0) >= fb.cfg.lead.claim.delayByMaxClaimPerDay.maxClaimPerDay) {
      // XXX: check the user claims in that day
      logger.debug('slack user claim reach max claims per day:', intervalSinceMsgPosted, fb.cfg.lead.claim.userPerDay[payload.user.id]);
      let notifyMessage = nunjucks.render(config.slack.claimFailedMsg, {
        error: nunjucks.render(fb.cfg.lead.claim.cappedClaimMsg, {
          delay: (fb.cfg.lead.claim.delayByMaxClaimPerDay.delay - intervalSinceMsgPosted).toFixed(0)
        })
      });
      return resp.json(notifyMessage);
    }
    // XXX: process claim one by one.
    console.log('claim payload:',payload);
    claimQueue.add(function () {
      return Promise.all([
        slack.api.users.info({
          token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
          user: payload.user.id
        }),
        leadsRef.child(payload.callback_id).once('value').then(function (snap) {
          let lead = snap.val();
          if (!lead)
            throw new Error('Lead not found');
          lead.id = snap.key;
          if (lead.idInCrm) {
            return crm.interceptor({ call: 'getLeadInfo', leadId: lead.idInCrm, ignoreLogs: false, system: systemName }).then(function (info) {
            // return crm.getLeadInfo(lead.idInCrm, false, systemName).then(function (info) {
              lead.leadInCrm = info;
              return lead;
            }).catch(function (err) {
              logger.warn('retrieve crm lead failed:', err, err.stack);
              return lead;
            });
          } else {
            return crm.interceptor({ call: 'searchLeadInfo', searchQuery: { email: encodeURIComponent(lead.email), phone: lead.phone }, ignoreLogs: false, system: systemName })
            // return crm.searchLeadInfo({email: encodeURIComponent(lead.email), phone: lead.phone}, false, systemName)
              .then((info) => {
                if(info.people.length) {
                  lead.leadInCrm = info.people[0];
                  lead.reassignFrom = fb.cfg.crm.monitorLeadOwnerToClaim;
                  lead.idInCrm = info.people[0].id;
                  return lead;
                } else {
                  if(lead.agentSourced) {
                    lead.customTag = fb.cfg && fb.cfg.lead && fb.cfg.lead.customTag;
                  }
                  return lead;
                }
              }).catch(error => console.log('##fetch error:',error));
          }
        })
      ])
        .then(function (ret) {
          console.log('###=>ret:',JSON.stringify(ret));
          let user = ret[0];
          logger.log('got slack user:', user);
          let lead = ret[1];
          logger.log('got firebase lead:', lead);
          let username = user.user.profile.real_name_normalized || user.user.profile.real_name;
          if (fb.cfg.crm && fb.cfg.crm.usernameFromSlack)
            username = fb.cfg.crm.usernameFromSlack[payload.user.name] || fb.cfg.crm.usernameFromSlack[username] || username;
          lead.agentName = username;
          // FIXME: if we already have id in crm, why we here?
          //        1. one possible reason is the multiple click to claim from users, the later click
          //           may found the idInCrm exists and the lead was assignedTo some agent already.
          //        2. The other case, is that we want broadcast a lead which should be "reassigned"
          //           when it is claimed. for this case, only the first claim should reassign the lead
          // XXX: so, we should pipe the claim requests one by one, only handle one claim request at the same time
          //      to prevent from reassign multiple times.
          return Promise.resolve().then(function () {
            if (lead.leadInCrm) {
              logger.log("lead.leadInCrm true", JSON.stringify(lead.leadInCrm));
              // XXX: the lead was assigned to someone or already in the system anyway,
              //      we could know current request is to re-assign from a certain agent
              //      or by check the lead find it's current status
              // XXX: we may setup some "reassign" flag in firebase lead, then do the reassign when the flag
              //      detected.
              /*previous condition: lead.reassignFrom == lead.leadInCrm.assignedTo*/
              if (Array.isArray(lead.reassignFrom) && _.includes(lead.reassignFrom, lead.leadInCrm.assignedTo)/* && username != lead.reassignFrom*/) {
                logger.log('reassign lead ' + lead.idInCrm + ' from ' + lead.reassignFrom + ' to ' + username + ' ...');
                return crm.interceptor({ call: 'updateLead', leadId: lead.idInCrm, updateObj: { assignedTo: username }, ignoreLogs: false, system: systemName }).then(function (ret) {
                // return crm.updateLead(lead.idInCrm, { assignedTo: username }, false, systemName).then(function (ret) {
                  logger.log('reassign lead ' + lead.idInCrm + ' from ' + lead.reassignFrom + ' to ' + username + ' ret:', ret.id);
                  lead.assignedTo = ret.assignedTo;
                  // TODO: more than reassign when claim, we do this in the FUB callback handler.
                  if (fb.cfg.georgiaar && realgeeks.isRGSource(lead.source)) {
                    // Call the peopleCreatedWebhook of sendtext.js
                    logger.log("calling peopleCreated webhook in sendtext.js " + sendtextWebhookUrl);
                    axios.post(sendtextWebhookUrl, {
                      "src": "RG",
                      "resourceIds": [lead.idInCrm]
                    }).then((resp) => {
                      logger.log("webhook response: " + (resp));
                    }).catch((err) => {
                      logger.log("webhook error: " + err);
                    });

                    // XXX: call realgeeks incoming lead api to do the reassignment too.
                    realgeeks.listUsers(lead.source).then(function (users) {
                      let agentUser = users.filter(function (u) {
                        return u.name == lead.assignedTo;
                      })[0];
                      if (!agentUser)
                        throw new Error('Agent ' + lead.assignedTo + ' does not found in realgeeks.');
                      logger.log('realgeeks agent:', agentUser);
                      return realgeeks.newActivity(lead.id, [{
                        type: 'was_assigned',
                        user: {
                          id: agentUser.id
                        }
                      }], lead.source).then(function (ret) {
                        logger.log('reassign realgeeks lead ' + lead.id + ' to ' + lead.assignedTo + ' ret:', ret);
                      });
                    }).catch(function (err) {
                      logger.warn('reassign in realgeeks failed:', err, err.stack);
                    });
                  }
                  return {
                    statusCode: 202,
                    body: ret
                  }
                });
              }
              else/* if (lead.leadInCrm.assignedTo == username)*/ {
                // XXX: we do not want the re-assignment success here, since re-assignment should only happen once (lead claimed)
                //      we do not want the 2nd click again send claim request if we did claim it successfully.
                // FIXME: we prevented same user click here, but the others click at the same time still trigger a post new lead request???
                logger.log("lead.leadInCrm false", lead.id)
                lead.assignedTo = lead.leadInCrm.assignedTo;
                return {
                  statusCode: 200,
                  body: lead.leadInCrm
                };
              }

            }
            return crm.interceptor({ call: 'postNewLead', lead: lead, ignoreLogs: false, system: systemName }).then(function (ret) {
            // return crm.postNewLead(lead, false, systemName).then(function (ret) {
              console.log(ret.statusCode, ret.body);
              // existed "people" in the crm (200)
              // new created "people" (201)
              if (ret.statusCode == 200) {
                if(_.includes(fb.cfg.georgiaar.monitorFUBLeadOwner, ret.body.assignedTo)) {
                  return crm.interceptor({ call: 'updateLead', leadId: ret.body.id, updateObj: { assignedTo: lead.agentName }, ignoreLogs: false, system: systemName })
                  // return crm.updateLead(ret.body.id,{assignedTo:lead.agentName}, false, systemName)
                    .then(function (res) {
                    lead.assignedTo = res.assignedTo;
                    lead.idInCrm = res.id;
                    return {statusCode:201,body:{...res}};
                  })
                    .catch(function (error) {
                      logger.log('###=>error',error.message);
                      lead.assignedTo = ret.body.assignedTo;
                      lead.idInCrm = ret.body.id;
                      return ret;
                  })
                }
                else {
                  lead.assignedTo = ret.body.assignedTo;
                  lead.idInCrm = ret.body.id;
                  return ret;
                }
              }
              else if(ret.statusCode == 201) {
                lead.assignedTo = ret.body.assignedTo;
                lead.idInCrm = ret.body.id;
                return ret;
              }
              else if (ret.statusCode == 400) {
                logger.warn('post new lead to crm failed:', ret.body);
                let slackResp = slack.webhook(payload.response_url);
                throw new Error(ret.body.errorMessage);
                /*let msg = ret.body.errorMessage ? ret.body.errorMessage : 'Failed to claim the lead.';
                // Invalid value for 'assignedTo
                if (msg.match(/^Invalid value for 'assignedTo/))
                  msg = 'Can not locate your crm account by your slack profle full name. Make sure you setup same full name in both your slack profile and your crm account.';*/
                let notifyMessage = nunjucks.render(config.slack.claimFailedMsg, {
                  error: ret.body.errorMessage
                });
                logger.log('claim failure notify message:', notifyMessage);
                return slackResp.send(notifyMessage).then(function (ret) {
                  logger.log('failure message sent to slack action user:', payload.user.name, ret);
                });
              }
              else {
                throw new Error('Unhandled crm return status:', ret.statusCode, ret.body);
              }
              return ret;
            });
          }).then(async function (ret) {
            let agentLeadData = await findLeadInCrm(lead)
            let agentJson = {
              agentId: agentLeadData.assignedUserId,
              leadId: agentLeadData.id,
              name: agentLeadData.assignedTo,
              claimed_date: Date.now()
            }
            db.claim.create(agentJson).then(result => console.log('Adding mysql claim record for id ', lead.id))

            return leadsRef.child(lead.id).transaction(val => {
              val = val || {};
              val.idInCrm = lead.idInCrm;
              if (val.assignedTo != lead.assignedTo)
                val.claimedAt = fb.NOW;
              val.assignedTo = lead.assignedTo;
              val.reassignFrom = null;  // clear the reassign from field anyway.
              // XXX: just clear the rebroadcast, but keep the timestamps for later stat.
              // val.slackChannelSent = null;  // clear the channel sent time, no re-broadcast if assigned
              if (val.slackChannelSent) {
                for (let channelEncoded in val.slackChannelSent) {
                  let slackSent = val.slackChannelSent[channelEncoded];
                  if (slackSent && slackSent.scheduleRebroadcast)
                    slackSent.scheduleRebroadcast = null;
                }
              }
              return val;
            }, undefined, false)
              .then(() => {
                logger.log('firebase lead assigned info set.');
                return ret;
              });
          }).then(function (ret) {
            /* slack response */
            let slackResp = slack.webhook(payload.response_url);
            let updatedMessage = payload.original_message;
            updatedMessage.replace_original = true;
            delete updatedMessage.attachments[0].actions;
            updatedMessage.attachments[0].fields = updatedMessage.attachments[0].fields || [];
            let lastField = updatedMessage.attachments[0].fields[updatedMessage.attachments[0].fields.length - 1];
            if (lastField && lastField.title == "Assigned To") {
              lastField.value = lead.assignedTo;
            }
            else {
              updatedMessage.attachments[0].fields.push({
                "title": "Assigned To",
                "value": lead.assignedTo,
              });
            }
            logger.log('updated slack message:', updatedMessage);
            lead.fubUrl = fb.cfg.crm.siteUrl + '/2/people/view/' + lead.idInCrm;
            let notifyMessage = nunjucks.render(config.slack.leadAssignedMsg, {
              statusCode: ret.statusCode,
              assignedTo: lead.assignedTo,
              currentUser: username,
              lead: lead
            });
            logger.log('notify message:', notifyMessage);
            if (username == lead.assignedTo) {
              slackUserLastSuccessClaim[payload.user.id] = Date.now();
              if (!fb.cfg.lead.claim.ignoreUserPerDayChannels || !fb.cfg.lead.claim.ignoreUserPerDayChannels[payload.channel.name]) {
                fb.cfgRef.child('lead/claim/userPerDay').child(payload.user.id).transaction(val => {
                  val = val || {};
                  if (!val.date || val.date === today) {
                    //val.numClaimed = val.numClaimed || 0;
                    //val.numClaimed += 1;
                    val.claimed = val.claimed || {};
                  }
                  else {
                    val.uncapped = null;
                    //val.numClaimed = 1;
                    val.claimed = {};
                    val.credits = null;
                  }
                  val.date = today;
                  val.claimed[lead.idInCrm] = true;
                  val.username = payload.user.name;
                  val.numClaimed = Object.keys(val.claimed).length;
                  return val;
                }, undefined, false);
                logger.log('increase claim userPerDay stat:', payload.user.id, username);
              }
              else {
                logger.log('ignore increase claim userPerDay by channel:', payload.channel.name);
              }
            }
            return slackResp.send(notifyMessage).then(function (ret) {
              logger.log('claim result sent to slack action user:', payload.user.name, ret);
              return slackResp.send(updatedMessage).then(function (ret) {
                logger.log('slack message updated ret:', ret);
                let leadAssigned = assignedLeads[lead.id];
                assignedLeads[lead.id] = true;
                if (!leadAssigned && username == lead.assignedTo && lead.slackSent && typeof lead.slackSent == 'object' && fb.cfg.lead.leadAssignedMsg) {
                  for (let ts in lead.slackSent) {
                    let channel = lead.slackSent[ts];
                    if (channel == payload.channel.id) {
                      ts = ts.slice(0, -6) + '.' + ts.slice(-6);
                      ts = +ts;
                      let duration = Date.now() / 1000 - ts;
                      logger.log('slack sent timestamp detected:', ts, duration);
                      for (let i in fb.cfg.lead.leadAssignedMsg) {
                        let msgDef = fb.cfg.lead.leadAssignedMsg[i];
                        if (!msgDef.message)
                          continue;
                        if (msgDef.delayMin === undefined || msgDef.delayMin <= duration) {
                          if (msgDef.delayMax === undefined || msgDef.delayMax > duration) {
                            let messageTempl = msgDef.message;
                            if (typeof messageTempl == 'object') {
                              // it's array or object, we random choose a value of it.
                              messageTempl = messageTempl[random.pick(Object.keys(messageTempl))];
                            }
                            let assignedMsg = {
                              text: nunjucks.render(messageTempl, {
                                assignedTo: lead.assignedTo
                              }),
                              "replace_original": false,
                              "response_type": 'in_channel'
                            };
                            logger.log('decided assigned message by duration:', assignedMsg);
                            return slackResp.send(assignedMsg).then(function (ret) {
                              logger.log('assigned message sent ret:', ret);
                            });
                          }
                        }
                      }
                      break;
                    }
                  }
                }
              });
            });
          });
        }).catch(function (err) {
          logger.warn('claim lead failed:', err, err.stack);
          let slackResp = slack.webhook(payload.response_url);
          /*let msg = ret.body.errorMessage ? ret.body.errorMessage : 'Failed to claim the lead.';
          // Invalid value for 'assignedTo
          if (msg.match(/^Invalid value for 'assignedTo/))
            msg = 'Can not locate your crm account by your slack profle full name. Make sure you setup same full name in both your slack profile and your crm account.';*/
          let notifyMessage = nunjucks.render(config.slack.claimFailedMsg, {
            error: err.toString()
          });
          logger.log('claim failure notify message:', notifyMessage);
          return slackResp.send(notifyMessage).then(function (ret) {
            logger.log('failure message sent to slack action user:', payload.user.name, ret);
          }).catch(function (err) {
            logger.warn('send claim failure message to slack failed:', err, err.stack);
          });
        });
    });
    resp.send('');
  });

  let webhookUrl = config.webRootUrl + '/fub/webhook';

  app.get('/fub/webhook/create', function (req, resp) {
    crm.interceptor({ call: 'createWebhook', type: 'peopleCreated', webhookUrl: webhookUrl, ignoreLogs: false, system: systemName })
    // crm.createWebhook('peopleCreated', webhookUrl, false, systemName)
      .then(ret => {
        logger.log('***** peopleCreated', webhookUrl)
        return crm.interceptor({ call: 'createWebhook', type: 'peopleUpdated', webhookUrl: webhookUrl, ignoreLogs: false, system: systemName })
        // return crm.createWebhook('peopleUpdated', webhookUrl, false, systemName);
      })
      .then(ret => {
        resp.json(ret);
      })
      .catch(err => {
        logger.warn(err, err.stack);
        errorResponse(err, resp);
      });
  });

  app.get('/fub/webhook/other', function (req, resp) {
    crm.interceptor({ call: 'createWebhook', type: 'textMessagesUpdated', webhookUrl: webhookUrl, ignoreLogs: false, system: systemName })
    // crm.createWebhook('textMessagesUpdated', webhookUrl, false, systemName)
      .then(ret => {
        logger.log('***** textMessages', webhookUrl)
        return crm.interceptor({ call: 'createWebhook', type: 'emailsUpdated', webhookUrl: webhookUrl, ignoreLogs: false, system: systemName })
        // return crm.createWebhook('emailsUpdated', webhookUrl, false, systemName);
      })
      .then(ret => {
        resp.json(ret);
      })
      .catch(err => {
        logger.warn(err, err.stack);
        errorResponse(err, resp);
      });
  });

  app.post('/fub/webhook', function (req, resp) {
    logger.log('got fub webhook post:', req.body);
    let event = req.body;
    // we only handle lead which was not in firebase, so
    // and the lead is assigned to certain user
    let delay = fb.cfg.crm.webhookDelay || (fb.cfg.lead.priceToChannel || fb.cfg.lead.zipCodeToChannel ? 2000 : 0);
    // XXX: since we possiblly introduce some large delay, then we have to response to the webhook request in limited time.
    let respSent = delay >= 5000;
    if (respSent)
      resp.send('');
    return Promise.resolve()
      // delay 2 seconds since the price data may comes later?
      .delay(delay)
      .then(() => {
        let leadIds = {};
        if (event.event === 'peopleCreated') {
          event.resourceIds.forEach(leadId => {
            leadIds[leadId] = null;
          });
          return leadIds;
        }
        if (event.event === 'peopleUpdated') {
          logger.log("peopleUpdatedFiredHere");
          return Promise.map(event.resourceIds, leadId => {
            return leadsRef.orderByChild('idInCrm').equalTo(leadId).once('value').then(snap => snap.val())
              .then(ret => {
                leadIds[leadId] = ret ? Object.keys(ret)[0] : null;
              });
          })
            .then(() => {
              return leadIds;
            });
        }
      })
      .then(leadIds => {
        logger.log('new leadIds in FUB:', leadIds)
        if (leadIds && Object.keys(leadIds).length > 0) {
          return Promise.mapSeries(Object.keys(leadIds), leadId => {
            let fbLeadId = leadIds[leadId]
            return crm.interceptor({ call: 'getLeadInfo', leadId: leadId }).then(lead => {
              // BEGIN: code to send slack message on peopleUpdated event
              if (leadId) {
                leadCommonDataRef.orderByChild('id').equalTo(lead.id).once('value').then(snap => snap.val()).then(val => {
                  if (val) {
                    let firebaseLeadKey = Object.keys(val)[0]
                    let leadObject = val[firebaseLeadKey]
                    if (leadObject) {
                      try {
                        let slackMessage = ''
                        let leadNewEmail = lead.emails && lead.emails[0] ? lead.emails[0].value : null
                        let leadNewPhone = lead.phones && lead.phones[0] ? lead.phones[0].value : null
                        let leadNewName = lead.name ? lead.name : null
                        let leadNewEmailTrimmed = leadNewEmail.trim().toLowerCase()
                        let leadNewPhoneTrimmed = leadNewPhone.trim().toLowerCase()
                        let leadNewNameTrimmed = leadNewName.trim().toLowerCase()

                        let leadOldEmail = ''
                        let leadOldPhone = ''
                        let leadOldName = ''
                        if (leadObject.oldName) {
                          leadOldEmail = leadObject.oldEmail.trim().toLowerCase()
                          leadOldPhone = leadObject.oldPhone.trim().toLowerCase()
                          leadOldName = leadObject.oldName.trim().toLowerCase()

                          if (leadOldName !== leadNewNameTrimmed) {
                            slackMessage = 'updated name from ' + leadObject.oldName + ' to ' + lead.name
                          } else if (leadOldPhone !== leadNewPhoneTrimmed) {
                            slackMessage = 'updated phone from ' + leadObject.oldPhone + ' to ' + leadNewPhone
                          } else if (leadOldEmail !== leadNewEmailTrimmed) {
                            slackMessage = 'updated email from ' + leadObject.oldEmail + ' to ' + leadNewEmail
                          }
                        } else {
                          if (event.event === 'peopleCreated') {
                            let leadEmail = lead.emails && lead.emails[0] ? lead.emails[0].value : null
                            let leadPhone = lead.phones && lead.phones[0] ? lead.phones[0].value : null
                            leadCommonDataRef.push().set({
                              id: lead.id,
                              oldName: lead.name,
                              oldPhone: leadPhone,
                              oldEmail: leadEmail,
                              oldSource: lead.source,
                              oldPrice: lead.price,
                              oldAssignedUserId: lead.assignedUserId
                            })
                          }
                        }

                        if (slackMessage.length > 0) {
                          // save entries for oldName1, oldEmail1 and oldPhone1 inside if clause
                          // this is not outside if clause because we must not update the firebase
                          // if none of name, email or phone have been updated (for optimisation)
                          leadCommonDataRef.child(firebaseLeadKey).update({ 'oldPhone': leadNewPhone, 'oldEmail': leadNewEmail, 'oldName': lead.name })
                          // If its one among Name, phone, or email address, compose slack message
                          slackMessage = 'Agent ' + lead.assignedTo + ' ' + slackMessage
                          let linkToLead = fb.cfg.crm.siteUrl + '/2/people/view/' + lead.id
                          slackMessage = slackMessage + ' Link to lead: ' + linkToLead
                          logger.log('peopleUpdated event slack message to be written: ' + slackMessage)
                          // send message in slack channel
                          let params = nunjucks.render(config.slack.genericMessage, {
                            channel: '@UGVSW37T7',
                            text: slackMessage
                          })

                          params.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken
                          slack.api.chat.postMessage(params).then(ret => {
                            logger.info('peopleUpdated audit log written to slack:', ret)
                          })

                          params = nunjucks.render(config.slack.genericMessage, {
                            channel: fb.cfg.crm.auditChannel,
                            text: slackMessage
                          })

                          params.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken
                          slack.api.chat.postMessage(params).then(ret => {
                            logger.info('peopleUpdated audit log written to slack:', ret)
                          })
                        }
                      } catch (e) {
                        logger.log('Error occurred sending slack message: ' + e)
                      }
                    } else {
                      if (event.event === 'peopleCreated') {
                        let leadEmail = lead.emails && lead.emails[0] ? lead.emails[0].value : null
                        let leadPhone = lead.phones && lead.phones[0] ? lead.phones[0].value : null
                        leadCommonDataRef.push().set({
                          id: lead.id,
                          oldName: lead.name,
                          oldPhone: leadPhone,
                          oldEmail: leadEmail,
                          oldSource: lead.source,
                          oldPrice: lead.price,
                          oldAssignedUserId: lead.assignedUserId
                        })
                      }
                    }
                  } else {
                    if (event.event === 'peopleCreated') {
                      let leadEmail = lead.emails && lead.emails[0] ? lead.emails[0].value : null
                      let leadPhone = lead.phones && lead.phones[0] ? lead.phones[0].value : null
                      leadCommonDataRef.push().set({
                        id: lead.id,
                        oldName: lead.name,
                        oldPhone: leadPhone,
                        oldEmail: leadEmail,
                        oldSource: lead.source,
                        oldPrice: lead.price,
                        oldAssignedUserId: lead.assignedUserId
                      })
                    }
                  }
                })
              }
              // END: code to send slack message on peopleUpdated event
            })
          })
        }
      })
      .then(ret => {
        if (!respSent) {
          resp.send('')
        }
      })
      .catch(err => {
        logger.warn(err, err.stack)
        if (!respSent) {
          return errorResponse(err, resp)
        }
      })
  })

  app.get('/leads/:id', function (req, resp) {
    logger.log('lead check:', req.params.id);
    return Promise.resolve().then(function () {
      return leadsRef.orderByChild('no').equalTo(+req.params.id).once('value');
    })
      .then(snap => {
        if (snap.val() === null)
          return leadsRef.orderByChild('idInCrm').equalTo(+req.params.id).once('value');
        return snap;
      })
      .then(snap => {
        if (snap.val() === null)
          return resp.send('Not Found');
        resp.json({
          key: snap.key,
          val: snap.val()
        });
      });
  });

  app.get('/geocode', (req, resp) => {
    return geocode.geocode({
      address: req.query.address
    })
      .then(geoInfo => {
        resp.json(geoInfo);
      })
      .catch(err => {
        logger.warn(err, err.stack);
        return errorResponse(err, resp);
      });
  });

  app.get('/newLead/config', function (req, resp) {
    logger.log('lead cfg req');
    fb.initCfg.then(() => {
      let channels = {};
      if (fb.cfg.lead.sourceToChannel) {
        for (let source in fb.cfg.lead.sourceToChannel) {
          channels[fb.cfg.lead.sourceToChannel[source]] = true;
        }
      }
      if (fb.cfg.lead.priceToChannel) {
        for (let ruleName in fb.cfg.lead.priceToChannel) {
          let rule = fb.cfg.lead.priceToChannel[ruleName];
          if (rule.channel) {
            channels[rule.channel] = true;
          }
        }
      }
      if (fb.cfg.lead.zipCodeToChannel) {
        for (let zipCode in fb.cfg.lead.zipCodeToChannel) {
          channels[fb.cfg.lead.zipCodeToChannel[zipCode]] = true;
        }
      }
      if (fb.cfg.lead.defaultChannel) {
        channels[fb.cfg.lead.defaultChannel] = true;
      }
      resp.json({
        sources: fb.cfg.lead.sources || ['Call In Lead', 'Zillow Call In', 'realtor.com', 'realtor'],
        channels: Object.keys(channels).filter(channel => channel.slice(0, 1) !== '@')
      });
    });
  });

  app.post('/newLead', function (req, resp) {
    /* create new lead */
    logger.log('*****got new lead req:', req.body);
    let lead = req.body;
    Promise.resolve().then(() => {
      if (!lead.firstName || !lead.phone)
        throw new Error('First name and phone is required to create new lead.');
      let newLead = {
        name: [lead.firstName || '', lead.lastName || ''].join(' ').trim(),
        phone: lead.phone,
        email: lead.email || null,
        message: lead.message || null,
        address: lead.address || null,
        price: lead.price || null,
        source: lead.source || 'Manual',
        channel: !lead.channel || lead.channel === 'AUTO' ? null : lead.channel,
        createdAt: fb.NOW
      };
      if(lead.assignedTo && !_.includes(fb.cfg.georgiaar.monitorFUBLeadOwner, lead.assignedTo)) {
          newLead.assignedTo = lead.assignedTo;
      }
      let leadRef = leadsRef.push();
      logger.log('create new lead:', leadRef.key, newLead);
      return leadRef.set(newLead)
        .then(ret => {
          logger.log('new lead created:', leadRef.key, ret);
          resp.json({
            id: leadRef.key
          });
        });
    })
      .catch(err => {
        logger.warn(err, err.stack);
        return errorResponse(err, resp);
      });
  });

  app.post('/notifyPhpBridgeToSlack', function (req, resp) {
    resp.status(200).send('OK')
    console.log('notifyPhpBridgeToSlack')
    let data = req.body
    const key = data.key
    if (key === 'RzhcEg5EEAwMZv8QsrHwXZa2Y9Mfl2Nq') {
      let slackMessage = 'PHP Bridge MySQL service restarted as it was stopped'
      let params = nunjucks.render(config.slack.genericMessage, {
        channel: fb.cfg.slack.devChannel,
        text: slackMessage
      })

      params.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken
      slack.api.chat.postMessage(params).then(ret => {
        logger.info('notifyPhpBridgeToSlack written to slack:', ret)
      })
    }
  })

  // FollowUpBoss webhook 'callsCreated' to listen to call created event
  app.post('/fub/callsCreatedEvent', async (request, response) => {
    response.status(200).send('OK')
    try {
      let leadResponsePromises = []
      let repeatCallReminderHours = fb.cfg.lead.repeatCallRemiderHours
      for (var resourceIdIndex = 0; resourceIdIndex < request.body.resourceIds.length; resourceIdIndex++) {
        let callId = request.body.resourceIds[resourceIdIndex]
        try {
          const response = await crm.interceptor({ call: 'getCall', id: callId, ignoreLogs: false, system: systemName })
          let responseParsed = JSON.parse(response)
          console.log('responseParsed.isIncoming = ', responseParsed.isIncoming)
          if (responseParsed.isIncoming === false) {
            console.log('called = ', responseParsed.isIncoming)

            let callJson = {
              leadId: responseParsed.personId,
              fubCallId: responseParsed.id,
              agentId: responseParsed.userId,
              duration: responseParsed.duration,
              agentName: responseParsed.userName
            }

            db.call.create(callJson).then(result => console.log('call log recorded with call id ', responseParsed.id))

            console.log('Repeat call remider logic here')
            let firebaseLeadSnapshot = await fb.leadCommonDataRef.orderByChild('id').equalTo(responseParsed.personId).once('value')
            let firebaseLead = firebaseLeadSnapshot.val()
            console.log('firebaseLead=', JSON.stringify(firebaseLead))

            if (firebaseLead) {
              console.log('firebaseLead=IN')
              let firebaseLeadKey = Object.keys(firebaseLead)[0]
              let leadReminderOn = firebaseLead[firebaseLeadKey].reminderOn

              if (leadReminderOn) {
                console.log('leadReminderOn=', leadReminderOn)
                console.log('duration=', responseParsed.duration)

                if (responseParsed.duration < 120) {
                  console.log('leadReminderOn=IN', responseParsed.duration)
                  leadResponsePromises.push(crm.interceptor({ call: 'getLeadInfo', leadId: responseParsed.personId, ignoreLogs: false, system: systemName, fields: 'allFields' }))
                } else {
                  fb.leadCommonDataRef.child(firebaseLeadKey).update({ 'reminderOn': false })
                }
              }
            }
          }
        } catch (err) {
          console.log('abc-error: ', err)
        }
      }

      console.log('leadResponsePromises ', leadResponsePromises)

      let leadResponses = []
      Promise.all(leadResponsePromises).then(async function (results) {
        console.log('leadResponsePromises=', leadResponsePromises)
        console.log('results=', results)
        leadResponses = results
        leadResponses = leadResponses.filter(lead => ((lead.createdVia !== 'Manually') && (lead.createdVia !== 'Import')))
        let cityPromises = []
        for (let i = 0; i < leadResponses.length; i++) {
          let curResponse = leadResponses[i]
          cityPromises.push(
            crm.interceptor({ call: 'getEvents', leadId: curResponse.id, type: [], ignoreLogs: true, system: systemName }).then(ret => {
              let event = ret.events.filter(event => !!event.property)[0]
              let returnedEventObj
              if (!!event && !!event.property) {
                returnedEventObj = {
                  city: event ? event.property.city : null,
                  street: event ? event.property.street : null,
                  zipcode: event ? event.property.code : null
                }
              } else {
                returnedEventObj = {
                  city: null,
                  street: null,
                  zipcode: null
                }
              }
              return returnedEventObj
            }).catch((err) => {
              console.log(err)
              return {
                city: null,
                street: null,
                zipcode: null
              }
            })
          )
        }

        let fromNumbers = [], streets = [], zipcodes = [], citiesArray = []
        let cities1 = ['Athens', 'Watkinsville', 'Oconee', 'Jasper'].map(x => x.toUpperCase())
        let AthensNumber = '+17066216658'
        let cities2 = ['Augusta', 'Evans', 'Grovetown', 'Hepzibah'].map(x => x.toUpperCase())
        let AugustaNumber = '+17062142837'
        let DefaultNumber = await fb.cfgRef.child('webhooks/peopleCreated/initialText').once('value').then(snap => snap.val().fromNumber)

        Promise.all(cityPromises).then(cities => {
          if (!!cities) {
            cities.forEach((cit) => {
              try {
                let theNumber, theCity, theStreet = null
                let city = cit.city
                theStreet = cit.street
                if (!!city) {
                  theCity = city.toUpperCase()
                  if (cities1.indexOf(theCity) > -1) {
                    theNumber = AthensNumber
                  } else if (cities2.indexOf(theCity) > -1) {
                    theNumber = AugustaNumber
                  } else {
                    theNumber = DefaultNumber
                  }
                } else {
                  theNumber = DefaultNumber
                }
                fromNumbers.push(theNumber)
                streets.push(theStreet)
                zipcodes.push((!!cit ? cit.zipcode : null))
                citiesArray.push((!!cit.city ? cit.city : 'None'))
              } catch (e) {
                logger.log('exception: ' + JSON.stringify(e))
              }
            })

            leadResponses.forEach((lead, index) => {
              console.log('CurLead=', JSON.stringify(lead))
              if (!!lead && !!lead.source && !!lead.phones[0]) {
                let src = lead.source.toUpperCase()
                let thePhone = lead.phones[0].value
                // This object stores mapping from source names to what should be sent to twilio inorder to have it pronounced properly in voice calls
                let announcementSrcObj = {
                  'THEAUGUSTAMLS.COM': 'The Augusta MLS',
                  'THEATHENSMLS.COM': 'The Athens MLS',
                  'THEATLANTAMLS.COM': 'The Atlanta MLS',
                  'METHODATLANTA.NET': 'Method Atlanta dot net',
                  'GEORGIAAR': 'Georgia A R',
                  'NEWNWINDIANALISTINGS.COM': 'New N W Indiana Listings'
                }
                let newSrc = lead.source
                if (announcementSrcObj[src]) {
                  newSrc = announcementSrcObj[src]
                }
                crm.interceptor({ call: 'getUserInfo', userId: lead.assignedUserId, ignoreLogs: true }).then((user) => {
                  if (user.phone) {
                    crm.interceptor({ call: 'getCalls', leadId: lead.id, ignoreLogs: false, system: systemName }).then((responseLeadCallsData) => {
                      let responseLeadCallsParsed = JSON.parse(responseLeadCallsData)
                      if (responseLeadCallsParsed.calls.length <= 5) {
                        let nowTime = localMoment().format('HH:mm')
                        let silentTime = fb.cfg.lead.rebroadcast.silentTime
                        var now = new Date()
                        now.setHours(now.getHours() + parseInt(repeatCallReminderHours[responseLeadCallsParsed.calls.length + 1]))
                        nowTime = localMoment(now).format('HH:mm')
                        console.log('nowTime + 4 = ', nowTime)
                        let reminderDate = ''
                        if (silentTime) {
                          if (silentTime.from <= silentTime.to) {
                            if (nowTime >= silentTime.from && nowTime < silentTime.to) {
                              reminderDate = localMoment(now).format('YYYY-MM-DDT' + silentTime.to)
                            }
                          } else {
                            if (nowTime >= silentTime.from || nowTime < silentTime.to) {
                              reminderDate = localMoment(now).format('YYYY-MM-DDT' + silentTime.to)
                            }
                          }
                        }
                        var reminderNewDate = moment(new Date()).format('YYYY-MM-DDTHH:mm')
                        if (reminderDate) {
                          reminderNewDate = new Date(reminderDate)
                          var timeNonBusinessHours = nowTime.split(':')
                          console.log('hours = ', timeNonBusinessHours[0])
                          console.log('mins = ', timeNonBusinessHours[1])
                          reminderNewDate.setHours(reminderNewDate.getHours() + parseInt(timeNonBusinessHours[0]))
                          reminderNewDate.setMinutes(reminderNewDate.getHours() + parseInt(timeNonBusinessHours[1]))
                          reminderNewDate = moment(reminderNewDate).format('YYYY-MM-DDTHH:mm')
                          console.log('reminderNewDate = ', reminderNewDate)
                        }
                        let promptMsg = 'New lead from ' + newSrc + ' The name is ' + lead.name + ' Looking in ' + citiesArray[index] + ' , press any key when you are ready to be connected.'
                        scheduleReminderCall({
                          machineDetection: 'Enable',
                          url: util.createUrl(config.webRootUrl + '/twilio/voice?', {
                            promptMsg: encodeURIComponent(promptMsg),
                            leadId: lead.id,
                            assignedUserId: lead.assignedUserId,
                            assignedTo: encodeURIComponent(lead.assignedTo),
                            phone: encodeURIComponent(thePhone),
                            callerId: encodeURIComponent(user.phone),
                            from: encodeURIComponent(fromNumbers[index])
                          }),
                          to: user.phone,
                          from: fromNumbers[index],
                          record: true,
                          statusCallback: util.createUrl(config.webRootUrl + '/twilio/voice?', {
                            statusTxt: 'completeOrAnswered',
                            leadId: lead.id,
                            assignedUserId: lead.assignedUserId,
                            assignedTo: encodeURIComponent(lead.assignedTo),
                            phone: encodeURIComponent(thePhone),
                            callerId: encodeURIComponent(user.phone),
                            from: encodeURIComponent(fromNumbers[index]),
                            promptMsg: encodeURIComponent(promptMsg),
                            leadSrc: src,
                            reminderCall: true
                          }),
                          statusCallbackMethod: 'POST',
                          statusCallbackEvent: ['completed', 'answered']
                        }, { address: newSrc, ...lead }, reminderNewDate)
                      }
                    })
                  }
                })
              }
            })
          }
        })
      })
    } catch (e) {
      logger.log('Error occurred in /fub/callsCreatedEvent', e)
    }
  })

  app.get('/fub/getAgentCalls/:id', async (request, response) => {
    response.status(200).send('OK')
    let agentId = request.params.id
    console.log('req.params.id', request.params.id)
    const limiter = new Bottleneck({
      maxConcurrent: 1,
      minTime: 20000
    })
    crm.interceptor({ call: 'getUsers' }).then((responseData) => {
      let usersResponse = JSON.parse(responseData)
      const allUsers = usersResponse.users
      for (var i = 0; i < allUsers.length; i++) {
        limiter.schedule(getAgentCalls, allUsers[i].id, allUsers[i].name).then((response) => {})
      }
    })
    // getAgentCalls(agentId)
  })

  // FollowUpBoss webhook 'eventsCreated' to listen to website activity events
  app.post('/eventCreated', async (request, response) => {
    response.status(200).send('OK')
    try {
      console.log('uri: ', request.body.uri)
      for (var resourceIdIndex = 0; resourceIdIndex < request.body.resourceIds.length; resourceIdIndex++) {
        let curEventId = request.body.resourceIds[resourceIdIndex]
        crm.interceptor({ call: 'getEvent', id: curEventId, ignoreLogs: false, system: systemName }).then(async (responseData) => {
          let responseParsed = responseData
          let eventType = responseParsed.type
          let eventLeadId = responseParsed.personId
          console.log('eventType: ', eventType)
          console.log('eventLeadId: ', eventLeadId)
          if (eventType === 'created') {
            let fieldQuery = { fields: 'id,source,emails,phones,name,price,assignedUserId,customLeadQuickloginLink,customMobileAppLink' }
            crm.interceptor({ call: 'getLeadFieldsInfo', leadId: eventLeadId, fieldQuery: fieldQuery, ignoreLogs: false, system: systemName }).then((responseLeadInfoData) => {
              let leadSource = responseLeadInfoData.source
              console.log('leadSource: ', leadSource)
              console.log('responseLeadEventData.events[i].source: ', responseData.source)
              if (leadSource !== responseData.source) {
                let eventMessage = responseData.message
                console.log('eventMessage: ', eventMessage)
                if (eventMessage.includes('Lead was created from') || eventMessage.includes('Lead was created.')) {
                  console.log('eventMessage: TRUE')
                  console.log('responseLeadInfoData.customLeadQuickloginLink: ', responseLeadInfoData.customLeadQuickloginLink)
                  console.log('responseLeadInfoData.customMobileAppLink: ', responseLeadInfoData.customMobileAppLink)
                  if (!_.isEmpty(responseLeadInfoData.customLeadQuickloginLink) && !_.isEmpty(responseLeadInfoData.customMobileAppLink)) {
                    let tokenNotes = 'Lead Quicklogin Link: <a href="' + responseLeadInfoData.customLeadQuickloginLink + '" target="_blank">' + responseLeadInfoData.customLeadQuickloginLink + '</a>'
                    tokenNotes += '\n</br><br>Mobile App Link: <a href="' + responseLeadInfoData.customMobileAppLink + '" target="_blank">' + responseLeadInfoData.customMobileAppLink + '</a>'
                    crm.interceptor({ call: 'addNote', leadId: eventLeadId, note: tokenNotes, isHtml: true, system: systemName, ignoreLogs: false })
                  }
                }
              }
            }).catch((err) => {
              logger.log('getEvents Error', err)
            })
          }
        }).catch((err) => {
          logger.log('getEvent Error', err)
        })
      }
    } catch (e) {
      logger.log('Error occurred in /fub/eventsCreatedEvent', e)
    }
  })
}

async function getAgentCalls (agentId, agentName) {
  var date = new Date()
  var last = new Date(new Date() - 6 * 24 * 60 * 60 * 1000)
  last.setHours(4, 0, 0, 0) // Setting 4 hours as timezone is set as UTC-04:00 for Sequelize connection so that hours will be set as mid-night 00:00:00
  let agentCalls = await db.call.findAll({
    where: {
      agentId: agentId,
      createdAt: { [Op.between]: [last, date] }
      // duration: { [Op.gt]: 40 }
    }
  }).then(function (agentCalls) {
    console.log('agentCalls = ', JSON.stringify(agentCalls))
    return agentCalls
  })

  agentCalls = agentCalls.filter((call) => call.duration > 40)
  let agentCallCount = agentCalls.length
  console.log('agentCalls.length = ', agentCalls.length)
  if (agentCallCount < 70) {
    console.log('agentName = ', agentName)
    slack.findUserByFullName(agentName).then((slackUser) => {
      if (slackUser) {
        console.log('slackUser.name = ', slackUser.name)
        const firebaseExemptCallAgents = fb.cfg.lead.claim.exemptAgentsCallCount
        const agentCallCountMsgMode = fb.cfg.lead.claim.agentCallCountMsgMode
        if (!firebaseExemptCallAgents.includes(agentName)) {
          console.log('inside TRUE')
          if (agentCallCountMsgMode === 'warning') {
            // slack.sendCallsMessage('agentCallCountWarning', { agentName: agentName, agentCallCount: agentCallCount, channel: '@UGVSW37T7' }).catch(() => console.log("couldn't find assigned agent in slack"))
            slack.sendCallsMessage('agentCallCountWarning', { agentName: agentName, agentCallCount: agentCallCount, channel: '@' + slackUser.name }).catch(() => console.log("couldn't find assigned agent in slack"))
          } else {
            // slack.sendCallsMessage('agentCallCountHard', { agentName: agentName, agentCallCount: agentCallCount, channel: '@UGVSW37T7' }).catch(() => console.log("couldn't find assigned agent in slack"))
            slack.sendCallsMessage('agentCallCountHard', { agentName: agentName, agentCallCount: agentCallCount, channel: '@' + slackUser.name }).catch(() => console.log("couldn't find assigned agent in slack"))
            let punishedSlackUser = {}
            punishedSlackUser[slackUser.name] = 30
            fb.ref.child('config').child('lead').child('claim').child('punishedUsers').update(punishedSlackUser)
          }
        }
      }
    })
  }
}

/**
 * @param text
 * this function will replace all texts within double curly braces {{ somevar }}
 * with $somevar
 */
function doubleCurlyToDollar(text) {
  var regex = /[^{\}]+(?=})/g;
  var matchArray = text.match(regex);
  let newText = text;
  if (matchArray) {
    matchArray.forEach(function (item, index) {
      newText = newText.replace("{{" + item + "}}", "$" + item.trim());
    });
  }
  return newText;
}

function dollarToDoubleCurly(text) {
  var regex = /\$\w+/g;
  let matches = text.match(regex);
  if (matches) {
    matches.forEach((item) => {
      item = item.trim();
      text = text.replace(item, "{{ " + item.replace("$", "") + " }}");
    });
  }
  return text;
}

function findLeadInCrm (lead) {
  if(lead) {
    if (lead.idInCrm) {
      // crm.getLeadInfo(lead.idInCrm, false, systemName,'allFields')
      return crm.interceptor({ call: 'getLeadInfo', leadId: lead.idInCrm, ignoreLogs: false, system: systemName, fields: 'allFields' }).then(function (info) {
        return info;
      }).catch(function (err) {
        logger.log('retrieve crm lead failed:', err, err.stack);
        return null;
      });
    } else {
      // crm.searchLeadInfo({email: encodeURIComponent(lead.email), phone: lead.phone}, false, systemName)
      return crm.interceptor({call: 'searchLeadInfo', searchQuery: {email: encodeURIComponent(lead.email),phone: lead.phone}, ignoreLogs: false, system: systemName})
        .then((info) => {
          if(info.people.length) {
            return info.people[0];
          } else {
            return null;
          }
        }).catch(error => {
          logger.log('##=>fetch error:',error);
          return null;
        });
    }
  } else {
    logger.log('lead is empty');
    return null;
  }
}

function handleRepeatLead (Lead, snap, timeStamp) {
  let timeGoodToCallNow = SendtextLead.timeGoodToCallNow(Lead.source)
  setTimeout(() => {
    snap.ref.once('value').then(function (fullLead) {
      let firebaseLead = fullLead.val()||{};
      if(Object.keys(firebaseLead).length) {
        firebaseLead.id = fullLead.key;
        let rSlack = require('slack');
        let Slack = new rSlack({ token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken })
        if(timeGoodToCallNow && firebaseLead.agentAllSlackSent &&firebaseLead.agentAllSlackSent.length) {
          logger.log('##=>Time good to call now',Lead.id);
          let AllMessages = []
          let newMessage = nunjucks.render(config.slack.newLeadMsg, {
            lead:firebaseLead,
            channel: firebaseLead.taddleSlackSent.channel
          });
          newMessage.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken;
          let agentMessages = _.cloneDeep(newMessage);
          _.forEach(firebaseLead.agentAllSlackSent,(value,index)=>{
            AllMessages.push(
              {
                ...agentMessages,
                channel:value.channel,
                ts:value.ts,
                text:'Your time is expired to initiate call.'
              }
            )
            delete AllMessages[index].attachments[0].actions;
            AllMessages[index].attachments.push({color: "danger", title: "Handed off to the ISA"});
            AllMessages[index].attachments = JSON.stringify(AllMessages[index].attachments);
          });
          _.forEach(AllMessages,(value)=>{
            slack.api.chat.update(value).then(()=>{}).catch((Err)=>{
              console.log("###>slack error",JSON.stringify(Err))
            })
          })

          newMessage.ts = firebaseLead.taddleSlackSent.ts;
          newMessage.attachments[0].actions = [
            {
              "name": "initiateCallISA",
              "text": "Initiate Call",
              "type": "button",
              "value": "initiateCallISA"
            },
            {
              "name": "sendToChannel",
              "text": "Send to channel",
              "type": "button",
              "value": "sendToChannel"
            }
          ];
          newMessage.attachments[0].fields.push(
            {
              "title": "Assigned To",
              "value": (Lead && Lead.assignedTo) || (firebaseLead && firebaseLead.assignedTo) || 'N/A',
              "short": true,
            },
            {
              "title": "Stage",
              "value": (Lead && Lead.stage) || 'N/A',
              "short": true,
            },
            {
              "title": "Lead Link",
              "value": (firebaseLead.idInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${firebaseLead.idInCrm}|client>`) ||
                (Lead && `<${fb.cfg.crm.siteUrl}/2/people/view/${Lead.id}|client>`) ||
                'N/A',
            },
          )

          newMessage.text = `*ISA members can call lead now.*`;
          newMessage.attachments = JSON.stringify(newMessage.attachments);
          slack.api.chat.update(newMessage).then(()=>{}).catch((Err)=>{
            console.log("###>slack error",JSON.stringify(Err))
          })
          snap.ref.update({
            agentAllSlackSent:[]
          }).then().catch((err)=>{
            logger.log('###=>set agentAllSlackSent to null',err);
          })
        }
        else if (firebaseLead.agentAllSlackSent && firebaseLead.agentAllSlackSent.length) {
          logger.log('##=>Silent time lead',Lead.id);
          let stage = Lead.stage.toLowerCase();
          if(stage==='lead' || stage==='contact') {
            _.forEach(firebaseLead.agentAllSlackSent,(value,index)=>{
              Slack.chat.delete({
                token: fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken,
                ts: value.ts,
                channel: value.channel,
              }).catch((err) => {
                logger.log("Delete message error", err);
                return;
              })
            });
            snap.ref.update({
              agentAllSlackSent:[],
              existingLeadBroadCast: true
            }).then(()=>{
              snap.ref.once('value').then((leadINLead)=>{
                newLeadsMethod(leadINLead).then((res) => {
                  logger.log('done broadcasting',res);
                  leadINLead.ref.update({existingLeadBroadCast: null}).then().catch(error => console.log(error));
                  slack.send('taddle', {
                    channel: fb.cfg.crm.taddleChannel,
                    message: `This <${fb.cfg.crm.siteUrl}/2/people/view/${firebaseLead.idInCrm}|Lead> got successfully broadcasted to appropriate channel.`
                  }).then(() => {});
                }).catch((error) => console.log(error))
              })
            }).catch((err)=>{
              logger.log('###=>set agentAllSlackSent to null',err);
            })
          }
          else if (stage==='alive' || stage==='engaged' || stage==='buying') {
            let newMessage = nunjucks.render(config.slack.newLeadMsg, {
              lead:firebaseLead,
              channel: firebaseLead.taddleSlackSent.channel
            });
            newMessage.ts = firebaseLead.taddleSlackSent.ts;
            newMessage.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken;
            newMessage.text = `*ISA members can call lead now.*`;
            newMessage.attachments[0].actions = [
              {
                "name": "initiateCallISA",
                "text": "Initiate Call",
                "type": "button",
                "value": "initiateCallISA"
              },
              {
                "name": "sendToChannel",
                "text": "Send to channel",
                "type": "button",
                "value": "sendToChannel"
              }
            ];
            newMessage.attachments[0].fields.push(
              {
                "title": "Assigned To",
                "value": (Lead && Lead.assignedTo) || (firebaseLead && firebaseLead.assignedTo) || 'N/A',
                "short": true,
              },
              {
                "title": "Stage",
                "value": (Lead && Lead.stage) || 'N/A',
                "short": true,
              },
              {
                "title": "Lead Link",
                "value": (firebaseLead.idInCrm && `<${fb.cfg.crm.siteUrl}/2/people/view/${firebaseLead.idInCrm}|client>`) ||
                  (Lead && `<${fb.cfg.crm.siteUrl}/2/people/view/${Lead.id}|client>`) ||
                  'N/A',
              },
            )
            newMessage.attachments = JSON.stringify(newMessage.attachments);
            console.log('###=>final new newMessage',JSON.stringify(newMessage));
            slack.api.chat.update(newMessage).then(()=>{}).catch((Err)=>{
              logger.log("###>slack error",JSON.stringify(Err))
            })
            snap.ref.update({
              agentAllSlackSent:[]
            }).then().catch((err)=>{
              logger.log('###=>set agentAllSlackSent to null',err);
            })
          }
        }
      } else {
        logger.log('firebase lead not found',Lead.id,firebaseLead);
      }
    }).catch(function (error) {
      logger.log("###=> lead fetch error",error)
    })
  },timeStamp * 1000)
}

const scheduleReminderCall = (payload, lead, remiderDateTime) => {
  slack.findUserByFullName(lead.assignedTo).then(async (slackUser) => {
    if (slackUser) {
      let firebaseLeadSnapshot = await reminderCalls.orderByChild('leadId').equalTo(lead.id).once('value')
      let firebaseLead = firebaseLeadSnapshot.val()
      if (firebaseLead) {
        let firebaseLeadKey = Object.keys(firebaseLead)[0]
        reminderCalls.child(firebaseLeadKey).remove()
      }
      reminderCalls.push().set({
        leadId: lead.id,
        payload,
        lead,
        callStatus: 'pending',
        agentNote: '',
        slackUserName: slackUser.name,
        reminderDateTime: remiderDateTime
      }).then(() => {
        console.log('successfully scheduled a call!')
      }).catch((error) => {
        console.log('error in scheduling the call', error)
      })
    }
  }).catch((error) => {
    console.log('error in fetching slack username:', error)
  })
}

module.exports = {
  init: init,
  getAgentCalls: getAgentCalls
}
