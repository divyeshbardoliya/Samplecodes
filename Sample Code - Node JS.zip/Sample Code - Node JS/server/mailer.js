var nodemailer = require('nodemailer');
var transport = require('./nodemailer-gmail-transport');

var transporter = nodemailer.createTransport(transport);

module.exports = transporter;
/*
transporter.sendMail({
  from: 'pmarks@georgiaar.com',
  to: 'ulion2002@gmail.com',
  subject: 'Test2',
  text: 'Email test content\n\nend line'
});*/