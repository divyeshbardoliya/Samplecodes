var config = require('config');
var firebase = require("firebase-admin");
//var Queue = require('firebase-queue');
var logger = require('./log');
var fbEvents = new (require('events').EventEmitter);
var _ = require('lodash');
var jsonDiff = require('json-diff');
logger.log('NODE_ENV: ' + config.util.getEnv('NODE_ENV'));
//logger.log(config);

firebase.initializeApp({
  credential: firebase.credential.cert(config.firebase.serviceAccount),
  databaseURL: config.firebase.databaseURL
});

var FB = firebase.database().ref();
FB.child('.info/connected').on("value", function(snap) {
  if (snap.val() === true) {
    logger.log("FB connected");
  } else {
    logger.log("FB not connected");
  }
});
if (config.firebase.rootPath)
  FB = FB.child(config.firebase.rootPath);
var fbCfgRef = FB.child('config');

function onConfig(snap) {
  var newCfg = snap.val();
  var oldCfg = exports.cfg;
  exports.cfg = newCfg;
  if (!_.isEqual(newCfg, oldCfg)) {
  //if (newCfg) {
    if (oldCfg) {
      //logger.log('fbCfg:', newCfg);
      logger.log('fbCfg updated:', jsonDiff.diffString(oldCfg, newCfg));
    }
    else {
      //logger.log('fbCfg:', newCfg);
      fbEvents.emit('cfgLoaded', newCfg); // should only run this once
    }
    fbEvents.emit('cfgUpdated', newCfg, oldCfg, jsonDiff.diff(oldCfg, newCfg));
    //}
  }
  return newCfg;
}

fbCfgRef.on('value', onConfig);

var initialCfg = fbCfgRef.once('value').then(onConfig);

var queueRef = FB.child('queue');

var leadsRef = FB.child('leads');
var callsRef = FB.child('calls');
var agentCallsRef = FB.child('agentCalls');
var leadCommonDataRef = FB.child('leadCommonData')

function toFK(id) {
  return id.toString().trim().replace(/\./g, '<dot>').replace(/#/g, '<dash>');
}

function fromFK(id) {
  return id.replace(/<dot>/g, '.').replace(/<dash>/g, '#');
}

var exports = {
  ref: FB,
  cfg: undefined,
  initCfg: initialCfg,
  NOW: firebase.database.ServerValue.TIMESTAMP,
  cfgRef: fbCfgRef,
  toFK: toFK,
  fromFK: fromFK,
  events: fbEvents,
  leadsRef: leadsRef,
  leadCommonDataRef: leadCommonDataRef,
  callsRef: callsRef,
//  Queue: Queue,
  queueRef: queueRef,
  agentCallsRef: agentCallsRef,
  tasksRef: queueRef.child('tasks')
};

module.exports = exports;
