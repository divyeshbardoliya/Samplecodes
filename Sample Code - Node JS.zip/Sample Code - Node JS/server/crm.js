'use strict'
var config = require('config')
const _ = require('lodash')
var fb = require('./firebase')
var nunjucks = require('./nunjucks')
var logger = require('./log')
var rp = require('request-promise')
const Bottleneck = require('bottleneck')
const moment = require('moment-timezone')
const limiter = new Bottleneck()

const interceptor = function (requestParams) {
  let apiCall = requestParams.call
  let params = {}
  let configRequest = {}

  switch (apiCall) {
    case 'addNote':
      params['body'] = {
        'personId': requestParams.leadId,
        'body': requestParams.note,
        'isHtml': requestParams.isHtml
      }
      configRequest = config.crm.addNoteRequest
      break
    case 'getUsers':
      configRequest = config.crm.getUsers
      break
    default:
      // code block
  }

  params['system'] = fb.cfg.crm.systemId
  params['apiKey'] = requestParams.apiKey || fb.cfg.crm.apiKey

  params['xsystem'] = fb.cfg.crm.xSystem
  params['xsystemkey'] = fb.cfg.crm.xSystemKey

  let request = nunjucks.render(configRequest, params)
  let funId = apiCall + moment.tz(new Date(), fb.cfg.timezone).format('YYYYMMDDHHmmssS') + '_' + Math.floor(Math.random() * 1000) + 1
  if (requestParams.call === 'postNewLead' && (!requestParams.lead.address || !requestParams.lead.city)) {
    delete request.body.person.tags
    delete request.body.property
  }

  const result = limiter.schedule((funId) => rp(request)).then((response) => {
    console.log('x-ratelimit-limit = ', response.headers['x-ratelimit-limit'])
    console.log('x-ratelimit-remaining = ', response.headers['x-ratelimit-remaining'])
    let xRateLimitRemaining = response.headers['x-ratelimit-remaining']
    if (apiCall === 'getEvent' || apiCall === 'getEvents') {
      if (xRateLimitRemaining > 5) {
        limiter.updateSettings({ maxConcurrent: 2, minTime: 10 })
      }
      if (xRateLimitRemaining <= 5) {
        limiter.updateSettings({ maxConcurrent: 2, minTime: 1050 })
      }
    } else {
      if (xRateLimitRemaining > 10) {
        limiter.updateSettings({ maxConcurrent: 2, minTime: 10 })
      }
      if (xRateLimitRemaining <= 10) {
        limiter.updateSettings({ maxConcurrent: 2, minTime: 850 })
      }
    }

    if (requestParams.ignoreLogs) {
      logger.log('retrieve  ' + apiCall + ' ret:', response)
    }
    if (apiCall === 'postNewLead') {
      return response
    } else {
      return response.body
    }
  }).catch(error => {
    console.log('##fetch error:', error)
    return null
  })

  return result
}

limiter.on('failed', async (error, jobInfo) => {
  const id = jobInfo.options.id
  console.warn(`Job ${id} failed: ${error}`)
  if (jobInfo.retryCount <= 4) { // Here retry upto 4 times
    let jumpTime = Math.floor(Math.random() * 1000) + 61000
    console.log(`Retrying job ${id} in ${jumpTime}ms!`)
    return jumpTime
  }
})

limiter.on('retry', (error, jobInfo) => console.log(`Now retrying ${jobInfo.options.id}` + error))

module.exports = {
  interceptor: interceptor
}
