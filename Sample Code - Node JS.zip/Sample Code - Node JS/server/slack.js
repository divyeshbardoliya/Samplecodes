"use strict";
const config = require('config');
const nunjucks = require('./nunjucks');
const logger = require('./log');
const Promise = require('bluebird');
const errorResponse = require('./utils').errorResponse;
const fb = require('./firebase');
const rp = require('request-promise');
const _ = require('lodash');

const SlackAPI = require('slack-api').promisify();


function Slack(hook_url, http_proxy_options) {
  this.hook_url = hook_url;
}

Slack.prototype.send = function(message) {
  let option = {
    url: this.hook_url,
    json: true,
    body: message
  };

  return rp.post(option);
};


let slackCfgRef = fb.cfgRef.child('slack');

let slacks = {};


function sendCallsMessage (msgType, context) {
  return Promise.resolve().then(async function () {
    let msgTempl = config.slack[msgType + 'Msg']
    if (!msgTempl) {
      return Promise.reject(new Error('Slack msg ' + msgType + ' not configured'))
    }
    let slackMsg = nunjucks.render(msgTempl, context)
    logger.log('rendered slack msg:', slackMsg)
    slackMsg.token = fb.cfg.slack.authInfo[fb.cfg.slack.teamId].accessToken
    slackMsg.as_user = false
    return SlackAPI.chat.postMessage(slackMsg)
  })
}

module.exports = {
  init: init,
  api: SlackAPI,
  webhook: getSlackWebhook,
  send: sendMessage,
  sendCallsMessage: sendCallsMessage,
  isAdmin: isAdmin,
  allowCommand: allowCommand,
  findUserByName: getSlackUserByName,
  findUserByFullName: getSlackUserByFullName
};
