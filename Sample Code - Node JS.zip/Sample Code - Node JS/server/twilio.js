var fb = require('./firebase');
//var logger = require('./log');
var twilio = require('twilio');

const LookupsClient = twilio.LookupsClient;

var client = null;
let lookups = null;
var twiml = null;
fb.events.on('cfgUpdated', function (cfg) {
  if (cfg.twilio) {
    module.exports.client = client = new twilio.RestClient(cfg.twilio.accountSId, cfg.twilio.authToken);
    module.exports.twiml = twiml = new twilio.TwimlResponse();
    module.exports.lookups = lookups = new LookupsClient(cfg.twilio.accountSId, cfg.twilio.authToken);
  }
});

const isValidNumber = (number) => {
  return new Promise((resolve, reject) => {
    lookups.phoneNumbers(number).get((error, response) => {
      if (error) {
        console.log(error);
        reject({error, message: 'The call was not made because the number ' + number + ' is Invalid.'});
      }
      resolve(response);
      return true;
    })
  });
};

module.exports = {
  client: client,
  TwimlResponse: twilio.TwimlResponse,
  twiml: twiml,
  lookups: lookups,
  isValidNumber
};