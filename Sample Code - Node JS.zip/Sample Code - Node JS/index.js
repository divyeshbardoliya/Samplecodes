// require('appmetrics-dash').attach();

var morgan = require('morgan')

var server = require('./server');

var express = require('express');
var compress = require('compression');
var bodyParser = require('body-parser');
var cors = require('cors');


var app = express();

app.set('port', (process.env.OPENSHIFT_NODEJS_PORT || process.env.PORT || 5000));

app.use(morgan('MORGAN :method :url :status :res[content-length] - :response-time ms'));

app.use(compress());

app.use(cors());

app.enable('trust proxy');

if (process.env.NODE_ENV == 'production') {
  var enforce = require('express-sslify');
  // use HTTPS(true) in case you are behind a load balancer (e.g. Heroku)
  app.use(enforce.HTTPS({trustProtoHeader: true}));
  // TODO: Azure need different setup:
  // app.use(enforce.HTTPS(false, true))
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));

app.use('/forms', express.static(__dirname + '/webapp/dist'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function (request, response) {
  console.log("hit root url");
  response.render('pages/index');
});

server.init(app).then(function () {
  var listenOnIp = process.env.OPENSHIFT_NODEJS_IP;

  function listenSuccess() {
    console.log('Node app is running on port', (listenOnIp ? listenOnIp + ':' : '') + app.get('port'));
  }

  if (listenOnIp) {
    app.listen(app.get('port'), listenOnIp, listenSuccess);
  }
  else {
    app.listen(app.get('port'), listenSuccess);
  }
}).catch(function (err) {
  console.error('Server init failed:', err, err.stack);
});
