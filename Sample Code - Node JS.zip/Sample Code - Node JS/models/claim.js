module.exports = (sequelize, DataTypes) => {
  const Claim = sequelize.define('claim', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      leadId: DataTypes.INTEGER,
      agentId: DataTypes.INTEGER,
      name: DataTypes.STRING,
      claimed_date: DataTypes.DATE
    },
    {
      freezeTableName: true,
    }
  )

  return Claim
}
