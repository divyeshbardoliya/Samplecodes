module.exports = (sequelize, DataTypes) => {
  const Call = sequelize.define('call', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      fubCallId: DataTypes.INTEGER,
      duration: DataTypes.INTEGER,
      leadId: DataTypes.INTEGER,
      agentId: DataTypes.INTEGER,
      agentName: DataTypes.STRING,
    },
    {
      freezeTableName: true,
    }
  )

  return Call
}
