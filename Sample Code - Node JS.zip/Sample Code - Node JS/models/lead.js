module.exports = (sequelize, DataTypes) => {
  const Lead = sequelize.define('lead', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      leadId: DataTypes.INTEGER,
      name: DataTypes.STRING,
      zip: DataTypes.STRING,
      city: DataTypes.STRING,
      price: DataTypes.INTEGER,
      broadcast_date: DataTypes.DATE
    },
    {
      freezeTableName: true,
    }
  )

  return Lead
}
