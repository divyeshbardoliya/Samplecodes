var config = {
  "firebase": {
    "serviceAccount": {
      "projectId": "",
      "clientEmail": ""
    },
    "databaseURL": ""
  },
  "talkus": {
    "identify": {
      "url": "https://{{apiKey}}@app.talkus.io/api/visitor/identify",
      "method": "POST",
      "json": true,
      "body": "``body``"
    }
  },
  processLeads: false,
  processRealGeeksLeads: false
};

const env_config = process.env.NODE_ENV && require(`./${process.env.NODE_ENV}`);
config = {...config, ...env_config};

if (process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART1) {
  var keyInJson = process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART1;
  if (process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART2)
    keyInJson += process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART2;
  if (process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART3)
    keyInJson += process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART3;
  if (process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART4)
    keyInJson += process.env.GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY_PART4;
  config.firebase.serviceAccount.privateKey = JSON.parse('"' + keyInJson.replace(/\\/g, "\\") + '"');
}
if (process.env.MYSQL_DB_CALL_LOGS)
  config.mysql_db_call_logs = process.env.MYSQL_DB_CALL_LOGS

module.exports = config;
