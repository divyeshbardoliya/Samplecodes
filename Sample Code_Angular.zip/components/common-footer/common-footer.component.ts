import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { GlobalService } from 'src/app/services/global/global.service';

@Component({
    selector: 'app-common-footer',
    templateUrl: './common-footer.component.html',
    styleUrls: ['./common-footer.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class CommonFooterComponent implements OnInit {

    constructor(public globalService: GlobalService) { }

    ngOnInit() {
    }

}
