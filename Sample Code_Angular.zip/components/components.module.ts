import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CommonHeaderComponent } from "./common-header/common-header.component";
import { CommonFooterComponent } from "./common-footer/common-footer.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    declarations: [
        CommonHeaderComponent,
        CommonFooterComponent,
    ],
    exports: [
        CommonModule,
        CommonHeaderComponent,
        CommonFooterComponent,
    ],
})
export class ComponentsModule { }
