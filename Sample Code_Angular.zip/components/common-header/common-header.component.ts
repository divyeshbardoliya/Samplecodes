import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'app-common-header',
    templateUrl: './common-header.component.html',
    styleUrls: ['./common-header.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class CommonHeaderComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
