import { Injectable, EventEmitter, Output, Directive } from '@angular/core';
import { Subscription } from 'rxjs/internal/Subscription';
import { environment } from "../../../../src/environments/environment";
import { RestService } from '../rest/rest.service';
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import * as moment from "moment";
import "moment/locale/es";

@Directive()
@Injectable({
    providedIn: 'root'
})
export class GlobalService {
    public showLoader: boolean = false;
    @Output() postalCodeSelected: EventEmitter<any> = new EventEmitter();

    constructor(private restService: RestService, public router: Router, private toastr: ToastrService) {

    }

    // Function to return number in currency with commas
    LF_numberWithCommas(x: any) {
        if (x != null && x != '' && x != undefined) {
            let y = x.toFixed(2).toString().split('.');
            return y[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + '.' + y[1];
        }
        else {
            return 0;
        }
    }

    // Function to return date string in spanish
    LF_returnDateString(date) {
        var event = new Date(date);
        var options = { year: 'numeric', month: 'long', day: 'numeric' };
        return event.toLocaleDateString('es-MX', options);
    }

    // Function to check if the given string is a number
    LF_checkNumericString(str) {
        return /^\d+$/.test(str);
    }

    // Function to return the list of months
    LF_getMonthsDropdownList() {
        return [
            {
                Id: '01',
                Desc: "Enero"
            },
            {
                Id: '02',
                Desc: "Febrero"
            },
            {
                Id: '03',
                Desc: "Marzo"
            },
            {
                Id: '04',
                Desc: "Abril"
            },
            {
                Id: '05',
                Desc: "Mayo"
            },
            {
                Id: '06',
                Desc: "Junio"
            },
            {
                Id: '07',
                Desc: "Julio"
            },
            {
                Id: '08',
                Desc: "Agosto"
            },
            {
                Id: '09',
                Desc: "Septiembre"
            },
            {
                Id: '10',
                Desc: "Octubre"
            },
            {
                Id: '11',
                Desc: "Noviembre"
            },
            {
                Id: '12',
                Desc: "Diciembre"
            }
        ];
    }

    // Function to return the list of years for birth date
    LF_getListBirthYears(todayDate_year: string) {
        let listYears = [];
        todayDate_year = todayDate_year == "" ? moment().format("YYYY") : todayDate_year;

        for (let index = 0; index < 100; index++) {
            listYears.push({
                Id: parseFloat(todayDate_year) - index,
                Desc: parseFloat(todayDate_year) - index
            });
        }
        return listYears;
    }

    // Function to return the list of days for birth date
    LF_getListBirthDays() {
        let listDays = [];
        for (let index = 0; index < 31; index++) {
            listDays.push({
                Id: this.LF_pad(index + 1, 2),
                Desc: index + 1,
            });
        }
        return listDays;
    }

    // Function to check if the screen if mobile or desktop
    LF_isMobile() {
        if (this.LF_getWidth() <= 767) {
            return true;
        }
        return false;
    }

    // Function to pad the given number preceded by 0
    LF_pad(num, size) {
        var s = num + "";
        while (s.length < size) s = "0" + s;
        return s;
    }

    // Function to get the width of the browser
    LF_getWidth() {
        return Math.max(
            document.body.scrollWidth,
            document.documentElement.scrollWidth,
            document.body.offsetWidth,
            document.documentElement.offsetWidth,
            document.documentElement.clientWidth
        );
    }

    // Function to get the height of the browser
    LF_getHeight() {
        return Math.max(
            document.body.scrollHeight,
            document.documentElement.scrollHeight,
            document.body.offsetHeight,
            document.documentElement.offsetHeight,
            document.documentElement.clientHeight
        );
    }

    // Function to show error message
    LF_showWarningMessage(message, title) {
        this.toastr.warning(message, title);
    }

    // Function to show error message
    LF_showErrorMessage(message, title) {
        this.toastr.error(message, title);
    }

    // Function to show success message
    LF_showSuccessMessage(message, title) {
        this.toastr.success(message, title);
    }

    // Function to restrict single quotes in currency input
    LF_restrictSingleQuotes(event) {
        // Prevent default if not in array
        if (event.keyCode === 222) {
            event.preventDefault();
        }
    }

    // Function to handle the opening of call and mailto from click events
    LF_openCallMailLinks(url) {
        window.location.href = url;
    }

    // Function to redirect internal pages
    LF_redirectToPage(page, data = undefined) {
        if (data) {
            this.router.navigate([page, data]);
        }
        else {
            this.router.navigate([page]);
        }
    }

    // Function to capitaliza each word of the sentence
    LF_toTitleCase(str) {
        return str.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    }

    // Function to allow the user to only enter numbers
    LF_numberOnly(event) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
            event.preventDefault();
        }
    }

    // Function to restrict all the characters in the input
    LF_restrictAll(event) {
        console.log("in");
        event.preventDefault();
    }

    // Function for authentication
    RF_login() {
        let data = {
            URL: environment.authenticateApi,
            DATA: {
                "Username": environment.UserApi,
                "Password": environment.PassApi,
            },
        }
        return new Promise((resolve, reject) => {
            this.restService.RF_postData(data, '')
                .then((response: any) => {
                    try {
                        if ((response && response.status && response.status != 200) || (response && response.ExceptionType)) {
                            reject();
                        }
                        else {
                            resolve(response);
                        }
                    } catch (e) {
                        reject();
                    }
                }, (err) => {
                    reject();
                });
        });
    }

    // Function for fetching the postal code details
    RF_fetchPostalCodeDetails(postalCode) {
        return new Promise((resolve, reject) => {
            this.RF_login().then((auth: any) => {
                // Function to fetch the techo data
                let data = {
                    URL: environment.proxy_domain,
                    DATA: {
                        "URL": environment.postalCodeApi + '?ZipCode=' + postalCode,
                        "Authorization": auth,
                        "DATA": {}
                    },
                };
                this.restService.RF_postData(data, "")
                    .then((response: any) => {
                        if ((response && response.status && response.status != 200) || (response && response.ExceptionType)) {
                            reject();
                        }
                        else {
                            resolve(response);
                        }
                    }, (err) => {
                        reject();
                    });
            }).catch(() => {
                reject();
            });
        });
    }

    // Function to open the given modal
    LF_openModal(modalId, modalClass) {
        let modal = document.getElementById(modalId);
        modal.style.display = "block";
        modal.className = "modal fade show " + modalClass;
    }

    // Function to close the given modal
    LF_closeModal(modalId, modalClass) {
        let modal = document.getElementById(modalId);
        modal.style.display = "none";
        modal.className = "modal fade " + modalClass;
    }
}
