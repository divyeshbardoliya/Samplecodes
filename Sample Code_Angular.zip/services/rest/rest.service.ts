import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from "@angular/router";

@Injectable({
    providedIn: 'root'
})
export class RestService {
    constructor(public httpClient: HttpClient, private router: Router) { }
    // Function to patch data to API
    RF_patchData(data, authToken: string) {
        let headers = {};
        if (authToken != '')
            headers['Authorization'] = authToken;
        return new Promise(resolve => {
            this.httpClient.patch(data.URL, data.DATA, {
                headers: headers
            }).subscribe(data => {
                resolve(data);
            }, err => {
                this.LF_redirectOnError(err);
                resolve(err);
            });
        });
    }
    // Function to get data from API
    RF_getData(url, authToken: string) {
        let headers = {};
        if (authToken != '')
            headers['Authorization'] = authToken;
        return new Promise((resolve, reject) => {
            this.httpClient.get(url, {
                headers: headers
            }).subscribe(res => {
                resolve(res);
            }, (err) => {
                this.LF_redirectOnError(err);
                reject(err);
            });
        });
    }

    // Function to post data to API
    RF_postData(data, authToken: string) {
        let headers = {};
        if (authToken != '')
            headers['Authorization'] = authToken;
        return new Promise(resolve => {
            this.httpClient.post(data.URL, data.DATA, {
                headers: headers
            }).subscribe(data => {
                resolve(data);
            }, err => {
                this.LF_redirectOnError(err);
                resolve(err);
            });
        });
    }
    // Function to redirect the user to home page on 401 and other errors
    LF_redirectOnError(err) {
        // if ((err.status == 401 || err.status == 0)) {
        //     this.router.navigate(["/"]);
        // }
    }
}
