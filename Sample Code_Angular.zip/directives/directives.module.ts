import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { CustominputDirective } from "./custominput/custominput.directive";

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        CustominputDirective,
    ],
    exports: [
        CommonModule,
        CustominputDirective,
    ],
})
export class DirectivesModule { }
