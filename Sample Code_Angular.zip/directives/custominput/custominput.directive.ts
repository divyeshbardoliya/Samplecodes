import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
    selector: '[appCustominput]'
})
export class CustominputDirective {

    constructor(private model: NgControl) { }

    // Custom directive to show only the text after #### for the selected input
    @HostListener('ngModelChange') onNgModelChange() {
        // this.model.control.setValue(newValue);
        this.model.valueAccessor.writeValue(this.model.value.split('####')[1]);
    }

}
