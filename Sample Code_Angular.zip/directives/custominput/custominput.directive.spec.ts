import { CustominputDirective } from './custominput.directive';

describe('CustominputDirective', () => {
    it('should create an instance', () => {
        const directive = new CustominputDirective();
        expect(directive).toBeTruthy();
    });
});
