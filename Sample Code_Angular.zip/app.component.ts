import { Component, enableProdMode } from '@angular/core';
import { GlobalService } from './services/global/global.service';

enableProdMode();
@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent {
    title = 'Title';

    constructor(public globalService: GlobalService) {
    }

    LF_onActivate(event) {
        // to move to top on every page load
        window.scroll(0, 0);
    }
}
