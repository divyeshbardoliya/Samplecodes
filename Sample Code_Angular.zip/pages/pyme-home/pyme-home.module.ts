import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PymeHomeComponent } from './pyme-home.component';
import { ComponentsModule } from '../../components/components.module';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
    {
        path: "",
        component: PymeHomeComponent
    },
]

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        ComponentsModule,
        CarouselModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    exports: [RouterModule],
    declarations: [
        PymeHomeComponent,
    ],
})

export class PymeHomeModule { }
