import { Component, OnInit, ViewEncapsulation, NgZone, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { GlobalService } from 'src/app/services/global/global.service';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RestService } from 'src/app/services/rest/rest.service';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-pyme-home',
    templateUrl: './pyme-home.component.html',
    styleUrls: ['./pyme-home.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class PymeHomeComponent implements OnInit {

    @ViewChild('pymeWizard') pymeWizard: ElementRef;
    selectedType: any;
    pymeType: any;
    pymeTypeId: any;
    postalCode: any;
    formStep: any = 1;
    owlOptions: OwlOptions;
    pymeCategoryDebouce: any;
    pymeCategorySearching: boolean = false;
    pymeCategoryFocused: boolean = false;
    pymeCategories: any = [];
    otherPymeCategory: any = "";
    postalCodeFormGroup: FormGroup;
    postalCodeSubmitted: boolean = false;
    quotationFormGroup: FormGroup;
    quotationSubmitted: boolean = false;
    userFormGroup: FormGroup;
    userDataSubmitted: boolean = false;
    postalCodeSelectedSubscription: Subscription;
    giroDataFlag: any = 0;
    girosList: any = [];
    subGirosList: any = [];
    cityBankCustomer: any;

    constructor(private zone: NgZone, private formBuilder: FormBuilder, public globalService: GlobalService, private restService: RestService, public route: ActivatedRoute) {

        if (this.route.snapshot.paramMap.get('formStep')) {
            this.formStep = this.route.snapshot.paramMap.get('formStep')
            console.log("this.formStep", this.formStep);
        }

        this.quotationFormGroup = this.formBuilder.group({
            quotation: new FormControl('', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(4), Validators.maxLength(10)])),
        });
        this.postalCodeFormGroup = this.formBuilder.group({
            postalCode: new FormControl('', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(5), Validators.maxLength(5)])),
        });
        this.userFormGroup = this.formBuilder.group({
            name: new FormControl('', Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z ]*$')])),
            telephone: new FormControl('', Validators.compose([Validators.required, Validators.pattern('^[0-9]*$'), Validators.minLength(10), Validators.maxLength(10)])),
            email: new FormControl('', Validators.compose([Validators.required, Validators.email])),
        });
        // Subscribe to the postal code change event from the modal
        this.postalCodeSelectedSubscription = this.globalService.postalCodeSelected.subscribe((value) => {
            // Set the value to the postalCode field
            this.postalCodeFormGroup.get('postalCode').setValue(value);
        });

        // Call the function to get the required data
        this.RF_getRequiredGiroData();

    }

    ngOnDestroy() {
        this.postalCodeSelectedSubscription.unsubscribe();
    }

    ngOnInit() {
        this.owlOptions = {
            dots: false,
            center: true,
            items: 1,
            loop: false,
            margin: 10,
            autoWidth: false,
            startPosition: 0,
            nav: true,
            autoHeight: true,
            mouseDrag: false,
            touchDrag: false,
            pullDrag: false,
            freeDrag: false,
            navText: ["<div class='nav-btn prev-slide'></div>", "<div class='nav-btn next-slide'></div>"],
        };
    }

    // Function to handle the selection of property type
    LF_handlePropertyTypeSelection(type) {
        this.formStep++;
        this.selectedType = type;
        // Move to the next step
        this.pymeWizard['next']();
        window.scroll(0, 0);
    }

    // Function to handle the selection of property type
    LF_handlePymeTypeSelection(id, type) {
        this.formStep++;
        this.pymeType = type;
        this.pymeTypeId = id;
        // Move to the next step
        this.pymeWizard['next']();
        window.scroll(0, 0);
        this.pymeCategories = [];
        this.pymeCategorySearching = false;
    }

    // Function to handle the click of back button
    LF_handleBackClick(param) {
        this.formStep--;
        // Move to the previous step
        this.pymeWizard['prev']();
        window.scroll(0, 0);
        if (param == 'pymeType') {
            this.selectedType = '';
        }
        else if (param == 'postalCode') {
            this.pymeType = '';
            this.pymeTypeId = '';
        }
    }

    // Function to check the pyme category
    RF_checkPymeCategory(event) {
        this.zone.run(() => {
            this.pymeCategorySearching = true;
            this.pymeCategoryFocused = true;
            this.pymeCategories = [];
            if (this.pymeCategoryDebouce) {
                clearTimeout(this.pymeCategoryDebouce);
            }
            this.pymeCategoryDebouce = setTimeout(() => {
                this.pymeCategorySearching = false;
                console.log(this.otherPymeCategory);
                if (this.otherPymeCategory != "") {
                    this.pymeCategories = this.subGirosList.filter((subGiro) => {
                        return (subGiro['Desc'].toLowerCase().indexOf(this.otherPymeCategory.toLowerCase()) !== -1);
                    });
                }
                else {
                    this.pymeCategories = JSON.parse(JSON.stringify(this.subGirosList));
                }
            }, 300);
        })
    }

    // Function to handle the selection of pyme category from autocomplete menu
    LF_pymeCategoryFieldSelected(id, value) {
        this.otherPymeCategory = value;
        this.LF_handlePymeTypeSelection(id, value);
    }

    // Function to handle the submit of postal code form
    LF_onPostalCodeSubmit(values) {
        this.postalCodeSubmitted = true;
        if (this.postalCodeFormGroup.valid) {
            this.formStep++;
            this.postalCode = values.postalCode;
            // Move to the next step
            this.pymeWizard['next']();
            window.scroll(0, 0);
            this.postalCodeSubmitted = false;
        }
    }

    // Function to handle the submit of the quotation form
    LF_onQuotationSubmit(values) {
        this.quotationSubmitted = true;
        if (this.quotationFormGroup.valid) {
            console.log("redirect to planes page");
            this.globalService.LF_redirectToPage('/planes', { selectedType: 'RENTADO', pymeType: 'Abarrotes y Mercancías mixtas', pymeTypeId: '1', postalCode: '98765', userName: 'Espac Mexic', userTelephone: '9987654321', userEmail: 'espaciosmx1@gmail.com' });
        }
    }

    // Function to handle the submit of user data form
    LF_onUserDataSubmit(values) {
        this.userDataSubmitted = true;
        if (this.userFormGroup.valid) {
            this.LF_BankOptionSelected('yes');
            this.userDataSubmitted = false;
        }
    }

    // Function to handle the selection of user of bank options
    LF_BankOptionSelected(value) {
        this.cityBankCustomer = value;
        setTimeout(() => {
            this.globalService.LF_redirectToPage('/planes', { selectedType: this.selectedType, pymeType: this.pymeType, pymeTypeId: this.pymeTypeId, postalCode: this.postalCode, userName: this.userFormGroup.get('name').value, userTelephone: this.userFormGroup.get('telephone').value, userEmail: this.userFormGroup.get('email').value });
        }, 1000);
    }

    // Function to handle the fetching of the required giro and subgiro data
    RF_getRequiredGiroData() {
        this.globalService.showLoader = true;
        this.globalService.RF_login().then((auth: any) => {
            // Function to fetch the giro data
            let dataGiro = {
                URL: environment.proxy_domain,
                DATA: {
                    "URL": environment.catalogsApi,
                    "Authorization": auth,
                    "DATA": { "EstructuraNombre": "EBPTLBRI", "CatalogoNombre": "_CGIRO", "OpcionCatalogoId": 0 }
                },
            };
            this.restService.RF_postData(dataGiro, "")
                .then((response: any) => {
                    try {
                        if ((response && response.status && response.status != 200) || (response && response.ExceptionType)) {
                            this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
                        }
                        else {
                            if (response.Status && response.Status.IsSuccess) {
                                this.girosList = response.ResponseData;
                            }
                            else {
                                this.globalService.LF_showErrorMessage((response.Status && response.Status.Message) ? response.Status.Message : environment.somethingWentWrong, environment.alertTitle);
                            }
                        }
                        this.LF_hideLoader();
                    } catch (e) {
                        this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
                        this.LF_hideLoader();
                    }
                }, (err) => {
                    this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
                    this.LF_hideLoader();
                });
            // Function to fetch the subgiro data
            let dataSubGiro = {
                URL: environment.proxy_domain,
                DATA: {
                    "URL": environment.catalogsApi,
                    "Authorization": auth,
                    "DATA": { "EstructuraNombre": "EBPTLBRI", "CatalogoNombre": "_CSUBGIRO", "OpcionCatalogoId": 0 }
                },
            };
            this.restService.RF_postData(dataSubGiro, "")
                .then((response: any) => {
                    try {
                        if ((response && response.status && response.status != 200) || (response && response.ExceptionType)) {
                            this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
                        }
                        else {
                            if (response.Status && response.Status.IsSuccess) {
                                this.subGirosList = response.ResponseData;
                            }
                            else {
                                this.globalService.LF_showErrorMessage((response.Status && response.Status.Message) ? response.Status.Message : environment.somethingWentWrong, environment.alertTitle);
                            }
                        }
                        this.LF_hideLoader();
                    } catch (e) {
                        this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
                        this.LF_hideLoader();
                    }
                }, (err) => {
                    this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
                    this.LF_hideLoader();
                });
        }).catch(() => {
            this.globalService.LF_showErrorMessage(environment.somethingWentWrong, environment.alertTitle);
            this.globalService.showLoader = false;
        });
    }

    // Function to handle the hiding of loader
    LF_hideLoader() {
        this.giroDataFlag++;
        if (this.giroDataFlag % 2 == 0) {
            this.globalService.showLoader = false;
        }
    }

}
