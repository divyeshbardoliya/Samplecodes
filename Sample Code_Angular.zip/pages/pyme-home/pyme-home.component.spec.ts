import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PymeHomeComponent } from './pyme-home.component';

describe('PymeHomeComponent', () => {
    let component: PymeHomeComponent;
    let fixture: ComponentFixture<PymeHomeComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [PymeHomeComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PymeHomeComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
