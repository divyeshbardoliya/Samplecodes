import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from "@angular/router";

const routes: Routes = [
    {
        path: "", // Main home
        loadChildren: () => import('./pages/pyme-home/pyme-home.module').then(m => m.PymeHomeModule),
        data: {
            title: 'Home',
            path: '/Home'
        }
    },
    {
        path: "exito-de-alquiler", // Policy Purchased Thank you page
        loadChildren: () => import('./pages/pyme-policy-purchased/pyme-policy-purchased.module').then(m => m.PymePolicyPurchasedModule),
        data: {
            title: 'Hire Successful',
            path: '/Hiresuccess'
        }
    },
    {
        path: "planes", // Planes page
        loadChildren: () => import('./pages/planes/planes.module').then(m => m.PlanesModule),
        data: {
            title: 'Planes',
            path: '/Planes'
        }
    },
    {
        path: "cbnx-paquetes-detalle", // CBNX Protected Insurance Coverage - packages
        loadChildren: () => import('./pages/pyme-package-detail/pyme-package-detail.module').then(m => m.PymePackageDetailModule),
        data: {
            title: 'CBNX paquetes detalle',
            path: '/Detalle'
        }
    },
    {
        path: "datos-del-contratante",
        loadChildren: () => import('./pages/pyme-contractor-form/pyme-contractor-form.module').then(m => m.PymeContractorFormModule),
        data: {
            title: 'DATOS DEL CONTRATANTE',
            path: '/datos-del-contratante'
        }
    },
    {
        path: "solicitud-cancelacion-poliza",
        loadChildren: () => import('./pages/policy-cancellation-request/policy-cancellation-request.module').then(m => m.PolicyCancellationRequestModule),
        data: {
            title: 'Solicitud Cancelación Póliza',
            path: '/solicitud-cancelacion-poliza'
        }
    },
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forRoot(routes),
    ],
    exports: [RouterModule],
    declarations: []
})
export class AppRoutingModule { }
